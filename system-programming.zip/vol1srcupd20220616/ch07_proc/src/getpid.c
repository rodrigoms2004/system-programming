/*
 * Example on getpid(), getppid(), getpgrp(), and getpgid().
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
  pid_t  pid;

  fprintf(stdout, "My process id, pid=%u\n", getpid());
  fprintf(stdout, "My parent's process id, ppid=%u\n", getppid());
  fprintf(stdout, "My process group id, pgrp=%u\n", getpgrp());
  fprintf(stdout, "My process group id, pgid=%u\n", getpgid(0));
}

