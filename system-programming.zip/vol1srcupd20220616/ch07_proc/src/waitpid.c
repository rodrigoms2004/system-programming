/*
 * Create two child processes and wait for them using waitpid() with
 * WUNTRACED flag.
 * The parent sends the second child a SIGSTOP signal.
 * The parent sleeps for one second to let the children get a chance to start.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <signal.h>      /* kill() */
#include <unistd.h>
#include <sys/wait.h>

#define NPROCS      2    /* number of child processes to create */
#define SLEEPTIME  20    /* number of seconds a child sleeps */

int main(int argc, char *argv[])
{
  pid_t  pid;
  int    i;
  int    stat;   /* child's exit value */
  int    options = (WUNTRACED);  /* options for waitpid() */

  /* Create the child processes */
  fprintf(stdout, "Parent: to create %u child processes\n", NPROCS);
  for (i = 0; i < NPROCS; i++)
  {
    pid = fork();

    if (pid == -1)
    {
      fprintf(stderr, "fork() failed, errno=%d\n", errno);
      return(1);
    }
    else if (pid == 0)
    {
      /* This is the child process. */
      fprintf(stdout, "Child: I'm a new born child, my pid=%u\n", getpid());
      fprintf(stdout, "Child: my parent is pid=%u\n", getppid());
      sleep(SLEEPTIME);
      return(0);
    }
  }

  /* This is the parent */

  /* Send a signal to the last child */
  sleep(1);
  kill(pid, SIGSTOP);

  /* Wait for all child processes to exit */
  for (i = 0; i < NPROCS; i++)
  {
    pid = waitpid(-1, &stat, options);
    fprintf(stdout, "waitpid() has returned with pid = %d\n", pid);

    /* See if the child terminated normally.
     * WIFEXITED(stat) evaluates to non-zero if a child has terminated normally,
     * whether it returned zero or non-zero.
     */
    if (WIFEXITED(stat))
    {
      fprintf(stdout, "Child %u has terminated normally\n", pid);
      if (WEXITSTATUS(stat))
        fprintf(stdout, "The lowest byte of exit value for child %u is %d\n",
          pid, WEXITSTATUS(stat) );
      else
        fprintf(stdout, "Child %d has returned a value of 0\n", pid);
    }

    /* See if the child terminated due to a signal */
    if (WIFSIGNALED(stat) != 0)
    {
      /* Child terminated due to a signal */
       fprintf(stdout, "Child %d terminated due to a signal\n", pid);
       fprintf(stdout, "Child %d terminated due to getting signal %d\n",
         pid, WTERMSIG(stat));
    }

    /* See if the child was stopped. */
    if (WIFSTOPPED(stat) != 0)
    {
      /* Child was stopped */
      fprintf(stdout, "Child was stopped.\n");
      fprintf(stdout, "Child was stopped by signal %d.\n", WSTOPSIG(stat));
    }
  } 
  return(0);
}

