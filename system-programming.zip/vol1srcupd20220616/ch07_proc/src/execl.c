/*
 * Create a child process to run a new program with the execl() function.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>

#define  PROG_NAME  "myprog"  /* name of my program */
#define  PROG_PATH  "./myprog"  /* path of my program */

int main(int argc, char *argv[])
{
  pid_t  pid;              /* process id */
  int    ret;

  /* Create a child process */
  pid = fork();

  if (pid == -1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    return(1);
  }
  else if (pid == 0)
  {
    char  arg1[8] = "2";  /* first real argument to the child process */

    /* This is the child process. */
    fprintf(stdout, "Child: I'm a new born child.\n");

    /* Run a new program in the child process */
    ret = execl(PROG_PATH, PROG_NAME, (char *)arg1, (char *)NULL);
    fprintf(stdout, "Child: execl() returned %d, errno=%d\n", ret, errno);
    return(0);
  }
  else
  {
    /* This is the parent process. */
    fprintf(stdout, "Parent: I've just spawned a child.\n");

    /* Perform the parent process' task here */
    fprintf(stdout, "Parent: exited\n");
    return(0);
  }
}

