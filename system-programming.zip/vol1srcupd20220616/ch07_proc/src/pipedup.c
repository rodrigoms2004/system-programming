/*
 * Parent and child processes communication using a pipe with dup().
 * The parent process sends a message to the child process using a pipe.
 * Copyright (c) 2013, 2014, 2019-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>      /* pipe(), read(), write() */
#include <string.h>      /* strlen() */
#include <sys/types.h>
#include <sys/wait.h>

#define  BUFSIZE  128
#define  MYMSG  "This is a message from the parent."

int main(int argc, char *argv[])
{
  pid_t  pid;           /* process id */
  int    pfd[2];        /* pipe file descriptors */
  int    ret = 0;
  ssize_t  bytes;       /* number of bytes read or written */
  char   buf[BUFSIZE];  /* message buffer */
  int    status;        /* child's exit status */

  /* Create a pipe */
  ret = pipe(pfd);
  if (ret != 0)
  {
    fprintf(stderr, "pipe() failed, errno=%d\n", errno);
    return(1);
  }

  /* Create a child process */
  pid = fork();
  if (pid == (pid_t)-1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    close(pfd[0]);
    close(pfd[1]);
    return(2);
  }
  else if (pid == 0)
  {    /* The child process */
    close(pfd[1]);        /* Close the write end of the pipe */

    /* Close stdin, duplicate pipe read end fd and read from stdin */
    close(0);
    if (dup(pfd[0]) == -1)
    {
      fprintf(stderr, "Child: dup() failed, errno=%d\n", errno);
      return(errno);
    }

    bytes = read(0, buf, BUFSIZE);  /* Read from the pipe */
    if (bytes < 0)
    {
      fprintf(stderr, "Child: read() failed, errno=%d\n", errno);
      return(1);
    }
    if (bytes < BUFSIZE)
      buf[bytes] = '\0';
    else
      buf[BUFSIZE-1] = '\0';
    fprintf(stdout, "Child received below messages from parent:\n%s\n", buf);

    close(pfd[0]);
    return(ret);
  }
  else
  {    /* The parent process */
    close(pfd[0]);        /* Close the read end of the pipe */

    /* Close stdout, duplicate pipe write end fd and write to stdout */
    close(1);
    if (dup(pfd[1]) == -1)
    {
      fprintf(stderr, "Parent: dup() failed, errno=%d\n", errno);
      return(errno);
    }

    sprintf(buf, "%s", MYMSG);
    bytes = write(1, buf, strlen(buf));  /* Write message to the pipe */
    if (bytes < 0)
    {
      fprintf(stderr, "Parent: write() failed, errno=%d\n", errno);
      ret = 3;
    }

    close(pfd[1]);          /* The reader will see EOF after this */
    pid = wait(&status);    /* Wait for the child */
    return(ret);
  }
}
