/*
 * Print system configurable parameters using sysconf()
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
  long  val;

  fprintf(stdout, "AIO_LISTIO_MAX = %ld\n", sysconf(_SC_AIO_LISTIO_MAX));
  fprintf(stdout, "AIO_MAX = %ld\n", sysconf(_SC_AIO_MAX));
  fprintf(stdout, "ASYNCHRONOUS_IO = %ld\n", sysconf(_SC_ASYNCHRONOUS_IO));
  fprintf(stdout, "ARG_MAX = %ld\n", sysconf(_SC_ARG_MAX));
  fprintf(stdout, "BC_BASE_MAX = %ld\n", sysconf(_SC_BC_BASE_MAX));
  fprintf(stdout, "BC_DIM_MAX = %ld\n", sysconf(_SC_BC_DIM_MAX));
  fprintf(stdout, "BC_SCALE_MAX = %ld\n", sysconf(_SC_BC_SCALE_MAX));
  fprintf(stdout, "BC_STRING_MAX = %ld\n", sysconf(_SC_BC_STRING_MAX));
  fprintf(stdout, "CHILD_MAX = %ld\n", sysconf(_SC_CHILD_MAX));
  fprintf(stdout, "CLK_TCK = %ld\n", sysconf(_SC_CLK_TCK));
  fprintf(stdout, "COLL_WEIGHTS_MAX = %ld\n", sysconf(_SC_COLL_WEIGHTS_MAX));
  fprintf(stdout, "DELAYTIMER_MAX = %ld\n", sysconf(_SC_DELAYTIMER_MAX));
  fprintf(stdout, "EXPR_NEST_MAX = %ld\n", sysconf(_SC_EXPR_NEST_MAX));
  fprintf(stdout, "JOB_CONTROL = %ld\n", sysconf(_SC_JOB_CONTROL));
  fprintf(stdout, "IOV_MAX = %ld\n", sysconf(_SC_IOV_MAX));
#ifdef AIX
  fprintf(stdout, "LARGE_PAGESIZE = %ld\n", sysconf(_SC_LARGE_PAGESIZE));
#endif
  fprintf(stdout, "LINE_MAX = %ld\n", sysconf(_SC_LINE_MAX));
  fprintf(stdout, "LOGIN_NAME_MAX = %ld\n", sysconf(_SC_LOGIN_NAME_MAX));
  fprintf(stdout, "MQ_OPEN_MAX = %ld\n", sysconf(_SC_MQ_OPEN_MAX));
  fprintf(stdout, "MQ_PRIO_MAX = %ld\n", sysconf(_SC_MQ_PRIO_MAX));
  fprintf(stdout, "MEMLOCK = %ld\n", sysconf(_SC_MEMLOCK));
  fprintf(stdout, "MEMLOCK_RANGE = %ld\n", sysconf(_SC_MEMLOCK_RANGE));
  fprintf(stdout, "MEMORY_PROTECTION = %ld\n", sysconf(_SC_MEMORY_PROTECTION));
  fprintf(stdout, "MESSAGE_PASSING = %ld\n", sysconf(_SC_MESSAGE_PASSING));
  fprintf(stdout, "NGROUPS_MAX = %ld\n", sysconf(_SC_NGROUPS_MAX));
  fprintf(stdout, "OPEN_MAX = %ld\n", sysconf(_SC_OPEN_MAX));
  fprintf(stdout, "PASS_MAX = %ld\n", sysconf(_SC_PASS_MAX));
  fprintf(stdout, "PAGESIZE = %ld\n", sysconf(_SC_PAGESIZE));
  fprintf(stdout, "PAGE_SIZE = %ld\n", sysconf(_SC_PAGE_SIZE));
  fprintf(stdout, "PRIORITIZED_IO = %ld\n", sysconf(_SC_PRIORITIZED_IO));
  fprintf(stdout, "PRIORITY_SCHEDULING = %ld\n", sysconf(_SC_PRIORITY_SCHEDULING));
  fprintf(stdout, "RE_DUP_MAX = %ld\n", sysconf(_SC_RE_DUP_MAX));
  fprintf(stdout, "RTSIG_MAX = %ld\n", sysconf(_SC_RTSIG_MAX));
  fprintf(stdout, "REALTIME_SIGNALS = %ld\n", sysconf(_SC_REALTIME_SIGNALS));
  fprintf(stdout, "SAVED_IDS = %ld\n", sysconf(_SC_SAVED_IDS));
  fprintf(stdout, "SEM_NSEMS_MAX = %ld\n", sysconf(_SC_SEM_NSEMS_MAX));
  fprintf(stdout, "SEM_VALUE_MAX = %ld\n", sysconf(_SC_SEM_VALUE_MAX));
  fprintf(stdout, "SEMAPHORES = %ld\n", sysconf(_SC_SEMAPHORES));
  fprintf(stdout, "SHARED_MEMORY_OBJECTS = %ld\n", sysconf(_SC_SHARED_MEMORY_OBJECTS));
  fprintf(stdout, "SIGQUEUE_MAX = %ld\n", sysconf(_SC_SIGQUEUE_MAX));
  fprintf(stdout, "STREAM_MAX = %ld\n", sysconf(_SC_STREAM_MAX));
  fprintf(stdout, "SYNCHRONIZED_IO = %ld\n", sysconf(_SC_SYNCHRONIZED_IO));
  fprintf(stdout, "TIMER_MAX = %ld\n", sysconf(_SC_TIMER_MAX));
  fprintf(stdout, "TIMERS = %ld\n", sysconf(_SC_TIMERS));
  fprintf(stdout, "TZNAME_MAX = %ld\n", sysconf(_SC_TZNAME_MAX));
  fprintf(stdout, "VERSION = %ld\n", sysconf(_SC_VERSION));
  fprintf(stdout, "XBS5_ILP32_OFF32 = %ld\n", sysconf(_SC_XBS5_ILP32_OFF32));
  fprintf(stdout, "XBS5_ILP32_OFFBIG = %ld\n", sysconf(_SC_XBS5_ILP32_OFFBIG));
  fprintf(stdout, "XBS5_LP64_OFF64 = %ld\n", sysconf(_SC_XBS5_LP64_OFF64));
  fprintf(stdout, "XBS5_LPBIG_OFFBIG = %ld\n", sysconf(_SC_XBS5_LPBIG_OFFBIG));
  fprintf(stdout, "XOPEN_CRYPT = %ld\n", sysconf(_SC_XOPEN_CRYPT));
  fprintf(stdout, "XOPEN_LEGACY = %ld\n", sysconf(_SC_XOPEN_LEGACY));
  fprintf(stdout, "XOPEN_REALTIME = %ld\n", sysconf(_SC_XOPEN_REALTIME));
  fprintf(stdout, "XOPEN_REALTIME_THREADS = %ld\n", sysconf(_SC_XOPEN_REALTIME_THREADS));
  fprintf(stdout, "XOPEN_ENH_I18N = %ld\n", sysconf(_SC_XOPEN_ENH_I18N));
  fprintf(stdout, "XOPEN_SHM = %ld\n", sysconf(_SC_XOPEN_SHM));
  fprintf(stdout, "XOPEN_VERSION = %ld\n", sysconf(_SC_XOPEN_VERSION));
#ifndef HPUX
  fprintf(stdout, "XOPEN_XCU_VERSION = %ld\n", sysconf(_SC_XOPEN_XCU_VERSION));
#endif
  fprintf(stdout, "ATEXIT_MAX = %ld\n", sysconf(_SC_ATEXIT_MAX));
  fprintf(stdout, "PAGE_SIZE = %ld\n", sysconf(_SC_PAGE_SIZE));
#ifdef AIX
  fprintf(stdout, "AES_OS_VERSION = %ld\n", sysconf(_SC_AES_OS_VERSION));
#endif
  fprintf(stdout, "2_VERSION = %ld\n", sysconf(_SC_2_VERSION));
  fprintf(stdout, "2_C_BIND = %ld\n", sysconf(_SC_2_C_BIND));
  fprintf(stdout, "2_C_DEV = %ld\n", sysconf(_SC_2_C_DEV));
#ifndef __APPLE__
  fprintf(stdout, "2_C_VERSION = %ld\n", sysconf(_SC_2_C_VERSION));
#endif
  fprintf(stdout, "2_FORT_DEV = %ld\n", sysconf(_SC_2_FORT_DEV));
  fprintf(stdout, "2_FORT_RUN = %ld\n", sysconf(_SC_2_FORT_RUN));
  fprintf(stdout, "2_LOCALEDEF = %ld\n", sysconf(_SC_2_LOCALEDEF));
  fprintf(stdout, "2_SW_DEV = %ld\n", sysconf(_SC_2_SW_DEV));
  fprintf(stdout, "2_UPE = %ld\n", sysconf(_SC_2_UPE));
#ifndef HPUX
  fprintf(stdout, "NPROCESSORS_CONF = %ld\n", sysconf(_SC_NPROCESSORS_CONF));
  fprintf(stdout, "NPROCESSORS_ONLN = %ld\n", sysconf(_SC_NPROCESSORS_ONLN));
#endif
#ifdef AIX
  fprintf(stdout, "THREAD_DATAKEYS_MAX = %ld\n", sysconf(_SC_THREAD_DATAKEYS_MAX));
#endif
  fprintf(stdout, "THREAD_DESTRUCTOR_ITERATIONS = %ld\n", sysconf(_SC_THREAD_DESTRUCTOR_ITERATIONS));
  fprintf(stdout, "THREAD_KEYS_MAX = %ld\n", sysconf(_SC_THREAD_KEYS_MAX));
  fprintf(stdout, "THREAD_STACK_MIN = %ld\n", sysconf(_SC_THREAD_STACK_MIN));
  fprintf(stdout, "THREAD_THREADS_MAX = %ld\n", sysconf(_SC_THREAD_THREADS_MAX));
#ifdef AIX
  fprintf(stdout, "REENTRANT_FUNCTIONS = %ld\n", sysconf(_SC_REENTRANT_FUNCTIONS));
#endif
  fprintf(stdout, "THREADS = %ld\n", sysconf(_SC_THREADS));
  fprintf(stdout, "THREAD_ATTR_STACKADDR = %ld\n", sysconf(_SC_THREAD_ATTR_STACKADDR));
  fprintf(stdout, "THREAD_ATTR_STACKSIZE = %ld\n", sysconf(_SC_THREAD_ATTR_STACKSIZE));
  fprintf(stdout, "THREAD_PRIORITY_SCHEDULING = %ld\n", sysconf(_SC_THREAD_PRIORITY_SCHEDULING));
  fprintf(stdout, "THREAD_PRIO_INHERIT = %ld\n", sysconf(_SC_THREAD_PRIO_INHERIT));
  fprintf(stdout, "THREAD_PRIO_PROTECT = %ld\n", sysconf(_SC_THREAD_PRIO_PROTECT));
  fprintf(stdout, "THREAD_PROCESS_SHARED = %ld\n", sysconf(_SC_THREAD_PROCESS_SHARED));
  fprintf(stdout, "TTY_NAME_MAX = %ld\n", sysconf(_SC_TTY_NAME_MAX));
  fprintf(stdout, "SYNCHRONIZED_IO = %ld\n", sysconf(_SC_SYNCHRONIZED_IO));
  fprintf(stdout, "FSYNC = %ld\n", sysconf(_SC_FSYNC));
  fprintf(stdout, "MAPPED_FILES = %ld\n", sysconf(_SC_MAPPED_FILES));
#ifdef AIX
  fprintf(stdout, "LPAR_ENABLED = %ld\n", sysconf(_SC_LPAR_ENABLED));
  fprintf(stdout, "AIX_KERNEL_BITMODE = %ld\n", sysconf(_SC_AIX_KERNEL_BITMODE));
  fprintf(stdout, "AIX_REALMEM = %ld\n", sysconf(_SC_AIX_REALMEM));
  fprintf(stdout, "AIX_HARDWARE_BITMODE = %ld\n", sysconf(_SC_AIX_HARDWARE_BITMODE));
  fprintf(stdout, "AIX_UKEYS = %ld\n", sysconf(_SC_AIX_UKEYS));
  /* root user only */
  fprintf(stdout, "AIX_MP_CAPABLE = %ld\n", sysconf(_SC_AIX_MP_CAPABLE));
#endif
}

