/*
 * Create a child process.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
  pid_t  pid;

  /* Create a child process */
  pid = fork();

  if (pid == -1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    return(1);
  }
  else if (pid == 0)
  {
    /* This is the child process. */
    fprintf(stdout, "Child: I'm a new born child, my pid=%u\n", getpid());
    fprintf(stdout, "Child: my parent is pid=%u\n", getppid());
    /* Perform the child process' task here */
    return(0);
  }
  else
  {
    /* This is the parent process. */
    sleep(2);
    fprintf(stdout, "Parent: I've just spawned a child, its pid=%u\n", pid);
    /* Perform the parent process' task here */
    return(0);
  }
}
