/*
 * A very simple program -- just sleep a number of seconds.
 * Copyright (c) 2013, 2014, 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>    /* atoi() */
#include <unistd.h>    /* sleep() */

#define  DEF_SLEEP_TIME  3     /* default sleep time (in seconds) */

int main(int argc, char *argv[])
{
  unsigned int  seconds = DEF_SLEEP_TIME;
  unsigned int  leftover;

  fprintf(stdout, "Entered my program\n");

  /* Parse the input parameter if there is one */
  if (argc > 1)
  {
    /* Convert the parameter value from string to integer */
    seconds = atoi(argv[1]);
    if (seconds <= 0)
      seconds = DEF_SLEEP_TIME;
  }

  /* Sleep for the specified number of seconds */
  fprintf(stdout, "My program is going to sleep for %u seconds.\n", seconds);
  leftover = sleep(seconds);
  if (leftover > 0)
    fprintf(stdout, "My program: sleep() was interrupted.\n");

  /* Exit */
  fprintf(stdout, "Exited my program\n");
  return(0);
}
