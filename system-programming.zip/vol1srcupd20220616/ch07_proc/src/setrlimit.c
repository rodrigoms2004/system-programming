/*
 * Set resource limits of a process.
 * Changing the hard limit of a resource requires super user privilege.
 * Copyright (c) 2019, 2020-2021  Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/resource.h>

#define RSCNAME_LEN  24
#define NUM_RSCNAMES 16

struct rscname
{
  unsigned int  idx;
  char          rscname[RSCNAME_LEN+1];
};

struct rscname  names[NUM_RSCNAMES] =
{
  0,  "RLIMIT_CPU",
  1,  "RLIMIT_FSIZE",
  2,  "RLIMIT_DATA",
  3,  "RLIMIT_STACK",
  4,  "RLIMIT_CORE",
  5,  "__RLIMIT_RSS",
  6,  "__RLIMIT_NPROC",
  7,  "RLIMIT_NOFILE",
  8,  "__RLIMIT_MEMLOCK",
  9,  "RLIMIT_AS",
  10,  "__RLIMIT_LOCKS",
  11,  "__RLIMIT_SIGPENDING",
  12,  "__RLIMIT_MSGQUEUE",
  13,  "__RLIMIT_NICE",
  14,  "__RLIMIT_RTPRIO",
  15,  "__RLIMIT_NLIMITS"
};

void print_resrc_limit(unsigned int idx, struct rlimit *limit)
{
  if (limit == NULL)
    return;
  fprintf(stdout, "The limits of %s are: \n", names[idx].rscname);
  fprintf(stdout, "  Soft limit: ");
  if (limit->rlim_cur == RLIM_INFINITY)
    fprintf(stdout, "unlimited.\n");
  else
    fprintf(stdout, "%lu\n", limit->rlim_cur);
  fprintf(stdout, "  Hard limit: ");
  if (limit->rlim_max == RLIM_INFINITY)
    fprintf(stdout, "unlimited.\n");
  else
    fprintf(stdout, "%lu\n", limit->rlim_max);
}

int main(int argc, char *argv[])
{
  int    ret = 0;
  struct rlimit  limit;  /* limit of resource */

  /* Get current limit of the RLIMIT_NOFILE resource */
  ret = getrlimit(RLIMIT_NOFILE, &limit);
  if (ret < 0)
  {
    fprintf(stderr, "getrlimit(RLIMIT_NOFILE) failed , errno=%d\n", errno);
    return(1);
  }
  print_resrc_limit(RLIMIT_NOFILE, &limit);

  /* Raise the soft limit of the RLIMIT_NOFILE resource */
  fprintf(stdout, "\nTo raise the soft limit of RLIMIT_NOFILE resource...\n");
  limit.rlim_cur = limit.rlim_cur + 256;
  ret = setrlimit(RLIMIT_NOFILE, &limit);
  if (ret < 0)
  {
    fprintf(stderr, "setrlimit(RLIMIT_NOFILE) failed , errno=%d\n", errno);
    return(2);
  }
  fprintf(stdout, "setrlimit(RLIMIT_NOFILE) succeeded.\n");

  /* Get current limit of the RLIMIT_NOFILE resource */
  ret = getrlimit(RLIMIT_NOFILE, &limit);
  if (ret < 0)
  {
    fprintf(stderr, "getrlimit(RLIMIT_NOFILE) failed , errno=%d\n", errno);
    return(3);
  }
  print_resrc_limit(RLIMIT_NOFILE, &limit);

  /* Raise the hard limit of the RLIMIT_NOFILE resource, and soft limit too */
  fprintf(stdout, "\nTo raise the hard limit of RLIMIT_NOFILE resource...\n");
  limit.rlim_max = limit.rlim_max + (512);
  limit.rlim_cur = limit.rlim_cur + (1024);
  ret = setrlimit(RLIMIT_NOFILE, &limit);
  if (ret < 0)
  {
    fprintf(stderr, "setrlimit(RLIMIT_NOFILE) failed to raise the hard limit,"
      " errno=%d\n", errno);
    return(4);
  }
  fprintf(stdout, "setrlimit(RLIMIT_NOFILE) succeeded in raising the hard limit.\n");

  /* Get current limit of the RLIMIT_NOFILE resource */
  ret = getrlimit(RLIMIT_NOFILE, &limit);
  if (ret < 0)
  {
    fprintf(stderr, "getrlimit(RLIMIT_NOFILE) failed , errno=%d\n", errno);
    return(5);
  }
  print_resrc_limit(RLIMIT_NOFILE, &limit);

  return(0);
}
