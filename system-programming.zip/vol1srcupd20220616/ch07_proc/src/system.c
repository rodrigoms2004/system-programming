/*
 * Run a new program using the system() function.
 * Copyright (c) 2013, 2014, 2019  Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#define  MYCMD  "/bin/echo 'Hello, there!'"  /* the command to run by default */

int main(int argc, char *argv[])
{
  int    ret = 0;
  char   *cmd = MYCMD;  /* the command to run */

  /* Get the command from the user if there is one */
  if (argc > 1)
    cmd = argv[1];

  /* Run the command */
  ret = system(cmd);
  if (ret == -1)
  {
    /* The first fork() failed */
    fprintf(stderr, "Calling system() failed, errno=%d\n", errno);
    return(1);
  }
  else
    /* The shell was up */
    fprintf(stdout, "Running the command %s returned %d\n", cmd, WEXITSTATUS(ret));

  return(0);
}

