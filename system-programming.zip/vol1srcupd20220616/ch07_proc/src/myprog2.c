/*
 * A very simple program -- sleep and then print environment variables.
 * Copyright (c) 2013, 2014, 2019,2020  Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>    /* atoi() */
#include <unistd.h>    /* sleep() */

#define  DEF_SLEEP_TIME  3     /* default sleep time (in seconds) */

int main(int argc, char *argv[])
{
  unsigned int  seconds = DEF_SLEEP_TIME;
  unsigned int  leftover;
  extern char   **environ;  /* pointer to an array of environment variables */
  char          **envp;

  fprintf(stdout, "Entered my program\n");

  /* Parse the input parameter if there is one */
  if (argc > 1)
  {
    /* Convert the parameter value from string to integer */
    seconds = atoi(argv[1]);
    if (seconds <= 0)
      seconds = DEF_SLEEP_TIME;
  }

  /* Sleep for the specified number of seconds */
  fprintf(stdout, "My program is going to sleep for %u seconds.\n", seconds);
  leftover = sleep(seconds);
  if (leftover > 0)
    fprintf(stdout, "My program: sleep() was interrupted.\n");

  /* Print the environment variables */
  envp = environ;
  while (envp != NULL)
  {
    /* Stop if we've reached the end */
    if (*envp == NULL)
      break;
    fprintf(stdout, "environ[] = %s\n", *envp);
    envp++;
  }

  /* Exit */
  fprintf(stdout, "Exited my program\n");
  return(0);
}
