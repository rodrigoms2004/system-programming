/*
 * A very simple program that reads from stdin and writes to stdout.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* read(), write() */

#define  BUFSZ  256

int main(int argc, char *argv[])
{
  ssize_t    bytes;
  char       buf[BUFSZ];

  /* Read from stdin */
  bytes = read(0, buf, BUFSZ);
  if (bytes == -1)
  {
    fprintf(stderr, "read() failed, errno=%d\n", errno);
    return(-1);
  }
  buf[bytes] = '\0';

  /* Write to stdout */
  fprintf(stdout, "Just read: %s\n", buf);

  return(0);
}

