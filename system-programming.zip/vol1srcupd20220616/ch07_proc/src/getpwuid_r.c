/*
 * The getpwuid_r() function.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <pwd.h>       /* getpwuid_r(), getpwnam_r() */
#include <unistd.h>    /* sysconf() */
#include <stdlib.h>    /* malloc(), free() */
#include <string.h>      /* memset() */

int main(int argc, char *argv[])
{
  int   ret;
  long  buflen;   /* maximum buffer size */
  struct passwd  pwbuf;
  struct passwd  *pwbufp = NULL;
  char           *buf = NULL;    /* pointer to the buffer for string values */

  /* Get the value of the _SC_GETPW_R_SIZE_MAX parameter */
  buflen = sysconf(_SC_GETPW_R_SIZE_MAX);
  if (buflen == -1)
  {
    fprintf(stderr, "sysconf() failed, errno=%d\n", errno);
    return(1);
  }
  fprintf(stdout, "buflen=%ld\n", buflen);

  /* Allocate memory for the buffer */
  buf = (char *)malloc(buflen);
  if (buf == NULL)
  {
    fprintf(stderr, "malloc() failed\n");
    return(2);
  }
  memset((void *)buf, 0, buflen);

  /* Get the password file entry using getpwuid_r() */
#ifdef SPARC_SOLARIS
  pwbufp = getpwuid_r(geteuid(), &pwbuf, buf, buflen);
#else
  ret = getpwuid_r(geteuid(), &pwbuf, buf, buflen, &pwbufp);
#endif
  if (ret != 0)
  {
    fprintf(stderr, "getpwuid_r() failed, ret=%d\n", ret);
    free(buf);
    return(3);
  }

  /* Print the values of 'struct passwd' */
  fprintf(stdout, "User name = %s\n", pwbuf.pw_name);
  fprintf(stdout, "User id   = %u\n", pwbuf.pw_uid);
  fprintf(stdout, "Group id  = %u\n", pwbuf.pw_gid);
  fprintf(stdout, "Home directory  = %s\n", pwbuf.pw_dir);
  fprintf(stdout, "Login shell     = %s\n", pwbuf.pw_shell);

  fprintf(stdout, "&pwbuf=%p pwbufp=%p\n", &pwbuf, pwbufp);

  /* Free the dynamically allocated memory and return */
  free(buf);
  return(0);
}

