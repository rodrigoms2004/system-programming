/*
 * A very simple program demonstrating assert().
 * Copyright (c) 2019  Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <assert.h>

int main(int argc, char *argv[])
{
  char  *ptr = NULL;

  assert(ptr != NULL);

  printf("Program terminates normally.\n");
}
