/*
 * The getlogin() and getlogin_r() functions.
 * Copyright (c) 2013, 2014, 2021 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* getlogin() */
#include <limits.h>    /* LOGIN_NAME_MAX */

int main(int argc, char *argv[])
{
  int   ret = 0;
  char  *loginname;
#ifdef SPARC_SOLARIS
  char  name[_POSIX_LOGIN_NAME_MAX+1];
#elif defined(__APPLE__)
  char  name[_POSIX_LOGIN_NAME_MAX+1];
#else
  char  name[LOGIN_NAME_MAX+1];
#endif

  /* Get the login name using getlogin() */
  loginname = getlogin();
  if (loginname != NULL)
    fprintf(stdout, "My login name returned from getlogin() is %s\n", loginname);
  else
  {
    fprintf(stderr, "getlogin() failed, ret=%d, errno=%d\n", ret, errno);
    ret = 1;
  }

  /* Get the login name using getlogin_r() */
#ifdef SPARC_SOLARIS
  loginname = getlogin_r(name, _POSIX_LOGIN_NAME_MAX);
#elif defined(__APPLE__)
  loginname = getlogin_r(name, _POSIX_LOGIN_NAME_MAX);
#else
  ret = getlogin_r(name, LOGIN_NAME_MAX);
#endif
  if (ret == 0)
    fprintf(stdout, "My login name returned from getlogin_r() is %s\n", name);
  else
  {
    fprintf(stderr, "getlogin_r() failed, ret=%d, errno=%d\n", ret, errno);
    ret = 2;
  }

  return(ret);
}

