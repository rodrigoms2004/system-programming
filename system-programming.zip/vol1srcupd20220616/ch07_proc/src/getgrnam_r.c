/*
 * The getgrnam_r() function.
 * Look up information about a group.
 * Copyright (c) 2013, 2014, 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <grp.h>
#include <unistd.h>      /* sysconf() */
#include <stdlib.h>      /* malloc(), free() */
#include <string.h>      /* memset() */

#define DEFAULTGRP  "bin"

int main(int argc, char *argv[])
{
  int   ret, i;
  int   buflen;   /* maximum buffer size */
  struct group grpinfo;
  struct group *grpinfop = NULL;
  char         *buf = NULL;    /* pointer to the buffer for string values */
  char         *grpname = NULL;

  /* Get the name of the group from user */
  if (argc > 1)
    grpname = argv[1];
  else
    grpname = DEFAULTGRP;

  /* Get the value of the _SC_GETGR_R_SIZE_MAX parameter */
  buflen = sysconf(_SC_GETGR_R_SIZE_MAX);
  if (buflen == -1)
  {
    fprintf(stderr, "sysconf(_SC_GETGR_R_SIZE_MAX) failed.\n");
    return(1);
  }
  fprintf(stdout, "buflen=%u\n", buflen);

  /* Allocate memory for the buffer */
  buf = (char *)malloc(buflen);
  if (buf == NULL)
  {
    fprintf(stderr, "malloc() failed\n");
    return(2);
  }
  memset((void *)buf, 0, buflen);
  memset((void *)&grpinfo, 0, sizeof(grpinfo));

  /* Get the /etc/group file entry using getgrnam_r() */
#ifdef SPARC_SOLARIS
  ret = getgrnam_r(getlogin(), &grpinfo, buf, buflen);
#else
  ret = getgrnam_r(grpname, &grpinfo, buf, buflen, &grpinfop);
#endif
  if (ret != 0)
  {
    fprintf(stderr, "getgrnam_r() failed, ret=%d\n", ret);
    free(buf);
    return(3);
  }

  /* Print the values of 'struct passwd' */
  if (grpinfo.gr_name != NULL)
    fprintf(stdout, "Group name = %s\n", grpinfo.gr_name);
  fprintf(stdout, "Group id   = %u\n", grpinfo.gr_gid);
  for (i = 0; (grpinfo.gr_mem != NULL) && (grpinfo.gr_mem[i] != NULL); i++)
    fprintf(stdout, " %s ", grpinfo.gr_mem[i]);
  fprintf(stdout, "\n");

  /* Free the dynamically allocated memory and return */
  free(buf);
  return(0);
}

