/*
 * Test which exit function calls the registered cleanup at program termination.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <unistd.h>    /* _exit() */
#include <stdlib.h>    /* _Exit(), atexit(), atoi() */

#define  USE_RETURN  1

/* My cleanup function */
void my_cleanup()
{
  fprintf(stdout, "My cleanup function at termination was executed.\n");
}

int main(int argc, char *argv[])
{
  int  ret;
  int  how2exit = USE_RETURN;  /* by default use return() to exit the program */

  fprintf(stdout, "Entered main()\n");

  /* Get the input argument */
  if (argc > 1)
  {
    how2exit = atoi(argv[1]);
    if (how2exit <= 0)
      how2exit = USE_RETURN;
  }

  /* Register the cleanup function */
  ret = atexit(my_cleanup);
  if (ret != 0)
    fprintf(stderr, "atexit() failed, returned value = %d\n", ret);
  else
    fprintf(stdout, "My cleanup function was successfully registered.\n");

  /* Terminate the program in the way the user wants it */
  switch (how2exit)
  {
    case 2:
      fprintf(stdout, "To leave main() via exit()\n");
      exit(ret);
      break;
    case 3: 
      fprintf(stdout, "To leave main() via _exit()\n");
      _exit(ret);
      fflush(stdout);
      break;
    case 4: 
      fprintf(stdout, "To leave main() via _Exit()\n");
      _Exit(ret);
      fflush(stdout);
      break;
    case 5: 
      fprintf(stdout, "To leave main() via abort()\n");
      abort();
      break;
    default:
      fprintf(stdout, "To leave main() via return()\n");
      return(ret);
  }
}
