/*
 * Get environment variables via getenv().
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>    /* getenv() */

int main(int argc, char *argv[])
{
  int  ret;

  fprintf(stdout, "Environment variable HOSTNAME = %s\n", getenv("HOSTNAME"));
  fprintf(stdout, "Environment variable SHELL = %s\n", getenv("SHELL"));
  fprintf(stdout, "Environment variable TERM = %s\n", getenv("TERM"));
  fprintf(stdout, "Environment variable USER = %s\n", getenv("USER"));

  return(0);
}

