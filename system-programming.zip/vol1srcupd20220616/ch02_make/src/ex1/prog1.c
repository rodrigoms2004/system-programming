/*
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2016 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>

int main(int argc, char *argv[])
{
  extern void sayHello();

  sayHello();

  return(0);
}
