/*
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2016 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>

void sayHello()
{
  fprintf(stdout, "Hello, there!\n");
}

void sayHello2()
{
  fprintf(stdout, "Hello, there!!\n");
}
