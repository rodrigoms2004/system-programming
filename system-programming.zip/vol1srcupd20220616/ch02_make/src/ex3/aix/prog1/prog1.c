#include <stdio.h>

int main()
{
  func1();
  func2();
}

