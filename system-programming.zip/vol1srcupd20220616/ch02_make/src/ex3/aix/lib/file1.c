#include <stdio.h>

void func1()
{
  printf("Function func1 was called.\n");
}
