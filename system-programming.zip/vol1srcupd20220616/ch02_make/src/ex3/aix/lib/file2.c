#include <stdio.h>

void func2()
{
  printf("Function func2 was called.\n");
}
