/*
 * Library of utility functions.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2012-2016 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>    /* rand() */
#include <time.h>      /* nanosleep() */

/*
 * Sub-second sleep routine.
 * This function sleeps for microsecs microseconds.
 */
void sub_second_sleep(unsigned int microsecs)
{
  struct timespec  sleeptime;
  int  ret;

  sleeptime.tv_sec = (microsecs / 1000000);    /* seconds */
  sleeptime.tv_nsec = (microsecs % 1000000);   /* microseconds */

  errno = 0;
  ret = nanosleep(&sleeptime, (struct timespec *)NULL);
  if (ret == -1)
    fprintf(stderr, "sub_second_sleep() had an error, errno=%d\n", errno);
}

/*
 * Sleep for a random number of microseconds up to the maximum specified
 * or RAND_MAX.
 */
void random_sleep(unsigned int maxusec)
{
  float  randnumf, fraction;
  int    microsecs;
  struct timespec  sleeptime;
  int    ret;

  if (maxusec > RAND_MAX)
    maxusec = RAND_MAX;

  /* Generate a random number and scale that to maxusec */
  randnumf = (float) rand();
  fraction = (randnumf / (float)RAND_MAX);
  microsecs = (int)(fraction * maxusec);

  /* Set it up and call nanosleep() */
  sleeptime.tv_sec = (microsecs / 1000000);    /* seconds */
  sleeptime.tv_nsec = (microsecs % 1000000);   /* microseconds */

  errno = 0;
  ret = nanosleep(&sleeptime, (struct timespec *)NULL);
  if (ret == -1)
    fprintf(stderr, "random_sleep() had an error, errno=%d\n", errno);
}

