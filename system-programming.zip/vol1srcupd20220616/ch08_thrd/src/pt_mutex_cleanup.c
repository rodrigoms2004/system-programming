/*
 * Clean up the state of a dangling mutex whose lock is held by a dead thread
 * using pthread_mutex_consistent() and pthread_mutex_unlock().
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 * pthread_mutex_consistent() is not supported in Apple Darwin.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>

#define  MAXNTHREADS  10      /* maximum number of threads */
#define  DEFNTHREADS  2       /* default number of threads */
#define  MAXTASKS     9000    /* maximum number of tasks */
#define  DEFNTASKS    500     /* default number of tasks */
#define  LOOPCNT      10000

pthread_mutex_t      mutex1;     /* global mutex shared by all threads */

/* Thread cancellation cleanup handler function */
void cancel_cleanup(char *bufptr)
{
  fprintf(stdout, "Enter thread cancellation cleanup routine.\n");
  if (bufptr)
  {
    free(bufptr);
    fprintf(stdout, "cancel_cleanup(): memory at address %p was freed.\n",
      bufptr); 
  }
}

/* The worker thread */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;        /* my id */
  unsigned int  ntasks;      /* number of tasks to perform */
  int           i, j, ret=0;
  unsigned int  count = 0;   /* counter */
  int           curstate;    /* thread's current cancelstate */
  int           oldstate;    /* thread's previous cancelstate */
  int           curtype;     /* thread's current canceltype */
  int           oldtype;     /* thread's previous canceltype */
  char          *bufptr=NULL;   /* address of malloc-ed memory */
  struct timespec  slptm;    /* time to sleep */

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "worker_thread(): myid=%u ntasks=%u\n", myid, ntasks); 

  /* Set thread's cancelstate -- disable cancellation */
  curstate = PTHREAD_CANCEL_DISABLE;
  ret = pthread_setcancelstate(curstate, &oldstate);
  fprintf(stdout, "worker_thread(): thread cancellation is disabled.\n");

  /* Set thread's canceltype */
  curtype = PTHREAD_CANCEL_DEFERRED;
  ret = pthread_setcanceltype(curtype, &oldtype);

  /* To demo cancellation cleanup, we allocate some memory here. */
  bufptr = malloc(512);
  if (bufptr != NULL)
    fprintf(stdout, "worker_thread(): memory at address %p was allocated.\n",
      bufptr);
  else
    fprintf(stderr, "worker_thread(): failed to allocate memory.\n");

  /* Install the thread cancellation cleanup handler */
  pthread_cleanup_push((void (*)())cancel_cleanup, (void *)bufptr);

  /* Acquire the mutex lock */
  ret = pthread_mutex_lock(&mutex1);
  if (ret != 0)
  {
    fprintf(stderr, "Thread %u failed to lock the mutex, ret=%d\n", myid, ret);
  }

  /* Do the work */
  slptm.tv_sec = 0;
  slptm.tv_nsec = 100000000;  /* 1/10 second */
  for (i = 0; i < ntasks; i++)
  {
    for (j = 0; j < LOOPCNT; j++)
      count++;
    nanosleep(&slptm, (struct timespec *)NULL);
    fprintf(stdout, "worker_thread(): count=%u\n", count);

    if (count == (5*LOOPCNT))
      sleep(1);

    if (count == (10*LOOPCNT))
    {
      /* Set thread's cancelstate -- enable cancellation */
      curstate = PTHREAD_CANCEL_ENABLE;
      ret = pthread_setcancelstate(curstate, &oldstate);
      fprintf(stdout, "worker_thread(): thread cancellation is enabled.\n");
    }
  }

  /* Release the mutex lock */
  ret = pthread_mutex_unlock(&mutex1);
  if (ret != 0)
    fprintf(stderr, "Thread %u failed to unlock the mutex, ret=%d\n", myid, ret);

  /* Remove the thread cancellation cleanup handler */
  pthread_cleanup_pop(0);
  if (bufptr != NULL)
    free(bufptr);

#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)ret);
#endif
}

/* The manager thread */
int manager_thread(void *args)
{
  pthread_t  *argp;
  int        ret=0;
  pthread_t  targetThread;   /* thread id of the target thread */

  /* Extract input argument */
  argp = (pthread_t *)args;
  if (argp != NULL)
    targetThread = *(pthread_t *)argp;
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  sleep(1);  /* Let the worker thread run first */

  /* Cancel the worker thread */
  fprintf(stdout, "manager_thread(), canceling worker thread ...\n");
  fflush(stdout);
  ret = pthread_cancel(targetThread);
  if (ret != 0)
    fprintf(stderr, "manager_thread(), pthread_cancel() failed, ret=%d.\n", ret);

  /* Dead worker thread should still hold the lock.  Try to acquire that lock */
  fprintf(stdout, "Manager thread tries to acquire the same mutext lock ...\n");
  fflush(stdout);
  ret = pthread_mutex_lock(&mutex1);
  if (ret == EOWNERDEAD)
  {
    fprintf(stderr, "Manager thread got error EOWNERDEAD from "
      "pthread_mutex_lock(). Try to clean up ...\n");
#ifndef NOROBUST
    /* Make mutex state consistent */
    ret = pthread_mutex_consistent(&mutex1);
    if (ret != 0)
      fprintf(stderr, "Manager thread failed in pthread_mutex_consistent(),"
        " ret=%d.\n", ret);
    else
      fprintf(stdout, "Manager thread fixed mutex state so it's consistent.\n");
#endif

    /* Release the lock held by the dead thread */
    ret = pthread_mutex_unlock(&mutex1);
    if (ret != 0)
      fprintf(stderr, "Manager thread failed to release the mutex lock, "
        "ret=%d.\n", ret);
    else
      fprintf(stdout, "Manager thread successfully released the mutex lock.\n");

    fprintf(stdout, "Manager thread tries to lock the mutex again.\n");
    ret = pthread_mutex_lock(&mutex1);
    if (ret != 0)
      fprintf(stderr, "Manager thread failed to lock the mutex again, "
        "ret=%d.\n", ret);
    else
      fprintf(stdout, "Manager thread successfully acquired the mutext lock!\n");
  }
  else if (ret != 0)
  {
    fprintf(stderr, "Manager thread failed to lock the mutex, ret=%d.\n", ret);
  }
  else
    fprintf(stdout, "Manager thread successfully acquire the mutext lock.\n");

  ret = pthread_mutex_unlock(&mutex1);
  if (ret != 0)
    fprintf(stderr, "Manager thread failed to unlock the mutex, ret=%d.\n", ret);
  else
    fprintf(stdout, "Manager thread successfully released the mutex lock.\n");

#ifdef SUN64
  ret = (0);
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)(0));
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[MAXNTHREADS];
  unsigned int  args1[2];
  pthread_t     args2;
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif
  int           nthreads = DEFNTHREADS;     /* default # of threads */
  int           ntasks = DEFNTASKS;         /* default # of tasks */
  pthread_mutexattr_t  mutexattr1;          /* mutex attributes */

  /* Get number of threads and tasks from user */
  if (argc > 1)
  {
    nthreads = atoi(argv[1]);
    if (nthreads < 0 || nthreads > MAXNTHREADS)
      nthreads = DEFNTHREADS;
  }
  if (argc > 2)
  {
    ntasks = atoi(argv[2]);
    if (ntasks < 0 || ntasks > MAXTASKS)
      ntasks = DEFNTASKS;
  }

  /* Initialize mutex attributes */
  ret = pthread_mutexattr_init(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex attributes, ret=%d.\n", ret);
    pthread_exit((void *)-1);
  }

#ifndef NOROBUST
  /* Set robust mutex */
  ret = pthread_mutexattr_setrobust(&mutexattr1, PTHREAD_MUTEX_ROBUST);
  if (ret != 0)
  {
    fprintf(stderr, "pthread_mutexattr_setrobust() failed, ret=%d.\n", ret);
    pthread_exit((void *)-2);
  }
#endif
 
  /* Initialize the mutex */
  ret = pthread_mutex_init(&mutex1, &mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex, ret=%d.\n", ret);
    pthread_exit((void *)-3);
  }

  /* Load up the input arguments for the worker thread */
  args1[0] = (1);
  args1[1] = ntasks;

  /* Create a worker thread */
  ret = pthread_create(&thrds[0], (pthread_attr_t *)NULL,
        (void *(*)(void *))worker_thread, (void *)args1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create the worker thread, ret=%d.\n", ret);
    pthread_exit((void *)-4);
  }

  /* Create the manager thread */
  args2 = thrds[0];
  ret = pthread_create(&thrds[1], (pthread_attr_t *)NULL,
        (void *(*)(void *))manager_thread, (void *)&args2);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create the manager thread, ret=%d.\n", ret);
    pthread_exit((void *)-5);
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthreads; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  /* Destroy mutex attributes */
  ret = pthread_mutexattr_destroy(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex attributes, ret=%d.\n", ret);
    pthread_exit((void *)-6);
  }

  /* Destroy the mutex */
  ret = pthread_mutex_destroy(&mutex1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex, ret=%d.\n", ret);
    pthread_exit((void *)-7);
  }

  pthread_exit((void *)0);
}
