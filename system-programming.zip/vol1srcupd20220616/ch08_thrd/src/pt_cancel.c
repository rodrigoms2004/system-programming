/*
 * Thread cancellation.
 * Copyright (c) 2014, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>

#define  MAXNTHREADS  10      /* maximum number of threads */
#define  DEFNTHREADS  2       /* default number of threads */
#define  MAXTASKS     9000    /* maximum number of tasks */
#define  DEFNTASKS    500     /* default number of tasks */
#define  LOOPCNT      10000

/* Thread cancellation cleanup handler function */
void cancel_cleanup(char *bufptr)
{
  fprintf(stdout, "Enter thread cancellation cleanup routine.\n");
  if (bufptr)
  {
    free(bufptr);
    fprintf(stdout, "cancel_cleanup(): memory at address %p was freed.\n",
      bufptr); 
  }
}

/* The worker thread */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;        /* my id */
  unsigned int  ntasks;      /* number of tasks to perform */
  int           i, j, ret=0;
  unsigned int  count = 0;   /* counter */
  int           curstate;    /* thread's current cancelstate */
  int           oldstate;    /* thread's previous cancelstate */
  int           curtype;     /* thread's current canceltype */
  int           oldtype;     /* thread's previous canceltype */
  char          *bufptr=NULL;   /* address of malloc-ed memory */
  struct timespec  slptm;    /* time to sleep */

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "worker_thread(): myid=%u ntasks=%u\n", myid, ntasks); 

  /* Set thread's cancelstate -- disable cancellation */
  curstate = PTHREAD_CANCEL_DISABLE;
  ret = pthread_setcancelstate(curstate, &oldstate);
  fprintf(stdout, "worker_thread(): thread cancellation is disabled.\n");

  /* Set thread's canceltype */
  curtype = PTHREAD_CANCEL_DEFERRED;
  ret = pthread_setcanceltype(curtype, &oldtype);

  /* To demo cancellation cleanup, we allocate some memory here. */
  bufptr = malloc(512);
  if (bufptr != NULL)
    fprintf(stdout, "worker_thread(): memory at address %p was allocated.\n",
      bufptr);
  else
    fprintf(stderr, "worker_thread(): failed to allocate memory.\n");

  /* Install the thread cancellation cleanup handler */
  pthread_cleanup_push((void (*)())cancel_cleanup, (void *)bufptr);

  /* Do the work */
  slptm.tv_sec = 0;
  slptm.tv_nsec = 100000000;  /* 1/10 second */
  for (i = 0; i < ntasks; i++)
  {
    for (j = 0; j < LOOPCNT; j++)
      count++;
    nanosleep(&slptm, (struct timespec *)NULL);
    fprintf(stdout, "worker_thread(): count=%u\n", count);

    if (count == (5*LOOPCNT))
      sleep(1);

    if (count == (10*LOOPCNT))
    {
      /* Set thread's cancelstate -- enable cancellation */
      curstate = PTHREAD_CANCEL_ENABLE;
      ret = pthread_setcancelstate(curstate, &oldstate);
      fprintf(stdout, "worker_thread(): thread cancellation is enabled.\n");
    }
  }

  /* Remove the thread cancellation cleanup handler */
  pthread_cleanup_pop(0);
  if (bufptr != NULL)
    free(bufptr);

#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)ret);
#endif
}

/* The manager thread */
int manager_thread(void *args)
{
  pthread_t  *argp;
  int        ret=0;
  pthread_t  targetThread;   /* thread id of the target thread */

  /* Extract input argument */
  argp = (pthread_t *)args;
  if (argp != NULL)
    targetThread = *(pthread_t *)argp;
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  sleep(1);  /* Let the worker thread run first */

  /* Cancel the worker thread */
  fprintf(stdout, "manager_thread(), canceling worker thread ...\n");
  fflush(stdout);
  ret = pthread_cancel(targetThread);
  if (ret != 0)
    fprintf(stderr, "manager_thread(), pthread_cancel() failed, ret=%d\n", ret);

#ifdef SUN64
  ret = (0);
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)(0));
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[MAXNTHREADS];
  unsigned int  args1[2];
  pthread_t     args2;
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif
  int           nthreads = DEFNTHREADS;     /* default # of threads */
  int           ntasks = DEFNTASKS;         /* default # of tasks */

  /* Get number of threads and tasks from user */
  if (argc > 1)
  {
    nthreads = atoi(argv[1]);
    if (nthreads < 0 || nthreads > MAXNTHREADS)
      nthreads = DEFNTHREADS;
  }
  if (argc > 2)
  {
    ntasks = atoi(argv[2]);
    if (ntasks < 0 || ntasks > MAXTASKS)
      ntasks = DEFNTASKS;
  }

  /* Load up the input arguments for the worker thread */
  args1[0] = (1);
  args1[1] = ntasks;

  /* Create a worker thread */
  ret = pthread_create(&thrds[0], (pthread_attr_t *)NULL,
        (void *(*)(void *))worker_thread, (void *)args1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }

  /* Create the manager thread */
  args2 = thrds[0];
  ret = pthread_create(&thrds[1], (pthread_attr_t *)NULL,
        (void *(*)(void *))manager_thread, (void *)&args2);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create the manager thread, ret=%d\n", ret);
    pthread_exit((void *)-4);
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthreads; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  pthread_exit((void *)0);
}
