/*
 * Passing an array of integers to a child thread and returning a structure
 * from each child thread.
 * Copyright (c) 2014, 2019 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>      /* malloc() */
#include <string.h>      /* memset() */
#include <pthread.h>

#define  NTHREADS    2
#define  NTASKS      3

struct mydata
{
  char msg[32];
  int  num;
};
typedef struct mydata mydata;

/* 
 * The worker thread.
 */
mydata *worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid=0;
  unsigned int  ntasks=0;
  mydata        *outdata;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks); 

  /* Do some real work here */

  /* Return a structure of data to caller */
  outdata = (mydata *)malloc(sizeof(mydata));
  if (outdata != NULL)
  {
    memset((void *)outdata, 0, sizeof(mydata));
    outdata->num = (myid *100);
    sprintf(outdata->msg, "%s %u", "From child thread ", myid);
  }

  pthread_exit((void *)outdata);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[NTHREADS];
  unsigned int  args[NTHREADS][2];
  int           ret, i;
  mydata        *retval;  /* each child thread returns an int */

  /* Load up the input arguments for each child thread */
  for (i = 1; i <= NTHREADS; i++)
  {
    args[i-1][0] = i;
    args[i-1][1] = NTASKS;
  }

  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < NTHREADS; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-1);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 1; i <= NTHREADS; i++)
  {
    ret = pthread_join(thrds[i-1], (void **)&retval);
    if (retval == NULL)
      fprintf(stdout, "Child thread %u exited with return value NULL\n", i);
    else
    {
      fprintf(stdout, "Child thread %u exited with following return value:\n", i);
      fprintf(stdout, "  msg = %s\n", retval->msg);
      fprintf(stdout, "  num = %d\n", retval->num);
      free(retval);
    }
  }

  pthread_exit((void *)0);
}
