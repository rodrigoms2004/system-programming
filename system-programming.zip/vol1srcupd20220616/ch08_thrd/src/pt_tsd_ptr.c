/*
 * Thread-specific data in pthread.
 * Using thread-specific data to store a pointer to a thread specific buffer.
 * Copyright (c) 2014, 2019 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define  MAXNTHREADS  10      /* maximum number of threads */
#define  DEFNTHREADS  3       /* default number of threads */
#define  MAXTASKS     3000    /* maximum number of tasks */
#define  DEFNTASKS    2       /* default number of tasks */

pthread_key_t      bufptr;    /* thread-specific data (the key) */
struct mybuf {
  unsigned int     myid;
  char             text[32];
};

/* Print contents of 'struct mybuf' */
int print_buf(unsigned int myid, unsigned int cnt)
{
  struct timespec  slptm;
  int    i;
  char  *valptr;     /* pointer returned by pthread_getspecific() */
  struct mybuf  *mybufptr;   /* value of thread-specific key */

  slptm.tv_sec = 0;
  slptm.tv_nsec = 500000000;  /* 5/10 second */

  if (cnt <= 0)
    return(-1);

  for (i = 0; i < cnt; i++)
  {
    /* Retrieve thread-specific buffer pointer */
    valptr =  pthread_getspecific(bufptr);
    if (valptr == NULL)
    {
      fprintf(stderr, "print_buf(): pthread_getspecific() returned NULL\n");
      return(-2);
    }
    mybufptr = (struct mybuf *)valptr;

    /* Do something */
    fprintf(stdout, "Contents of the thread-specific buffer are:\n");
    fprintf(stdout, "  myid = %u\n", mybufptr->myid);
    fprintf(stdout, "  text = %s\n", mybufptr->text);

    nanosleep(&slptm, (struct timespec *)NULL);
  }
 
  return(0);
}

/* The worker thread */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;        /* my id */
  unsigned int  ntasks;      /* number of tasks to perform */
  int           i, ret=0;
  char          *ptr1;
  struct mybuf  *ptr2;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks); 

  /* Initialize thread specific data. First, allocate buffer memory. */
  ptr1 = (char *)malloc(sizeof(struct mybuf));
  if (ptr1 == NULL)
  {
#ifdef SUN64
    ret = (-2);
    pthread_exit((void *)&ret);
#else
    pthread_exit((void *)(-2));
#endif
  }

  /* Save the pointer in thread-specific data. No & because ptr1 is a pointer */
  ret = pthread_setspecific(bufptr, (void *)ptr1);
  if (ret != 0)
  {
    fprintf(stderr, "worker_thread: pthread_setspecific() failed, ret=%d\n",
      ret);
#ifdef SUN64
    ret = (-3);
    pthread_exit((void *)&ret);
#else
    pthread_exit((void *)(-3));
#endif
  }

  /* Set thread-specific data */
  ptr2 = (struct mybuf *)ptr1;
  ptr2->myid = myid;
  sprintf(ptr2->text, "This is thread %2d.\n", myid);

  /* Do the work -- just print the data. */
  print_buf(myid, ntasks);
  free(ptr1);

  ret = 0;
#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[MAXNTHREADS];
  unsigned int  args[MAXNTHREADS][2];
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif
  int           nthreads = DEFNTHREADS;     /* default # of threads */
  int           ntasks = DEFNTASKS;         /* default # of tasks */

  /* Get number of threads and tasks from user */
  if (argc > 1)
  {
    nthreads = atoi(argv[1]);
    if (nthreads < 0 || nthreads > MAXNTHREADS)
      nthreads = DEFNTHREADS;
  }
  if (argc > 2)
  {
    ntasks = atoi(argv[2]);
    if (ntasks < 0 || ntasks > MAXTASKS)
      ntasks = DEFNTASKS;
  }

  /* Load up the input arguments for each child thread */
  for (i = 0; i < nthreads; i++)
  {
    args[i][0] = (i + 1);
    args[i][1] = ntasks;
  }

  /* Create thread-specific data key: bufptr */
  ret = pthread_key_create(&bufptr, (void *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }
  
  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < nthreads; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-4);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthreads; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  /* Delete thread-specific data key: bufptr */
  ret = pthread_key_delete(bufptr);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to delete thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-5);
  }

  pthread_exit((void *)0);
}
