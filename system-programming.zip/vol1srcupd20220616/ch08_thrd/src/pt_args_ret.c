/*
 * Passing an array of integers to a child thread and returning one integer.
 * Copyright (c) 2014, Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <pthread.h>

#define  NTHREADS    2
#define  NTASKS      3

/* 
 * The worker thread.
 */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
#ifdef SUN64
  int           ret = 0;
#endif

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks); 
#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[NTHREADS];
  unsigned int  args[NTHREADS][2];
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif

  /* Load up the input arguments for each child thread */
  for (i = 0; i < NTHREADS; i++)
  {
    args[i][0] = i;
    args[i][1] = NTASKS;
  }

  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < NTHREADS; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-1);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < NTHREADS; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  pthread_exit((void *)0);
}
