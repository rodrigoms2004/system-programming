/*
 * Create and use a signal handling thread.
 * Update shared data with synchronization using pthread mutex.
 * Copyright (c) 2014, 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>

#define  NTHREADS    4
#define  NTASKS      5000000
#define  DELAY_COUNT 1000

unsigned int  global_count=0;    /* global data shared by all threads */
pthread_mutex_t      mutex1;     /* global mutex shared by all threads */

/* Signal handling thread */
void signal_handling_thread()
{
  int       signal;    /* signal number */
  sigset_t  sigset;    /* signal set */
  int       ret = 0;   /* return code */

  /* Block all signals */
  sigfillset(&sigset);
  pthread_sigmask(SIG_SETMASK, &sigset, (sigset_t *)NULL);
#ifdef AIX
  sigdelset(&sigset, SIGKILL);
  sigdelset(&sigset, SIGSTOP);
  sigdelset(&sigset, SIGWAITING);
#endif
  /* Wait for a signal to arrive and then handle it */
  while (1)
  {
    ret = sigwait((sigset_t *)&sigset, (int *)&signal);
    if (ret != 0)
      fprintf(stderr, "signal_handling_thread(): sigwait() failed, ret=%d\n",
        ret);
    else
      fprintf(stdout, "signal_handling_thread() received signal %d.\n",
        signal);
  }
#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/* 
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  int           i, j, ret=0;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks); 

  /* Do my job */
  for (i = 0; i < ntasks; i++)
  {
    ret = pthread_mutex_lock(&mutex1);
    if (ret != 0)
    {
      fprintf(stderr, "Thread %u failed to lock the mutex, ret=%d\n", myid, ret);
      continue;
    }

    /* Update the shared data */
    global_count = global_count + 1;
    /* insert a bit of delay */
    for (j = 0; j < DELAY_COUNT; j++);

    ret = pthread_mutex_unlock(&mutex1);
    if (ret != 0)
      fprintf(stderr, "Thread %u failed to unlock the mutex, ret=%d\n", myid, ret);
  }

#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[NTHREADS];
  unsigned int  args[NTHREADS][2];
  int           ret, i;
  int           retval = 0;         /* each child thread returns an int */
  pthread_mutexattr_t  mutexattr1;  /* mutex attributes */
#ifdef SUN64
  int           *retvalp = &retval; /* pointer to returned value */
#endif
  sigset_t      sigset;
  pthread_t     sigthrd;

  /* Block all signals */
  sigfillset(&sigset);
  pthread_sigmask(SIG_SETMASK, &sigset, (sigset_t *)NULL);

  /* Load up the input arguments for each child thread */
  for (i = 0; i < NTHREADS; i++)
  {
    args[i][0] = i;
    args[i][1] = NTASKS;
  }

  /* Initialize mutex attributes */
  ret = pthread_mutexattr_init(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-2);
  }

  /* Initialize the mutex */
  ret = pthread_mutex_init(&mutex1, &mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }

  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < NTHREADS; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-4);
    }
  }

  /* Create the signal handling thread */
  ret = pthread_create(&sigthrd, (pthread_attr_t *)NULL,
        (void *(*)(void *))signal_handling_thread, NULL);
  if (ret != 0)
    fprintf(stderr, "Failed to create the signal handling thread, ret=%d\n",
      ret);

  /* Send a signal to the worker thread */
  ret = pthread_kill(thrds[0], SIGINT);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to send a signal to first worker thread, ret=%d\n",
      ret);
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < NTHREADS; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  /* Destroy mutex attributes */
#ifndef HPUX64
  ret = pthread_mutexattr_destroy(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-5);
  }
#endif

  /* Destroy the mutex */
  ret = pthread_mutex_destroy(&mutex1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex, ret=%d\n", ret);
    pthread_exit((void *)-6);
  }

  fprintf(stdout, "global_count = %u\n", global_count);

  /* Cancel the signal handling thread */
  ret = pthread_cancel(sigthrd);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to cancel signal handling thread, ret=%d\n",
      ret);
  }

  pthread_exit((void *)0);
}
