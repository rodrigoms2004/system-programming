/*
 * Read-write locks in pthread with lock attribute init.
 * Copyright (c) 2014-2020, Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <pthread.h>

#define  NREADERS    2       /* number of readers */
#define  NWRITERS    1       /* number of writers */
#define  NTASKS      4
#define  DELAY_COUNT_RD 200000000
#define  DELAY_COUNT_WR 100000000

unsigned int  global_count=0;    /* global data shared by all threads */

/* Global read-write lock shared by all threads */
pthread_rwlock_t    rwlock1;

/* 
 * The reader thread.
 */
int reader_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  int           i, ret;
  unsigned long long j;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
    pthread_exit((void *)(-1));

  fprintf(stdout, "Reader thread %u started: ntasks=%u\n", myid, ntasks); 

  /* Do my job */
  for (i = 0; i < ntasks; i++)
  {
    fprintf(stdout, "Reader thread %u tries to get the read lock\n", myid);
    ret = pthread_rwlock_rdlock(&rwlock1);
    if (ret != 0)
    {
      fprintf(stderr, "Reader thread %u failed to get a read lock, ret=%d\n",
        myid, ret);
      continue;
    }
    fprintf(stdout, "Reader thread %u successfully get the read lock\n", myid);
    fflush(stdout);

    /* Read the shared data */
    fprintf(stdout, "  Reader thread %u read global_count, count = %u\n",
      myid, global_count);
    fflush(stdout);
    /* insert a bit of delay */
    for (j = 0; j < DELAY_COUNT_RD; j++);

    fprintf(stdout, "Reader thread %u successfully released the read lock\n",
        myid);
    fflush(stdout);

    ret = pthread_rwlock_unlock(&rwlock1);
  }

  pthread_exit((void *)0);
}

/* 
 * The writer thread.
 */
int writer_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  int           i, ret;
  unsigned long long j;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
    pthread_exit((void *)(-1));

  fprintf(stdout, "Writer thread %u started: ntasks=%u\n", myid, ntasks); 

  /* Do my job */
  for (i = 0; i < ntasks; i++)
  {
    fprintf(stdout, "Writer thread %u tries to get the write lock\n", myid);
    ret = pthread_rwlock_wrlock(&rwlock1);
    if (ret != 0)
    {
      fprintf(stderr, "Writer thread %u failed to get a write lock, ret=%d\n",
        myid, ret);
      continue;
    }
    fprintf(stdout, "Writer thread %u successfully get the write lock\n", myid);
    fflush(stdout);

    /* Update the shared data */
    global_count = global_count + 1;
    fprintf(stdout, "  Writer thread %u updated global_count, count = %u\n",
      myid, global_count);
    /* insert a bit of delay */
    for (j = 0; j < DELAY_COUNT_WR; j++);

    fprintf(stdout, "Writer thread %u successfully released the write lock\n",
        myid);
    fflush(stdout);

    ret = pthread_rwlock_unlock(&rwlock1);
  }

  pthread_exit((void *)0);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[NREADERS+NWRITERS];
  unsigned int  args[NREADERS+NWRITERS][2];
  int           ret=0, i;
  int           retval;  /* each child thread returns an int */
  pthread_rwlockattr_t    rwlattr;    /* read-write lock attribute */

  /* Initialize a read-write lock attribute */
  ret = pthread_rwlockattr_init(&rwlattr);
  if (ret != 0)
  {
    fprintf(stderr, "pthread_rwlockattr_init() failed, error=%d\n", ret);
    pthread_exit((void *)-1);
  }

  /* Initialize a read-write lock */
  ret = pthread_rwlock_init(&rwlock1, &rwlattr);
  if (ret != 0)
  {
    fprintf(stderr, "pthread_rwlock_init() failed, error=%d\n", ret);
    pthread_exit((void *)-2);
  }

  /* Load up the input arguments */
  for (i = 0; i < NREADERS; i++)
  {
    args[i][0] = (i+1);
    args[i][1] = NTASKS;
  }
  for (i = NREADERS; i < (NREADERS+NWRITERS); i++)
  {
    args[i][0] = (i+1);
    args[i][1] = NTASKS;
  }

  /* Create the reader threads */
  for (i = 0; i < NREADERS; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))reader_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the reader thread\n");
      pthread_exit((void *)-3);
    }
  }

  /* Create the writer threads */
  for (i = NREADERS; i < (NREADERS+NWRITERS); i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))writer_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the writer thread\n");
      pthread_exit((void *)-4);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value. 
   */
  for (i = 0; i < (NREADERS+NWRITERS); i++)
  {
    ret = pthread_join(thrds[i], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  fprintf(stdout, "global_count = %u\n", global_count);

  /* Destroy the read-write lock attribute */
#ifndef HPUX64
  ret = pthread_rwlockattr_destroy(&rwlattr);
  if (ret != 0)
  {
    fprintf(stderr, "Destroying read-write lock attribute failed, ret=%d\n",
      ret);
    pthread_exit((void *)-5);
  }
#endif

  /* Destroy the read-write lock */
  ret = pthread_rwlock_destroy(&rwlock1);
  if (ret != 0)
  {
    fprintf(stderr, "Destroying read-write lock failed, ret=%d\n", ret);
    pthread_exit((void *)-6);
  }

  pthread_exit((void *)0);
}
