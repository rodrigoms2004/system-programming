/*
 * Creating a child thread.
 * Copyright (c) 2014, 2019 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <pthread.h>

/*
 * The child thread.
 */
void child_thread(void *args)
{
  fprintf(stdout, "Enter the child thread\n");
  fprintf(stdout, "My thread id is %ul\n", pthread_self());
  fprintf(stdout, "Child thread exiting ...\n");
  pthread_exit((void *)NULL);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrd;
  int           ret;

  /* Create a child thread to run the child_thread() function. */
  ret = pthread_create(&thrd, (pthread_attr_t *)NULL,
        (void *(*)(void *))child_thread, (void *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "Error: failed to create the child thread, ret=%d\n", ret);
    return(ret);
  }

  /* Wait for the child thread to finish. */
  ret = pthread_join(thrd, (void **)NULL);
  if (ret != 0)
    fprintf(stderr, "Error: failed to join the child thread, ret=%d\n", ret);

  fprintf(stdout, "Main thread exiting ...\n");
  pthread_exit((void *)0);
}
