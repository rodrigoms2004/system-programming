/*
 * Print pthread attributes.
 * Copyright (c) 2014, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

/* Print pthread attributes */
void print_pthread_attr(pthread_attr_t *attr)
{
  int   ret;
  int   val = 0;
  struct sched_param    pri;  /* scheduling priority */
  void   *stkaddr = NULL;     /* stack address */
  size_t stksz = 0;           /* stack size */
  size_t guardsz = 0;         /* guard size */

  if (attr == NULL)
    return;

  /* Get and print detached state */
  ret = pthread_attr_getdetachstate(attr, &val);
  if (ret == 0)
    fprintf(stdout, "  Detach state = %s\n", 
      (val == PTHREAD_CREATE_DETACHED) ? "PTHREAD_CREATE_DETACHED" :
      (val == PTHREAD_CREATE_JOINABLE) ? "PTHREAD_CREATE_JOINABLE" :
      "Unknown");
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getdetachstate() "
      "failed, ret=%d\n", ret);

  /* Get and print contention scope */
  val = 0;
  ret = pthread_attr_getscope(attr, &val);
  if (ret == 0)
    fprintf(stdout, "  Contention scope = %s\n", 
      (val == PTHREAD_SCOPE_SYSTEM) ? "PTHREAD_SCOPE_SYSTEM" :
      (val == PTHREAD_SCOPE_PROCESS) ? "PTHREAD_SCOPE_PROCESS" :
      "Unknown");
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getscope() "
      "failed, ret=%d\n", ret);

  /* Get and print inherit scheduler */
  val = 0;
  ret = pthread_attr_getinheritsched(attr, &val);
  if (ret == 0)
    fprintf(stdout, "  Inherit scheduler = %s\n", 
      (val == PTHREAD_INHERIT_SCHED) ? "PTHREAD_INHERIT_SCHED" :
      (val == PTHREAD_EXPLICIT_SCHED) ? "PTHREAD_EXPLICIT_SCHED" :
      "Unknown");
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getinheritsched() "
      "failed, ret=%d\n", ret);

  /* Get and print scheduling policy */
  val = 0;
  ret = pthread_attr_getschedpolicy(attr, &val);
  if (ret == 0)
    fprintf(stdout, "  Scheduling policy = %s\n", 
      (val == SCHED_RR) ? "SCHED_RR" :
      (val == SCHED_FIFO) ? "SCHED_FIFO" :
      (val == SCHED_OTHER) ? "SCHED_OTHER" :
      "Unknown");
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getschedpolicy() "
      "failed, ret=%d\n", ret);

  /* Get and print scheduling priority */
  memset(&pri, 0, sizeof(pri));
  ret = pthread_attr_getschedparam(attr, &pri);
  if (ret == 0)
    fprintf(stdout, "  Scheduling priority = %d\n", pri.sched_priority);
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getschedparam() "
      "failed, ret=%d\n", ret);

  /* Get and print stack address and stack size */
  ret = pthread_attr_getstack(attr, &stkaddr, &stksz);
  if (ret == 0)
  {
    fprintf(stdout, "  Stack address = %p\n", stkaddr);
    fprintf(stdout, "  Stack size = %lu bytes\n", stksz);
  }
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getstack() "
      "failed, ret=%d\n", ret);

  /* Get and print guard size */
  ret = pthread_attr_getguardsize(attr, &guardsz);
  if (ret == 0)
    fprintf(stdout, "  Guard size = %lu bytes\n", guardsz);
  else
    fprintf(stderr, "print_pthread_attr(): pthread_attr_getguardsize() "
      "failed, ret=%d\n", ret);
}

int main(int argc, char *argv[])
{
  pthread_attr_t  attr1;
  int             ret;

  /* Initialize thread attributes */
  ret = pthread_attr_init(&attr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize thread attributes, ret=%d\n", ret);
    return(-1);
  }

  print_pthread_attr(&attr1);

  /* Destroy thread attributes */
  ret = pthread_attr_destroy(&attr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy thread attributes, ret=%d\n", ret);
    return(-2);
  }
  return(0);
}
