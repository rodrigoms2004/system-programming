/*
 * Thread-specific data in pthread.
 * Note that all threads share the same key or global variable gvar1, but each
 * thread has a private copy of the data. Changes to the data in one thread is
 * never seen by any other thread.
 * Copyright (c) 2014, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define  NTHREADS    4
#define  NTASKS      3

pthread_key_t      gvar1;        /* thread-specific data (the key) */

/* 
 * The worker thread.
 */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;        /* my id */
  unsigned int  ntasks;      /* number of tasks to perform */
  int           i, ret=0;
  unsigned int  *valptr;     /* pointer returned by pthread_getspecific() */
  unsigned int  mynewval;    /* value of thread-specific key */

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks); 

  ret = pthread_setspecific(gvar1, (void *)&myid);
  if (ret != 0)
    fprintf(stderr, "worker_thread: pthread_setspecific() failed, ret=%d\n",
      ret);

  /* Do my job */
  for (i = 0; i < ntasks; i++)
  {
    /* Get and print the current value of the thread-specific data */
    valptr =  pthread_getspecific(gvar1);
    if (valptr == NULL)
    {
      fprintf(stderr, "worker_thread: pthread_getspecific() returned NULL\n");
#ifdef SUN64
      ret = (-2);
      pthread_exit((void *)&ret);
#else
      pthread_exit((void *)(-2));
#endif
    }
    mynewval = (*(unsigned int *)valptr);
    fprintf(stdout, "In thread %u gvar1 = %u \n", myid, mynewval);

    /* Double the value of the thread-specific data */
    mynewval = (2 * mynewval);
    ret = pthread_setspecific(gvar1, (void *)&mynewval);
    if (ret != 0)
    {
      fprintf(stderr, "worker_thread: pthread_setspecific() failed, ret=%d\n",
      ret);
#ifdef SUN64
      ret = (-3);
      pthread_exit((void *)&ret);
#else
      pthread_exit((void *)(-3));
#endif
    }
    sleep(1);
  }

#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[NTHREADS];
  unsigned int  args[NTHREADS][2];
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif

  /* Load up the input arguments for each child thread */
  for (i = 0; i < NTHREADS; i++)
  {
    args[i][0] = (i + 1);
    args[i][1] = NTASKS;
  }

  /* Create thread-specific data key: gvar1 */
  ret = pthread_key_create(&gvar1, (void *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-1);
  }
  
  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < NTHREADS; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-2);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < NTHREADS; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  /* Delete thread-specific data key: gvar1 */
  ret = pthread_key_delete(gvar1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to delete thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }

  pthread_exit((void *)0);
}
