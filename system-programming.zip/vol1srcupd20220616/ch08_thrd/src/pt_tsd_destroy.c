/*
 * Providing destructor function for thread-specific data.
 * Note that all threads share the same global variable gvar1, but each thread
 * has a private copy of the data. Changes to the data in one thread is
 * never seen by any other thread.
 * Copyright (c) 2014, 2019 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>    /* malloc */
#include <string.h>    /* memset() */
#include <unistd.h>    /* sleep() */
#include <pthread.h>

#define  NTHREADS    2
#define  NTASKS      2
#define  MSGSIZE    64

pthread_key_t      gvar1;        /* thread-specific data */

struct mystruct
{
  unsigned int mynum;
  char         mymsg[MSGSIZE];
};
typedef struct mystruct mystruct;

/*
 * Destructor function for thread-specific data key, gvar1.
 */
void destroy_gvar1(void *ptr)
{
  if (ptr != NULL)
  {
    fprintf(stdout, "In destroy_gvar1(), free the memory at address %p\n", ptr);
    free(ptr);
  }
}

/* 
 * The worker thread.
 */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  int           i;
  mystruct      *mydata;
#ifdef SUN64
  int           ret = 0;
#endif

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks); 

  /* Dynamically allocate memory for the thread-specific data key, gvar1 */
  mydata = (mystruct *)malloc(sizeof(mystruct));
  if (mydata == NULL)
  {
    fprintf(stderr, "Thread %u failed to allocate memory\n", myid);
#ifdef SUN64
    ret = (-2);
    pthread_exit((void *)&ret);
#else
    pthread_exit((void *)-2);
#endif
  }
  memset((void *)mydata, 0, sizeof(mystruct));
  fprintf(stdout, "Thread %u, address of thread-specific data %p\n", myid, mydata);

  /* Set the value of the thread-specific data key */
  mydata->mynum = myid;
  sprintf(mydata->mymsg, "This is a message from thread %u.", myid);
  pthread_setspecific(gvar1, (void *)mydata);

  /* Do my job */
  for (i = 0; i < ntasks; i++)
  {
    mydata = pthread_getspecific(gvar1);
    fprintf(stdout, "In thread %u :\n", myid);
    fprintf(stdout, "  mynum = %u\n", mydata->mynum);
    fprintf(stdout, "  mymsg = %s\n", mydata->mymsg);
    sleep(1);
  }

  /* Note that: We would need to free the memory here if we had not
   * called pthread_key_create() with destroy_gvar1 in its second argument.
   *   free(mydata);
   * Since we did that, pthread will invoke destroy_gvar1() automatically
   * for us when each thread exits.
   */
#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[NTHREADS];
  unsigned int  args[NTHREADS][2];
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif

  /* Load up the input arguments for each child thread */
  for (i = 0; i < NTHREADS; i++)
  {
    args[i][0] = (i + 1);
    args[i][1] = NTASKS;
  }

  /* Create thread-specific data key: gvar1 and specify destructor function */
  ret = pthread_key_create(&gvar1, (void *)destroy_gvar1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-1);
  }
  
  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < NTHREADS; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-2);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < NTHREADS; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  /* Delete thread-specific data key: gvar1 */
  ret = pthread_key_delete(gvar1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to delete thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }

  pthread_exit((void *)0);
}
