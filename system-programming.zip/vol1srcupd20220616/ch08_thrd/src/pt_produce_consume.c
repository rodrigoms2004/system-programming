/*
 * Solving the Producer-Consumer problem using one pthread condition variable
 * (and mutex).
 * Copyright (c) 2014, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define  DEFBUFSZ      2    /* Maximum # of buffers to hold resources */
#define  DEFNTHREADS   3    /* default number threads of each type to run */
#define  MAXNTHREADS  12    /* max. number threads of each type allowed */
#define  DEFNTASKS     5    /* number of tasks to perform for each thread */
#define  MILLISECS25  25000 /*  25 milliseconds */

/*
 * Global data structures shared by all threads.
 */
pthread_cond_t   convar = PTHREAD_COND_INITIALIZER;     /* the condition variable */
pthread_mutex_t  mutex;            /* the associated mutex */
unsigned int     product_count=0;  /* the number of resources available */

void random_sleep(unsigned int maxusec);

/* 
 * The producer thread.
 */
int producer_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  unsigned int  maxbufs;
  int    ret = 0;

  /* Extract arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
    maxbufs = argp[2];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Producer: myid=%u ntasks=%u maxbufs=%u\n",
    myid, ntasks, maxbufs);

  /* Do my job */
  while (ntasks > 0)
  {
    /* Lock the mutex */
    ret = pthread_mutex_lock(&mutex);
    if (ret != 0)
    {
      fprintf(stderr, "Producer %3u failed to lock the mutex, ret=%u\n",
        myid, ret);
#ifdef SUN64
      ret = (-2);
      pthread_exit((void *)&ret);
#else
      pthread_exit((void *)-2);
#endif
    }
    fprintf(stdout, "Producer %3u locked the mutex\n", myid);

    /* Wait for buffers to become available */
    while (product_count >= maxbufs)
      pthread_cond_wait(&convar, &mutex);
 
    /* Do whatever it takes to produce the resource */

    /* Produce and add one resource to the pool */
    random_sleep(MILLISECS25);  /* It takes time to produce. */
    product_count = product_count + 1;
    fprintf(stdout, "Producer %3u added one resource, product_count=%u\n",
      myid, product_count);

    /* Without this, the awaiting consumer threads waiting on the same
     * condition variable won't get waken up even though the mutex
     * is properly released and re-acquired by the system automatically.
     */
    pthread_cond_signal(&convar);

    /* Unlock the mutex */
    ret = pthread_mutex_unlock(&mutex);
    if (ret != 0)
    {
      fprintf(stderr, "Producer %3u failed to unlock the mutex, ret=%u\n",
        myid, ret);
#ifdef SUN64
      ret = (-3);
      pthread_exit((void *)&ret);
#else
      pthread_exit((void *)-3);
#endif
    }
    fprintf(stdout, "Producer %3u unlocked the mutex\n", myid);

    /* Reduce my task count by one */
    ntasks = ntasks - 1;

  }  /* while */

#ifdef SUN64
  ret = 0;
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

/*
 * The consumer thread.
 */
int consumer_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  unsigned int  maxbufs;
  int    ret = 0;

  /* Extract arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
    maxbufs = argp[2];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)-1);
#endif

  fprintf(stdout, "Consumer: myid=%u ntasks=%u maxbufs=%u\n",
    myid, ntasks, maxbufs);

  /* Do my job */
  while (ntasks > 0)
  {
    /* Lock the mutex */
    ret = pthread_mutex_lock(&mutex);
    if (ret != 0)
    {
      fprintf(stderr, "Consumer %3u failed to lock the mutex, ret=%u\n",
        myid, ret);
#ifdef SUN64
      ret = (-2);
      pthread_exit((void *)&ret);
#else
      pthread_exit((void *)-2);
#endif
    }
    fprintf(stdout, "Consumer %3u locked the mutex\n", myid);

    /* Wait for resources to become available */
    while (product_count <= 0)
      pthread_cond_wait(&convar, &mutex);
 
    /* Consume and remove one resource from the pool */
    random_sleep(MILLISECS25);  /* It takes time to consume. */
    product_count = product_count - 1;
    fprintf(stdout, "Consumer %3u removed one resource, product_count=%u\n",
      myid, product_count);

    /* Without this, the awaiting producer threads waiting on the same
     * condition variable won't get waken up even though the mutex
     * is properly released and re-acquired by the system automatically.
     */
    pthread_cond_signal(&convar);

    /* Unlock the mutex */
    ret = pthread_mutex_unlock(&mutex);
    if (ret != 0)
    {
      fprintf(stderr, "Consumer %3u failed to unlock the mutex, ret=%u\n",
        myid, ret);
#ifdef SUN64
      ret = (-3);
      pthread_exit((void *)&ret);
#else
      pthread_exit((void *)-3);
#endif
    }
    fprintf(stdout, "Consumer %3u unlocked the mutex\n", myid);

    /* Decrement my task count by one */
    ntasks = ntasks - 1;

    /* Could actually consume the resource here if it takes long */

  }  /* while */

#ifdef SUN64
  ret = 0;
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

int main(int argc, char *argv[])
{
  pthread_t     prthrds[MAXNTHREADS];
  unsigned int  prargs[MAXNTHREADS][3];
  pthread_t     csthrds[MAXNTHREADS];
  unsigned int  csargs[MAXNTHREADS][3];
  int           ret, i;
  int           retval = 0;              /* Each child thread returns an int */
  int           nbufs = DEFBUFSZ;        /* number of total buffers */
  int           nthrds = DEFNTHREADS;    /* number of threads */
  int           ntasks = DEFNTASKS;      /* number of tasks per thread */
  pthread_mutexattr_t  mutexattr;        /* mutex attributes */
#ifdef SUN64
  int           *retvalp = &retval;      /* pointer to returned value */
#endif

  /* Get the number of buffers to use from user */
  if (argc > 1)
  {
    nbufs = atoi(argv[1]);
    if (nbufs <= 0)
      nbufs = DEFBUFSZ;
  }

  /* Get the number of threads to run from user */
  if (argc > 2)
  {
    nthrds = atoi(argv[2]);
    if ((nthrds <= 0) || (nthrds > MAXNTHREADS))
      nthrds = DEFNTHREADS;
  }

  /* Get the number of tasks per thread to perform from user */
  if (argc > 3)
  {
    ntasks = atoi(argv[3]);
    if (ntasks <= 0)
      ntasks = DEFNTASKS;
  }

  fprintf(stdout, "Run %d threads, %u tasks per thread using %u buffers\n",
      nthrds, ntasks, nbufs);

  /* Initialize mutex attributes */
  ret = pthread_mutexattr_init(&mutexattr);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-1);
  }

  /* Initialize the mutex */
  ret = pthread_mutex_init(&mutex, &mutexattr);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex, ret=%d\n", ret);
    pthread_exit((void *)-2);
  }

  /* Load up the input arguments to each child thread */
  for (i = 0; i < nthrds; i++)
  {
    prargs[i][0] = (i + 1);
    csargs[i][0] = (i + 1);
    prargs[i][1] = ntasks;
    csargs[i][1] = ntasks;
    prargs[i][2] = nbufs;
    csargs[i][2] = nbufs;
  }

  /* Create the consumer threads */
  for (i = 0; i < nthrds; i++)
  {
    ret = pthread_create(&csthrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))consumer_thread, (void *)csargs[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the consumer thread %d, ret=%d\n",
        i, ret);
      pthread_exit((void *)-3);
    }
  }

  /* Create the producer threads */
  for (i = 0; i < nthrds; i++)
  {
    ret = pthread_create(&prthrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))producer_thread, (void *)prargs[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the producer thread, ret=%d\n", ret);
      pthread_exit((void *)-4);
    }
  }

  /* Wait for the child threads to finish. */
  for (i = 0; i < nthrds; i++)
  {
#ifdef SUN64
    ret = pthread_join(prthrds[i], (void **)&retvalp);
#else
    ret = pthread_join(prthrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Producer thread %u exited with return value %d\n",
      i, retval);
  }
  for (i = 0; i < nthrds; i++)
  {
#ifdef SUN64
    ret = pthread_join(csthrds[i], (void **)&retvalp);
#else
    ret = pthread_join(csthrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Consumer thread %u exited with return value %d\n",
      i, retval);
  }

  fprintf(stdout, "main(), product_count = %d\n", product_count);

  /* Destroy mutex attributes */
#ifndef HPUX64
  ret = pthread_mutexattr_destroy(&mutexattr);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-5);
  }
#endif

  /* Destroy the mutex */
  ret = pthread_mutex_destroy(&mutex);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex, ret=%d\n", ret);
    pthread_exit((void *)-6);
  }

  pthread_exit((void *)0);
}
