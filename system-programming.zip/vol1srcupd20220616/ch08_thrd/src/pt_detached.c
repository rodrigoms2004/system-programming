/*
 * Creating a detached child thread.
 * Copyright (c) 2014, Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <pthread.h>

/* 
 * The child thread.
 */
void child_thread(void *args)
{
  fprintf(stdout, "Enter the child thread\n");
  fprintf(stdout, "Child thread exiting ...\n");
  pthread_exit((void *)NULL);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t       thrd;
  int             ret;
  pthread_attr_t  attr;  /* thread attributes */

  /* Initialize the pthread attributes */
  ret = pthread_attr_init(&attr);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to init thread attributes, ret=%d\n", ret);
    pthread_exit((void *)-1);
  }

  /* Set up to create a detached thread */
  ret = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to set detach state, ret=%d\n", ret);
    pthread_exit((void *)-2);
  }

  /* Create a detached child thread to run the child_thread() function. */
  ret = pthread_create(&thrd, (pthread_attr_t *)&attr,
        (void *(*)(void *))child_thread, (void *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create the child thread\n");
    pthread_exit((void *)-3);
  }

  /* Destroy the pthread attributes */
  ret = pthread_attr_destroy(&attr);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy thread attributes, ret=%d\n", ret);
    pthread_exit((void *)-4);
  }

  fprintf(stdout, "Main thread exiting ...\n");

  /*
   * Make sure you don't call return() or exit() here to terminate the main
   * thread. If you do, it will terminate the entire process including the
   * child thread even if the child thread may not even get a chance to run yet.
   */
  pthread_exit((void *)0);
}
