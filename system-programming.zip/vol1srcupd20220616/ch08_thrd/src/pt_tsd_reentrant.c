/*
 * Thread-specific data in pthread.
 * Using thread-specific data to prevent a thread from deadlock itself.
 * Remember if a thread has obtained a lock or not in a thread-specific data
 * and check that so that a thread won't deadlock itself in trying to get same
 * lock and the function becomes reentrantable.
 * To see self-deadlock, recompile with SHOWDEADLOCK defined using
 *  $ cc -DSHOWDEADLOCK pt_tsd_reentrant.c -o pt_tsd_reentrant -lpthread
 * Copyright (c) 2014, 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define  MAXNTHREADS  10      /* maximum number of threads */
#define  DEFNTHREADS  2       /* default number of threads */
#define  MAXTASKS     3000    /* maximum number of tasks */
#define  DEFNTASKS    5       /* default number of tasks */

pthread_key_t      haslock;   /* thread-specific data (the key) */
pthread_mutex_t    mutex1;    /* global mutex shared by all threads */

int recursive(unsigned int myid, unsigned int cnt)
{
  struct timespec  slptm;
  int    ret;
  unsigned int  *valptr;     /* pointer returned by pthread_getspecific() */
  unsigned int  ihaslock;    /* value of thread-specific key */
  unsigned int  myval;

  slptm.tv_sec = 0;
  slptm.tv_nsec = 500000000;  /* 5/10 second */

  if (cnt <= 0)
    return(0);

  /* To avoid deadlocking self, take the lock only if myself has not done so */
  valptr =  pthread_getspecific(haslock);
  if (valptr == NULL)
  {
    fprintf(stderr, "recursive(): pthread_getspecific() returned NULL\n");
    return(-3);
  }
  ihaslock = (*(unsigned int *)valptr);
#ifndef SHOWDEADLOCK
  if (ihaslock == 0)
  {
#endif
    ret = pthread_mutex_lock(&mutex1);
    if (ret != 0)
    {
      fprintf(stderr, "recursive(): thread %u failed to lock the mutex,"
        " ret=%d\n", myid, ret);
      return(-4);
    }

    /* Remember in thread-specific data that I have the lock already */
    myval = 1;
    ret = pthread_setspecific(haslock, (void *)&myval);
    if (ret != 0)
    {
      fprintf(stderr, "recursive(): thread %u pthread_setspecific() failed,"
        " ret=%d\n", myid, ret);
      return(-5);
    }
#ifndef SHOWDEADLOCK
  }
#endif

  /* Do some work. Here we do nothing but sleep and then call ourselves. */
  fprintf(stdout, "Thread %u in recursive(), cnt=%u\n", myid, cnt);
  nanosleep(&slptm, (struct timespec *)NULL);
  ret = recursive(myid, --cnt);

  /* Release the lock and clear our memory */
#ifndef SHOWDEADLOCK
  if (ihaslock == 0)
  {
#endif
    ret = pthread_mutex_unlock(&mutex1);
    if (ret != 0)
    {
      fprintf(stderr, "recursive(): thread %u failed to unlock the mutex,"
        " ret=%d\n", myid, ret);
      return(-6);
    }
    /* Reset the value in thread specific data */
    myval = 0;
    ret = pthread_setspecific(haslock, (void *)&myval);
    if (ret != 0)
    {
      fprintf(stderr, "recursive(): thread %u pthread_setspecific() failed,"
        " ret=%d\n", myid, ret);
      return(-7);
    }
#ifndef SHOWDEADLOCK
  }
#endif
  return(0);
}

/* The worker thread */
int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;        /* my id */
  unsigned int  ntasks;      /* number of tasks to perform */
  int           i, ret=0;
  unsigned int  myval = 0;   /* initial value for thread-specific data */

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "worker_thread(): myid=%u ntasks=%u\n", myid, ntasks); 

  /* Initialize thread specific data */
  ret = pthread_setspecific(haslock, (void *)&myval);
  if (ret != 0)
  {
    fprintf(stderr, "worker_thread(): pthread_setspecific() failed, ret=%d\n",
      ret);
#ifdef SUN64
    ret = (-2);
    pthread_exit((void *)&ret);
#else
    pthread_exit((void *)(-2));
#endif
  }

  /* Do the work */
  ret = recursive(myid, ntasks);

#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)ret);
#endif
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  pthread_t     thrds[MAXNTHREADS];
  unsigned int  args[MAXNTHREADS][2];
  int           ret, i;
  int           retval = 0;  /* each child thread returns an int */
#ifdef SUN64
  int           *retvalp = &retval;         /* pointer to returned value */
#endif
  int           nthreads = DEFNTHREADS;     /* default # of threads */
  int           ntasks = DEFNTASKS;         /* default # of tasks */
  pthread_mutexattr_t  mutexattr1;  /* mutex attributes */

  /* Get number of threads and tasks from user */
  if (argc > 1)
  {
    nthreads = atoi(argv[1]);
    if (nthreads < 0 || nthreads > MAXNTHREADS)
      nthreads = DEFNTHREADS;
  }
  if (argc > 2)
  {
    ntasks = atoi(argv[2]);
    if (ntasks < 0 || ntasks > MAXTASKS)
      ntasks = DEFNTASKS;
  }

  /* Initialize mutex attributes */
  ret = pthread_mutexattr_init(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-1);
  }

  /* Initialize the mutex */
  ret = pthread_mutex_init(&mutex1, &mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex, ret=%d\n", ret);
    pthread_exit((void *)-2);
  }

  /* Load up the input arguments for each child thread */
  for (i = 0; i < nthreads; i++)
  {
    args[i][0] = (i + 1);
    args[i][1] = ntasks;
  }

  /* Create thread-specific data key: haslock */
  ret = pthread_key_create(&haslock, (void *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to create thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }
  
  /* Create new threads to run the worker_thread() function and pass in args */
  for (i = 0; i < nthreads; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread, ret=%d\n", ret);
      pthread_exit((void *)-4);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthreads; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", (i+1), retval);
  }

  /* Delete thread-specific data key: haslock */
  ret = pthread_key_delete(haslock);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to delete thread-specific data key, ret=%d\n", ret);
    pthread_exit((void *)-5);
  }

  /* Destroy mutex attributes */
#ifndef HPUX64
  ret = pthread_mutexattr_destroy(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-6);
  }
#endif

  /* Destroy the mutex */
  ret = pthread_mutex_destroy(&mutex1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex, ret=%d\n", ret);
    pthread_exit((void *)-7);
  }

  pthread_exit((void *)0);
}
