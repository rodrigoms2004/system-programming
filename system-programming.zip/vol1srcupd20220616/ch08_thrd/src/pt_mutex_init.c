/*
 * Initialize a mutex with specialized mutex attributes.
 * As of this writing, AIX and HPUX do not support mutex robust attribute.
 * Copyright (c) 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <pthread.h>

void prt_mutex_attrs(pthread_mutexattr_t *attr)
{
  int    type = 0;      /* mutex type attribute */
  int    pshared = 0;   /* mutex pshared attribute */
  int    prot = 0;      /* mutex protocol attribute */
  int    pric = 0;      /* mutex prioceiling attribute */
  int    robust = 0;    /* mutex robust attribute */
  int    ret;

  if (attr == NULL) return;

  ret = pthread_mutexattr_gettype(attr, &type);
  fprintf(stdout, " mutex type attribute = %s\n",
      (type == PTHREAD_MUTEX_NORMAL) ? "PTHREAD_MUTEX_NORMAL" :
      (type == PTHREAD_MUTEX_RECURSIVE) ? "PTHREAD_MUTEX_RECURSIVE" :
      (type == PTHREAD_MUTEX_ERRORCHECK) ? "PTHREAD_MUTEX_ERRORCHECK" :
      (type == PTHREAD_MUTEX_DEFAULT) ? "PTHREAD_MUTEX_DEFAULT" :
      "Unknown");
  ret = pthread_mutexattr_getpshared(attr, &pshared);
  fprintf(stdout, " mutex pshared attribute = %s\n",
      (pshared == PTHREAD_PROCESS_PRIVATE) ? "PTHREAD_PROCESS_PRIVATE" :
      (pshared == PTHREAD_PROCESS_SHARED ) ? "PTHREAD_PROCESS_SHARED " :
      "Unknown");
  ret = pthread_mutexattr_getprotocol(attr, &prot);
  fprintf(stdout, " mutex protocol attribute = %s\n",
      (prot == PTHREAD_PRIO_NONE) ? "PTHREAD_PRIO_NONE" :
      (prot == PTHREAD_PRIO_INHERIT) ? "PTHREAD_PRIO_INHERIT" :
      (prot == PTHREAD_PRIO_PROTECT ) ? "PTHREAD_PRIO_PROTECT " :
      "Unknown");

  ret = pthread_mutexattr_getprioceiling(attr, &pric);
  fprintf(stdout, " mutex prioceiling attribute = %d\n", pric);

#ifndef NOROBUST
  ret = pthread_mutexattr_getrobust(attr, &robust);
  fprintf(stdout, " mutex robust attribute = %s\n",
      (robust == PTHREAD_MUTEX_STALLED) ? "PTHREAD_MUTEX_STALLED" :
      (robust == PTHREAD_MUTEX_ROBUST) ? "PTHREAD_MUTEX_ROBUST" :
      "Unknown");
#endif
}

pthread_mutex_t      mutex1;     /* global mutex shared by all threads */

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int           ret;
  pthread_mutexattr_t  mutexattr1;  /* mutex attributes */
  int           pshared;            /* mutex pshared attribute */
  int           prot;               /* mutex protocol attribute */

  /* Initialize mutex attributes */
  ret = pthread_mutexattr_init(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-1);
  }

  /* Set mutex pshared attribute to be PTHREAD_PROCESS_SHARED */
  pshared = PTHREAD_PROCESS_SHARED;
  ret = pthread_mutexattr_setpshared(&mutexattr1, pshared);
  if (ret != 0)
    fprintf(stderr, "failed to set mutex pshared attribute, ret=%d\n", ret);

  /* Set mutex protocol attribute to be PTHREAD_PRIO_INHERIT */
  prot = PTHREAD_PRIO_INHERIT;
  ret = pthread_mutexattr_setprotocol(&mutexattr1, prot);
  if (ret != 0)
    fprintf(stderr, "failed to set mutex protocol attribute, ret=%d\n", ret);

  /* Initialize the mutex */
  ret = pthread_mutex_init(&mutex1, &mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to initialize mutex, ret=%d\n", ret);
    pthread_exit((void *)-2);
  }
  fprintf(stdout, "The mutex initialization was successful!\n");

  /* Print mutex attributes */
  prt_mutex_attrs(&mutexattr1);

  /* Create the child threads to do the work here */

  /* Join the child threads */

  /* Destroy mutex attributes */
  ret = pthread_mutexattr_destroy(&mutexattr1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex attributes, ret=%d\n", ret);
    pthread_exit((void *)-3);
  }

  /* Destroy the mutex */
  ret = pthread_mutex_destroy(&mutex1);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to destroy mutex, ret=%d\n", ret);
    pthread_exit((void *)-4);
  }

  pthread_exit((void *)0);
}

