These are example programs in the book
"System Programming vol I by Jin-Jwei Chen".
