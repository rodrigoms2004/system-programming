/*
 * Read from terminal.
 * Enables nonblocking I/O using the fcntl() function.
 * By default, blocking I/O is used when reading from terminal.
 * Pass in an argument to turn on nonblocking I/O.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* read() */
#include <sys/ioctl.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

#define  BUFSZ  256

int main(int argc, char *argv[])
{
  int   ret;
  char  buf[BUFSZ];
  ssize_t  nbytes;
  int   fd=0;    /* standard input (stdin) is the default file descriptor */
  int   flags;
  int   nbio = 0;  /* by default, nonblocking I/O is off */

  /* User can turn on nonblocking I/O by passing in an argument */
  if (argc > 1)
  {
    nbio = 1;
    fprintf(stdout, "Nonblocking I/O is on\n");
  }
  else
    fprintf(stdout, "Nonblocking I/O is off\n");

  fprintf(stdout, "Enter a message:\n");

  /* Enables nonblocking I/O if the user says so */
  if (nbio)
  {
    /* Use fcntl() to turn on nonblocking I/O */
    flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1)
    {
      fprintf(stderr, "fcntl(F_GETFL) failed, errno=%d\n", errno);
      return(-1);
    }

    flags = flags | O_NONBLOCK;  /* turn on nonblocking I/O */

    ret = fcntl(fd, F_SETFL, flags);
    if (ret == -1)
    {
      fprintf(stderr, "fcntl(F_SETFL) failed, errno=%d\n", errno);
      return(-2);
    }
  }

  /* Read the input message */
  nbytes = read(fd, buf, BUFSZ);
  buf[nbytes] = '\0';
  fprintf(stdout, "\nJust read this from terminal:\n%s\n", buf);

  return(0);
}
