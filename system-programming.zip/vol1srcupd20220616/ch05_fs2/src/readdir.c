/*
 * This program does a 'ls -l' type of operation on a directory
 * by using the opendir(), readdir() and other functions.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <dirent.h>      /* readdir(3) */
#include <sys/stat.h>    /* stat(), fstat() */
#include <fcntl.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <locale.h>
#include <stdint.h>
#include <langinfo.h>
#include <string.h>      /* memset() */
#include <unistd.h>      /* chdir() */

#define  DEFFAULT_DIR  "."    /* to get status info of this directory */
#define  PERMBUFSZ      32    /* length of permission string buffer */
#define  DATEBUFSZ      64    /* length of date string buffer */

/*
 * Convert the permission value of a file/directory entry from type mode_t
 * to string.
 * INPUT:
 *   mode - permission value in type of mode_t
 *   permstr - buffer to hold the output permission string
 *   len - length, in bytes, of the output string buffer
 * RETURN: 0 for success, EINVAL for failure.
 */
int get_permstr(mode_t mode, char *permstr, unsigned int len)
{
  char filetype = '?';  /* Set type of file entry to unknown */

  /* Return if we get invalid input arguments */
  if (permstr == NULL || len < 15)
    return(EINVAL);

  /* Determine the type of the file entry */
  if (S_ISDIR(mode))  filetype = 'd';    /* directory */
  if (S_ISREG(mode))  filetype = '-';    /* regular file */
  if (S_ISLNK(mode))  filetype = 'l';    /* symbolic link */
  if (S_ISCHR(mode))  filetype = 'c';    /* character device */
  if (S_ISBLK(mode))  filetype = 'b';    /* block device */
  if (S_ISFIFO(mode)) filetype = '|';    /* FIFO */

  /* Convert the read-write-execute permission bits */
  sprintf(permstr, "%c%c%c%c%c%c%c%c%c%c %c%c%c", filetype,
    mode & S_IRUSR ? 'r' : '-',
    mode & S_IWUSR ? 'w' : '-',
    mode & S_IXUSR ? 'x' : '-',
    mode & S_IRGRP ? 'r' : '-',
    mode & S_IWGRP ? 'w' : '-',
    mode & S_IXGRP ? 'x' : '-',
    mode & S_IROTH ? 'r' : '-',
    mode & S_IWOTH ? 'w' : '-',
    mode & S_IXOTH ? 'x' : '-',
    mode & S_ISUID ? 'U' : '-',
    mode & S_ISGID ? 'G' : '-',
    mode & S_ISVTX ? 'S' : '-');

  return(0);
}

int list_dir_long(char *dirname)
{
  DIR    *thisdir;                /* directory stream pointer */
  char   date[DATEBUFSZ];         /* buffer for date string */
  char   permstr[PERMBUFSZ];      /* buffer for permission string */
  struct dirent *dp;              /* directory entry pointer */
  struct stat   statinfo;         /* status information */
  struct passwd *pwd;             /* password file entry */
  struct group  *grp;             /* group file entry */
  struct tm     *tm;              /* pointer to broken-down time structure */
  int           ret;

  if (dirname == NULL)
    return(EINVAL);

  /* Open the directory */
  errno = 0;
  thisdir = opendir(dirname);

  if (thisdir == NULL)
  {
    fprintf(stderr, "opendir() failed, errno=%d\n", errno);
    return(errno);
  }

  /* Change to that directory */
  ret = chdir(dirname);
  if (ret < 0)
  {
    fprintf(stderr, "chdir() failed, errno=%d\n", errno);
    return(errno);
  }

  /* Loop through all the entries that exist in the directory */
  errno = 0;
  while((dp = readdir(thisdir)) != NULL)
  {
    /* Get information of the next entry. Stop if we're done. */
    memset(&statinfo, 0, sizeof(statinfo));
    if (stat(dp->d_name, &statinfo) == -1)
    {
      fprintf(stderr, "stat() failed, errno=%d\n", errno);
      break;
    }

    /* Print the type, permissions, and number of links */
    memset(permstr, 0, PERMBUFSZ);
    if ((get_permstr(statinfo.st_mode, permstr, PERMBUFSZ)) == 0)
      fprintf(stdout, "%10.10s", permstr);
    fprintf(stdout, "%4d", statinfo.st_nlink);

    /* Print the owner name */
    if ((pwd = getpwuid(statinfo.st_uid)) != NULL)
      fprintf(stdout, " %-8.8s", pwd->pw_name);
    else
      fprintf(stdout, " %-8d", statinfo.st_uid);

    /* Print the group name */
    if ((grp = getgrgid(statinfo.st_gid)) != NULL)
      fprintf(stdout, " %-8.8s", grp->gr_name);
    else
      fprintf(stdout, " %-8d", statinfo.st_gid);

    /* Print the size of the file */
    fprintf(stdout, " %10jd", (intmax_t)statinfo.st_size);

    /* Convert the time to date in string */
    tm = localtime(&statinfo.st_mtime);
    strftime(date, sizeof(date), nl_langinfo(D_T_FMT), tm);

    /* Print the date/time string and entry name */
    fprintf(stdout, " %s %s\n", date, dp->d_name);
    errno = 0;
  }  /* while */

  closedir(thisdir);
  return(errno);
}

/*
 * List the directory specified or the current directory in long form.
 */
int main(int argc, char *argv[])
{
  int    ret = 0;
  char   *dirname = DEFFAULT_DIR;  /* directory to operate on */

  if (argc > 1)
    dirname = argv[1];

  ret = list_dir_long(dirname);

  return(ret);
}
