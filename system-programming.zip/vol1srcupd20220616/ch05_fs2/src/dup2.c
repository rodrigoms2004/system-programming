/*
 * dup2() function
 * Open a data file, read the first few bytes from it.
 * Then duplicate the file descriptor using dup2() and read the next few bytes.
 * Copyright (c) 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>    /* dup() and dup2() */

#define BYTECNT1  10
#define BYTECNT2  26
#define BUFLEN    128

int main(int argc, char *argv[])
{
  int    ret;
  int    fd, fd2, newfd;     /* file descriptors */
  char   buf[BUFLEN] = "";
  char   *fname;             /* name of input data file */

  /* Expect to get the file name from user */
  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Open the data file for read only. */
  fd = open(fname, O_RDONLY, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Read the first few bytes from the file. */
  ret = read(fd, buf, BYTECNT1);
  if (ret > 0 && ret < BUFLEN)
    buf[ret] = '\0';
  else
  {
    fprintf(stderr, "read() failed, ret = %d\n", ret);
    return(-1);
  }
  fprintf(stdout, "The first %u bytes in the dada file are %s.\n", BYTECNT1, buf);

  /* Duplicate the file descriptor using dup2() */
  fd2 = 6;
  newfd = dup2(fd, fd2);
  fprintf(stdout, "dup2() returned newfd=%d\n", newfd);

  /* Read the next few bytes */
  ret = read(fd, buf, BYTECNT2);
  if (ret > 0 && ret < BUFLEN)
    buf[ret] = '\0';
  else
  {
    fprintf(stderr, "read() failed, ret = %d\n", ret);
    return(-1);
  }
  fprintf(stdout, "The next %u bytes in the dada file are %s.\n", BYTECNT2, buf);

  close(newfd);
  return(0);
}
