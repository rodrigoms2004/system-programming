/*
 * access()
 * Test if a file system entry (a directory or file) exists and return
 * 1 if it does and 0 if not.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
  int   ret;
  char  *pathname = NULL;

  /* Get the file system entry supplied by the user if there is one */
  if (argc == 2)
    pathname = argv[1];
  else
  {
    fprintf(stdout, "Usage: %s file_or_directory_name\n", argv[0]);
    return(-1);
  }
 
  /* Test if the file system entry exists */
  ret = access(pathname, F_OK);
  if (ret == -1)
  {
    fprintf(stderr, "access() failed, errno=%d\n", errno);
    if (errno == ENOENT)
    {
      fprintf(stdout, "The file system entry %s does not exist.\n", pathname);
      /* return 0 if entry does not exist */
      return(0);
    }
    else
      return(-1);
  }

  /* return 1 if entry does not exist */
  fprintf(stdout, "The file system entry %s exists.\n", pathname);
  return(1);
}
