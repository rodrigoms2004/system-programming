/*
 * chown()
 * Change the group ownership of a file system entry.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>      /* chown(), stat(), fstat() */
#include <stdlib.h>      /* system() */
#include <string.h>      /* memset() */

#define  MYFILE  "./mychownfile"    /* default file name */

int main(int argc, char *argv[])
{
  int    ret;
  char   *pathname;      /* file/directory name */
  uid_t  newuid = -1;    /* no intention to change the user ID */
  gid_t  newgid;         /* ID of the new group */
  gid_t  *supgids=NULL;  /* array of IDs of supplementary groups */
  size_t  ngrps;         /* number of supplementary groups */
  char   mycmd[256];     /* buffer of a command to be executed */

  /* Get the file/directory name provided by the user, if there is one. */
  if (argc > 1)
    pathname = argv[1];
  else
    pathname = MYFILE;

  /* Get the number of supplementary groups. In some implementation
     this number may also include the effective group ID as well. */
  ngrps = getgroups(0, supgids);
  if (ngrps == -1)
  {
    fprintf(stderr, "getgroups() failed, errno=%d\n", errno);
    return(-1);
  }

  if (ngrps >= 1)
  {
    supgids = (gid_t *)malloc(sizeof(gid_t) * ngrps);
    if (supgids == NULL)
    {
      fprintf(stderr, "malloc() failed, errno=%d\n", errno);
      return(-2);
    }
    memset((void *)supgids, 0, (sizeof(gid_t) * ngrps));

    /* Get the IDs of the supplementary groups. Note that in some implementation
       the effective group ID may also be returned in the output list. */
    ret = getgroups(ngrps, supgids);
    if (ret == -1)
    {
      fprintf(stderr, "getgroups() failed, errno=%d\n", errno);
      return(-3);
    }

    /* Pick the second supplementary group if there is one */
    if (ngrps >= 2)
      newgid = supgids[1];
    else
      newgid = supgids[0];
  }
  else
  {
    /* Use the effective group ID if there is no supplementary group ID */
    newgid = getegid();
  }

  /* List the current user and group ownership before chown() */
  sprintf(mycmd, "ls -l %s", pathname);
  ret = system(mycmd);
  if (ret == -1)
  {
    fprintf(stderr, "system() failed, errno=%d\n", errno);
    if (supgids != NULL)
      free(supgids);
    return(-4);
  }

  /* Change the ownership of user and group */
  ret = chown(pathname, newuid, newgid);
  if (ret == -1)
  {
    fprintf(stderr, "chown() failed, errno=%d\n", errno);
    if (supgids != NULL)
      free(supgids);
    return(-5);
  }

  /* List the current user and group ownership after chown() */
  ret = system(mycmd);
  if (ret == -1)
  {
    fprintf(stderr, "system() failed, errno=%d\n", errno);
    if (supgids != NULL)
      free(supgids);
    return(-6);
  }

  /* Free the memory that we have allocated */
  if (supgids != NULL)
    free(supgids);

  return(0);
}
