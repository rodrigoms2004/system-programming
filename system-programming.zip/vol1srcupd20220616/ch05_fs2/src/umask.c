/*
 * umask(mode)
 *  The  parameter mode to umask() specifies the permissions to use.
 *  It is modified by the process' umask in the usual way: the permissions
 *  of the created directory or file are (mode & ~umask & 0777).
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define  UMASK_FILE  "./umask_file" 
#define  UMASK_DIR   "./umask_dir" 

int main(int argc, char *argv[])
{
  int   ret;
  int   fd;
  mode_t  newmask = 026;
  mode_t  oldmask;
  mode_t  mode1=0644, mode2=0755;

  
  /* Set new mask */
  oldmask = umask(newmask);
  fprintf(stdout, "old mask=%o new mask=%o\n", oldmask, newmask);

  /* Create a new file */
  fd = open(UMASK_FILE, O_CREAT|O_WRONLY, mode1);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-1);
  }
  close(fd);

  /* Create a new directory */
  ret = mkdir(UMASK_DIR, mode2);
  if (ret == -1)
  {
    fprintf(stderr, "mkdir() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}
