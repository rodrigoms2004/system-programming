/*
 * Obtain information about a file using stat() and fstat() function.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>      /* stat(), fstat() */
#include <string.h>      /* memset() */
#include <sys/stat.h>
#include <fcntl.h>       /* open() */
#include <time.h>        /* localtime() */
#include <langinfo.h>    /* nl_langinfo() */

#define  MYFILE  "./myfile"    /* default file name */
#define  DATE_BUFSZ    64      /* size of buffer for date string */
/*
 * Get localized date string.
 * This function converts a time from type time_t to a date string.
 * The input time is a value of type time_t representing calendar time.
 * The output is string of date and time in the following format: 
 *   Fri Apr  4 13:20:12 2014
 */
int cvt_time_to_date(time_t *time, char *date, unsigned int len)
{
  size_t       nchars;
  struct tm    *tm;

  if (time == NULL || date == NULL || len <= 0)
    return(-4);

  /* Convert the calendar time to a localized broken-down time */
  tm = localtime(time);

  /* Format the broken-down time tm */
  memset(date, 0, len);
  nchars = strftime(date, len, nl_langinfo(D_T_FMT), tm);
  if (nchars == 0)
    return(-5);
  else
    return(0);
}

int main(int argc, char *argv[])
{
  int  ret;
  struct stat  finfo;     /* information about a file */
  char         *fname;    /* file name */
  int          fd;        /* file descriptor of the opened file */
  char         date[DATE_BUFSZ];

  /* Get the file name from the user, if any */
  if (argc > 1)
    fname = argv[1];
  else
    fname = MYFILE;

  /* Obtain information about the file using stat() */
  ret = stat(fname, &finfo);
  if (ret != 0)
  {
    fprintf(stderr, "stat() failed, errno=%d\n", errno);
    return(-1);
  }

  fprintf(stdout, "Information about file %s obtained via stat():\n", fname);
  fprintf(stdout, "device ID = %u\n", finfo.st_dev);
  fprintf(stdout, "inode number = %lu\n", finfo.st_ino);
  fprintf(stdout, "access mode = o%o\n", finfo.st_mode);
  fprintf(stdout, "number of hard links = %u\n", finfo.st_nlink);
  fprintf(stdout, "owner's user ID = %u\n", finfo.st_uid);
  fprintf(stdout, "owner's group ID = %u\n", finfo.st_gid);
  fprintf(stdout, "device ID (if special file)= %u\n", finfo.st_rdev);
  fprintf(stdout, "total size in bytes = %ld\n", finfo.st_size);
  fprintf(stdout, "filesystem block size = %u\n", finfo.st_blksize);
  fprintf(stdout, "number of blocks allocated = %ld\n", finfo.st_blocks);
  fprintf(stdout, "time of last access = %ld\n", finfo.st_atime);
  ret = cvt_time_to_date(&finfo.st_atime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last access = %s\n", date);
  fprintf(stdout, "time of last modification = %ld\n", finfo.st_mtime);
  ret = cvt_time_to_date(&finfo.st_mtime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last modification = %s\n", date);
  fprintf(stdout, "time of last status change = %ld\n", finfo.st_ctime);
  ret = cvt_time_to_date(&finfo.st_ctime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last status change = %s\n", date);

  /* Need to open the file first when using fstat() */
  fd = open(fname, O_RDONLY);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Obtain information about the file using fstat() */
  memset(&finfo, 0, sizeof(finfo));
  ret = fstat(fd, &finfo);
  if (ret != 0)
  {
    fprintf(stderr, "fstat() failed, errno=%d\n", errno);
    return(-3);
  }

  fprintf(stdout, "\nInformation about file %s obtained via fstat():\n", fname);
  fprintf(stdout, "device ID = %u\n", finfo.st_dev);
  fprintf(stdout, "inode number = %lu\n", finfo.st_ino);
  fprintf(stdout, "access mode = o%o\n", finfo.st_mode);
  fprintf(stdout, "number of hard links = %u\n", finfo.st_nlink);
  fprintf(stdout, "owner's user ID = %u\n", finfo.st_uid);
  fprintf(stdout, "owner's group ID = %u\n", finfo.st_gid);
  fprintf(stdout, "device ID (if special file)= %u\n", finfo.st_rdev);
  fprintf(stdout, "total size in bytes = %ld\n", finfo.st_size);
  fprintf(stdout, "filesystem block size = %u\n", finfo.st_blksize);
  fprintf(stdout, "number of blocks allocated = %ld\n", finfo.st_blocks);
  fprintf(stdout, "time of last access = %ld\n", finfo.st_atime);
  ret = cvt_time_to_date(&finfo.st_atime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last access = %s\n", date);
  fprintf(stdout, "time of last modification = %ld\n", finfo.st_mtime);
  ret = cvt_time_to_date(&finfo.st_mtime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last modification = %s\n", date);
  fprintf(stdout, "time of last status change = %ld\n", finfo.st_ctime);
  ret = cvt_time_to_date(&finfo.st_ctime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last status change = %s\n", date);

  return(0);
}
