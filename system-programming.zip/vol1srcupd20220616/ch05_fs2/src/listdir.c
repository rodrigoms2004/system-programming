/*
 * List directory.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

/*
 * List the files and directories in a directory.
 */
int list_dir(const char *dirname)
{
  DIR *dirp;
  struct dirent *dp;

  /* Open the directory */
  if ((dirp = opendir(dirname)) == NULL)
  {
    fprintf(stderr, "Couldn't open the directory: %s, errno=%d\n",
      dirname, errno);
    return(errno);
  }

  /* Loop through reading each element in the directory */
  do
  {
    errno = 0;
    if ((dp = readdir(dirp)) != NULL)
    {
      printf("%s\n", dp->d_name);
    }
  } while (dp != NULL);

  (void) closedir(dirp);
  return(errno);
}

int main(int argc, char *argv[])
{
  int ret;

  /* List the directory specified or the current directory otherwise */
  if (argc > 1)
    ret = list_dir(argv[1]);
  else
    ret = list_dir(".");

  return (ret);
}
