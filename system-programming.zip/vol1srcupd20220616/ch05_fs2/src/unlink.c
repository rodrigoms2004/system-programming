/*
 * Remove a file, symlink or hard link using the unlink() function.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* unlink() */

int main(int argc, char *argv[])
{
  int      ret;

  /* Get the file or link name */
  if (argc <= 1)
  {
    fprintf(stdout, "Usage: %s pathname\n", argv[0]);
    return(-1);
  }

  /* Remove the file or link */
  ret = unlink(argv[1]);
  if (ret == -1)
  {
    fprintf(stderr, "unlink() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}

