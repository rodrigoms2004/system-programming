/*
 * Rename a file, symlink, hard link or directory using the rename() function.
 * Copyright (c) 2013, 2014, 2019  Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>

int main(int argc, char *argv[])
{
  int      ret;
  char     *oldpath, *newpath;

  /* Get the old and new names */
  if (argc <= 2)
  {
    fprintf(stdout, "Usage: %s old_pathname new_pathname\n", argv[0]);
    return(-1);
  }
  oldpath = argv[1];
  newpath = argv[2];

  /* Change the name */
  ret = rename(oldpath, newpath);
  if (ret == -1)
  {
    fprintf(stderr, "rename() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}

