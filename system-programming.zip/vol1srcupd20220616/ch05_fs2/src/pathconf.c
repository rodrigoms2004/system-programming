/*
 * Example Program for pathconf()
 * Get the current values of all configurable limits of a file or directory.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* pathconf() */
#include <limits.h>

#define  MYPATH  "."   /* use current directory */

int main(int argc, char *argv[])
{
  int   ret;
  long  val;

  /* Get the current values of all configurable limits of a file or directory */
  fprintf(stdout, "FILESIZEBITS = %ld\n", pathconf(MYPATH, _PC_FILESIZEBITS));
  fprintf(stdout, "LINK_MAX = %ld\n", pathconf(MYPATH, _PC_LINK_MAX));
  fprintf(stdout, "MAX_CANON = %ld\n", pathconf(MYPATH, _PC_MAX_CANON));
  fprintf(stdout, "MAX_INPUT = %ld\n", pathconf(MYPATH, _PC_MAX_INPUT));
  fprintf(stdout, "NAME_MAX = %ld\n", pathconf(MYPATH, _PC_NAME_MAX));
  fprintf(stdout, "PATH_MAX = %ld\n", pathconf(MYPATH, _PC_PATH_MAX));
  fprintf(stdout, "PIPE_BUF = %ld\n", pathconf(MYPATH, _PC_PIPE_BUF));
  fprintf(stdout, "POSIX2_SYMLINKS = %ld\n", pathconf(MYPATH, _PC_2_SYMLINKS));
  fprintf(stdout, "POSIX_ALLOC_SIZE_MIN = %ld\n", pathconf(MYPATH, _PC_ALLOC_SIZE_MIN));
  fprintf(stdout, "POSIX_REC_INCR_XFER_SIZE = %ld\n", pathconf(MYPATH, _PC_REC_INCR_XFER_SIZE));
  fprintf(stdout, "POSIX_REC_MAX_XFER_SIZE = %ld\n", pathconf(MYPATH, _PC_REC_MAX_XFER_SIZE));
  fprintf(stdout, "POSIX_REC_MIN_XFER_SIZE = %ld\n", pathconf(MYPATH, _PC_REC_MIN_XFER_SIZE));
  fprintf(stdout, "POSIX_REC_XFER_ALIGN = %ld\n", pathconf(MYPATH, _PC_REC_XFER_ALIGN));
  fprintf(stdout, "SYMLINK_MAX = %ld\n", pathconf(MYPATH, _PC_SYMLINK_MAX));
  fprintf(stdout, "_POSIX_CHOWN_RESTRICTED = %ld\n", pathconf(MYPATH, _PC_CHOWN_RESTRICTED));
  fprintf(stdout, "_POSIX_NO_TRUNC = %ld\n", pathconf(MYPATH, _PC_NO_TRUNC));
  fprintf(stdout, "_POSIX_VDISABLE = %ld\n", pathconf(MYPATH, _PC_VDISABLE));
  fprintf(stdout, "_POSIX_ASYNC_IO = %ld\n", pathconf(MYPATH, _PC_ASYNC_IO));
  fprintf(stdout, "_POSIX_PRIO_IO = %ld\n", pathconf(MYPATH, _PC_PRIO_IO));
  fprintf(stdout, "_POSIX_SYNC_IO = %ld\n", pathconf(MYPATH, _PC_SYNC_IO));
/*
  fprintf(stdout, "_POSIX_TIMESTAMP_RESOLUTION = %ld\n", pathconf(MYPATH, _PC_TIMESTAMP_RESOLUTION));
*/
  return(0);
}
