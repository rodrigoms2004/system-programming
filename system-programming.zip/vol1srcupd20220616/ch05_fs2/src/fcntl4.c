/*
 * fcntl() - Leave this one as exercise.
 * Locking a file segment using the fcntl() function.
 * Case 2: File regions locked by two processes don't overlap.
 * This program locks 3rd or 4th block of the file. The first instance of
 * this program (with an argument of 1 or no argument) locks and updates the
 * 3rd block while the second program instance (with an argument of 2) 
 * locks and updates the 4th block. Since the locked regions do not overlap,
 * the two processes should be able to proceed in parallel.
 * Note that the data file fcntl4.data must pre-exist with at least 2048 bytes
 * of data before you run this program.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>      /* fcntl() */
#include <fcntl.h>       /* open() */
#include <sys/stat.h>
#include <string.h>      /* memset() */
#include <stdlib.h>      /* atoi() */

#define  FILENAME  "./fcntl4.data"   /* name of data file to be updated */
#define  OFFSET2LOCK1     (1024)     /* file offset to lock for process 1 */
#define  OFFSET2LOCK2     (1536)     /* file offset to lock for process 2 */
#define  SIZE2LOCK        (512)      /* number of bytes to lock */
#define  MY_UPD_OFFSET1   OFFSET2LOCK1     /* starting offset of my update */
#define  MY_UPD_OFFSET2   OFFSET2LOCK2     /* starting offset of my update */
#define  MY_UPD_SIZE      (512)      /* size of my update */

int main(int argc, char *argv[])
{
  int    fd;
  struct flock  flock;
  char   buf[MY_UPD_SIZE];
  off_t  offset_ret, upd_offset;
  ssize_t  bytes;
  int      ret;
  int      instance = 1;    /* program instance */

  /* Get the program instance number */
  if (argc > 1)
    instance = atoi(argv[1]);
  if (instance < 1 || instance > 2)
  {
    fprintf(stderr, "Usage: %s [ 1 or 2 ]\n", argv[0]);
    return(-1);
  }

  /* Open the file */
  fd = open(FILENAME, O_WRONLY);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Set up the flock structure */
  flock.l_type = F_WRLCK;         /* to obtain a write lock */
  flock.l_whence = SEEK_SET;      /* offset relative to start of file */
  if (instance == 1)
    flock.l_start = OFFSET2LOCK1;    /* relative offset to lock for process 1 */
  else
    flock.l_start = OFFSET2LOCK2;    /* relative offset to lock for process 2 */
  flock.l_len = SIZE2LOCK;        /* number of bytes to lock */
   
  /* Acquire the lock on the file segment. Wait if lock not available */
  ret = fcntl(fd, F_SETLKW, &flock);
  if (ret == -1)
  {
    fprintf(stderr, "fcntl() failed to lock, errno=%d\n", errno);
    close(fd);
    return(-3);
  }

  /* Update one block of the file */
  fprintf(stdout, "Program instance %d got the file lock.\n", instance);
  if (instance == 1)
    upd_offset = MY_UPD_OFFSET1;
  else
    upd_offset = MY_UPD_OFFSET2;
  offset_ret = lseek(fd, upd_offset, SEEK_SET);
  if (offset_ret == -1)
  {
    fprintf(stderr, "lseek() failed, errno=%d\n", errno);
    close(fd);
    return(-4);
  }

  memset((void *)buf, 'A'+(instance-1), MY_UPD_SIZE);
  bytes = write(fd, buf, MY_UPD_SIZE);
  if (bytes == -1)
  {
    fprintf(stderr, "write() failed, errno=%d\n", errno);
    close(fd);
    return(-5);
  }

  fprintf(stdout, "Program instance %d updated one block of the file "
    "but still holding the lock.\n", instance);
  sleep(10);  /* Just to see if this blocks the other process */

  /* Release the file lock */
  fprintf(stdout, "Program instance %d releases the lock.\n", instance);
  flock.l_type = F_UNLCK;       /* to release the lock I acquired */
  ret = fcntl(fd, F_SETLK, &flock);
  if (ret == -1)
  {
    fprintf(stderr, "fcntl() failed to unlock, errno=%d\n", errno);
    close(fd);
    return(-6);
  }
  fprintf(stdout, "Program instance %d exiting.\n", instance);

  /* Close the file and return */
  close(fd);
  return(0);
}
