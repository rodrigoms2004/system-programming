/*
 * chdir(), getcwd() and pathconf().
 * Copyright (c) 2013, 2014, 2019-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* chdir() */
#include <stdlib.h>    /* malloc() */
#include <string.h>    /* memset() */

#define  NEW_WORK_DIR  "/tmp"    /* new working directory */

int main(int argc, char *argv[])
{
  int   ret;
  long  len;
  char  *buf=NULL;  /* buffer to hold the new pathname */
  char  *path;      /* pointer to the new pathname */

  /* Get the maximum length of a pathname */
  len = pathconf(".", _PC_PATH_MAX);
  if (len == (long)(-1))
  {
    fprintf(stderr, "pathconf() failed, errno=%d\n", errno);
    return(-1);
  }

  fprintf(stdout, "Maximum length of a pathname returned by pathconf() = %ld\n",
    len);

  /* Allocate memory for holding the pathname */
  buf = (char *)malloc((size_t)len);
  if (buf == NULL)
  {
    fprintf(stderr, "malloc() failed, errno=%d\n", errno);
    return(-2);
  }
  memset((void *)buf, 0, len);

  /* Get and print the current working directory */
  path = getcwd(buf, len);
  if (path == NULL)
  {
    fprintf(stderr, "getcwd() failed, errno=%d\n", errno);
    free(buf);
    return(-3);
  }
  else
    fprintf(stdout, "Current working directory: %s\n", path);

  /* Change the current working directory of this process */
  fprintf(stdout, "Trying to change current directory to %s\n", NEW_WORK_DIR);
  ret = chdir(NEW_WORK_DIR);
  if (ret == -1)
  {
    fprintf(stderr, "chdir() failed, errno=%d\n", errno);
    return(-4);
  }

  /* Get and print the current working directory */
  path = getcwd(buf, len);
  if (path == NULL)
  {
    fprintf(stderr, "getcwd() failed, errno=%d\n", errno);
    free(buf);
    return(-5);
  }
  else
    fprintf(stdout, "Current working directory: %s\n", path);

  /* Free the dynamically allocated memory and return success */
  free(buf);
  return(0);
}
