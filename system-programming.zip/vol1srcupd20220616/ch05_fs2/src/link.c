/*
 * link()
 * Copyright (c) 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>      /* link() */

int main(int argc, char *argv[])
{
  int    ret;
  char   *filename, *linkname;

  /* Get the names of the two files */
  if (argc > 2)
  {
    filename = argv[1];
    linkname = argv[2];
  }
  else
  {
    fprintf(stderr, "Usage: %s filename linkname\n", argv[0]);
    return(-1);
  }

  /* Create the link */
  ret = link(filename, linkname);
  if (ret == -1)
  {
    fprintf(stderr, "link() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}
