/*
 * Remove an empty directory using the rmdir() function.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* rmdir() */

int main(int argc, char *argv[])
{
  int      ret;

  /* Get the directory name */
  if (argc <= 1)
  {
    fprintf(stdout, "Usage: %s pathname\n", argv[0]);
    return(-1);
  }

  /* Remove the directory */
  ret = rmdir(argv[1]);
  if (ret == -1)
  {
    fprintf(stderr, "rmdir() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}

