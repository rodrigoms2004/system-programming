/*
 * Remove a file, symlink, hard link or directory using the remove() function.
 * Copyright (c) 2013, 2014, 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>

int main(int argc, char *argv[])
{
  int      ret;

  /* Get the name of the file, link, symlink or directory */
  if (argc <= 1)
  {
    fprintf(stdout, "Usage: %s pathname\n", argv[0]);
    return(-1);
  }

  /* Remove the file, link, symlink or directory */
  ret = remove(argv[1]);
  if (ret == -1)
  {
    fprintf(stderr, "remove() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}
