/*
 * A very simple program that writes a message to stdout.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>    /* read(), write() */
#include <string.h>    /* strcpy(), strlen() */

#define  BUFSZ  256
#define  MYMSG  "This is a message coming through pipe."

int main(int argc, char *argv[])
{
  ssize_t    bytes;
  char       buf[BUFSZ];
  size_t     len;

  /* Put the message in the buffer */
  strcpy(buf, MYMSG);
  len = strlen(MYMSG);

  /* Write the message to stdout */
  bytes = write(1, buf, len);
  if (bytes == -1)
  {
    fprintf(stderr, "write() failed, errno=%d\n", errno);
    return(-1);
  }

  return(0);
}

