/*
 * mkfifo()
 * Parent process communicates with child process via a FIFO.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#define  FIFO_PATH  "/tmp/myfifo1" 
#define  BUFSZ      256

int main(int argc, char *argv[])
{
  int   ret;
  int   fd;
  mode_t  mode=0644;
  pid_t   pid;
  char    buf[BUFSZ];
  ssize_t  bytes;
 
  /* Remove the FIFO if it exists */
  ret = unlink(FIFO_PATH);

  /* Create a FIFO as the communication channel between parent and child */
  ret = mkfifo(FIFO_PATH, mode);
  if (ret == -1)
  {
    fprintf(stderr, "mkfifo() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Create a child process */
  pid = fork();
  if (pid == (pid_t) -1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    return(-2);
  }

  if (pid == (pid_t) 0)
  {
    /* This is the child process. Make the child read from the FIFO. */

    /* Open the FIFO for read only */
    fd = open(FIFO_PATH, O_RDONLY, 0644);
    if (fd == -1)
    {
      fprintf(stderr, "Child: open() for read failed, errno=%d\n", errno);
      return(errno);
    }

    /* Read from the FIFO until it's done */
    do
    {
      bytes = read(fd, buf, BUFSZ);
      if (bytes < 0)
      {
        fprintf(stderr, "Child: read() failed, errno=%d\n", errno);
        close(fd);
        return(errno);
      }
      buf[bytes] = '\0';
      if (bytes > 0)
        fprintf(stdout, "Child: just read '%s'\n", buf);
    } while (bytes > 0);

    close(fd);
    return(0);
  }
  else
  {
    /* This is the parent process.  Make the parent write to the FIFO. */
    fd = open(FIFO_PATH, O_WRONLY, 0644);
    if (fd == -1)
    {
      fprintf(stderr, "Parent: open() for write failed, errno=%d\n", errno);
      return(errno);
    }

    /* Write some messages to the FIFO */
    sprintf(buf, "%s", "This is a message 1 from parent.");
    bytes = write(fd, buf, strlen(buf));
    fprintf(stdout, "Parent: just wrote '%s'\n", buf);
    sprintf(buf, "%s", "This is a message 2 from parent.");
    bytes = write(fd, buf, strlen(buf));
    fprintf(stdout, "Parent: just wrote '%s'\n", buf);

    close(fd);

    /* Wait for the child to terminate */
    wait(NULL);
    return(0);
  }

  return(0);
}
