/*
 * access()
 * Test if a file system entry (a directory or file) exists and whether
 * the current user has Read and Write permission to it.
 * Copyright (c) 2013, 2014, 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <unistd.h>

#define  PATHNAME  "./sav1" 

int main(int argc, char *argv[])
{
  int   ret;
  char  *pathname = NULL;

  /* Get the name of the file system entry supplied by the user */
  if (argc <= 1)
  {
    fprintf(stderr, "Usage: %s file_or_directory_name\n", argv[0]);
    return(-1);
  }
  pathname = argv[1];
 
  /* Test if the file system entry exists and is Readable and Writeable */
  ret = access(pathname, F_OK|R_OK|W_OK);
  if (ret == -1)
  {
    fprintf(stderr, "access() failed, errno=%d\n", errno);
    return(-2);
  }

  fprintf(stdout, "The entry %s exists and R/W permissions granted for this"
    " user.\n", pathname);

  return(0);
}

