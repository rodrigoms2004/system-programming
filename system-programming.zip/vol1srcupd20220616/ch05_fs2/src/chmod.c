/*
 * chmod()
 * Change the permissions of a file system entry.
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>      /* stat(), fstat() */

#define  MYFILE  "./mychmodfile"    /* default file name */

int main(int argc, char *argv[])
{
  int  ret;
  struct stat  finfo;        /* information about a file/directory */
  char         *pathname;    /* file/directory name */

  /* Get the file/directory name provided by the user, if there is one. */
  if (argc > 1)
    pathname = argv[1];
  else
    pathname = MYFILE;

  /* Obtain and report the existing permissions */
  ret = stat(pathname, &finfo);
  if (ret != 0)
  {
    fprintf(stderr, "stat() failed, errno=%d\n", errno);
    return(-1);
  }
  fprintf(stdout, "access mode = o%o\n", finfo.st_mode);

  /* Alter the permissions using chmod(). Add write permission for group
     and others. */
  ret = chmod(pathname, finfo.st_mode | S_IWGRP | S_IWOTH);
  if (ret == -1)
  {
    fprintf(stderr, "chmod() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Obtain and report the existing permissions again */
  ret = stat(pathname, &finfo);
  if (ret != 0)
  {
    fprintf(stderr, "stat() failed, errno=%d\n", errno);
    return(-3);
  }
  fprintf(stdout, "access mode = o%o\n", finfo.st_mode);

  return(0);
}
