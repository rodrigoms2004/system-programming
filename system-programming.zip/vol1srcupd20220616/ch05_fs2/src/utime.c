/*
 * Change access and modification times of a file (setting it backward).
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>      /* stat(), fstat() */
#include <string.h>      /* memset() */
#include <sys/stat.h>
#include <fcntl.h>       /* open() */
#include <time.h>        /* localtime() */
#include <langinfo.h>    /* nl_langinfo(), D_T_FMT */
#include <utime.h>       /* utime() */

#define  DATE_BUFSZ    64      /* size of buffer for date string */

/*
 * Get localized date string.
 * This function converts a time from type time_t to a date string.
 * The input time is a value of type time_t representing calendar time.
 * The output is string of date and time in the following format:
 *   Fri Apr  4 13:20:12 2014
 */
int cvt_time_to_date(time_t *time, char *date, unsigned int len)
{
  size_t       nchars;
  struct tm    *tm;

  if (time == NULL || date == NULL || len <= 0)
    return(-4);

  /* Convert the calendar time to a localized broken-down time */
  tm = localtime(time);

  /* Format the broken-down time tm */
  memset(date, 0, len);
  nchars = strftime(date, len, nl_langinfo(D_T_FMT), tm);
  if (nchars == 0)
    return(-5);
  else
    return(0);
}

int main(int argc, char *argv[])
{
  int     ret;
  char    *fname;       /* file name */
  struct  stat  finfo;  /* file information */
  char    date[DATE_BUFSZ];
  struct utimbuf newtime;     /* new access & modification times */

  /* Get the file name from the user */

  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Obtain information about the file using stat() */
  ret = stat(fname, &finfo);
  if (ret != 0)
  {
    fprintf(stderr, "stat() failed, errno=%d\n", errno);
    return(-2);
  }
  fprintf(stdout, "time of last access = %ld\n", finfo.st_atime);
  ret = cvt_time_to_date(&finfo.st_atime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last access = %s\n", date);
  fprintf(stdout, "time of last modification = %ld\n", finfo.st_mtime);
  ret = cvt_time_to_date(&finfo.st_mtime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last modification = %s\n", date);

  /* Set the file's access & modification times backward by one minute */
  newtime.actime = finfo.st_atime -60;
  newtime.modtime = finfo.st_mtime - 60;
  ret = utime(fname, &newtime);
  if (ret < 0)
  {
    fprintf(stderr, "utime() failed, errno=%d\n", errno);
    return(-3);
  }
  fprintf(stdout, "Setting new access and modification times was successful.\n");

  /* Obtain and print the new times of the file */
  ret = stat(fname, &finfo);
  if (ret != 0)
  {
    fprintf(stderr, "stat() failed, errno=%d\n", errno);
    return(-4);
  }
  fprintf(stdout, "time of last access = %ld\n", finfo.st_atime);
  ret = cvt_time_to_date(&finfo.st_atime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last access = %s\n", date);
  fprintf(stdout, "time of last modification = %ld\n", finfo.st_mtime);
  ret = cvt_time_to_date(&finfo.st_mtime, date, DATE_BUFSZ);
  fprintf(stdout, "time of last modification = %s\n", date);

  return(0);
}
