/*
 * fcntl() get commands
 * Copyright (c) 2013, 2014 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>

#include <sys/types.h>
#include <unistd.h>      /* fcntl() */
#include <fcntl.h>       /* open() */
#include <sys/stat.h>

int main(int argc, char *argv[])
{
  int   flags, ret;
  int   fd;
  char  *fname=NULL;

  /* Get the name of the file */
  if (argc <= 1)
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }
  fname = argv[1];

  /* Open the file */
  fd = open(fname, O_RDONLY);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Find file descriptor flags */
  flags = fcntl(fd, F_GETFD);
  if (flags == -1)
  {
    fprintf(stderr, "fcntl() failed, errno=%d\n", errno);
    close(fd);
    return(-2);
  }
  fprintf(stdout, "File descriptor flags: 0x%x\n", flags);

  /* Find file's status flags */
  flags = fcntl(fd, F_GETFL);
  if (flags == -1)
  {
    fprintf(stderr, "fcntl() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
  fprintf(stdout, "File status flags and access modes: 0x%x\n", flags);

  /* Print the file access modes. Note that we do it this way because
     O_RDONLY is defined to be 0, O_WRONLY 1, O_RDWR 2 */
  if ((flags & O_ACCMODE) & O_RDWR)
    fprintf(stdout, "File access mode: O_RDWR\n");
  else if ((flags & O_ACCMODE) & O_WRONLY)
    fprintf(stdout, "File access mode: O_WRONLY\n");
  else
    fprintf(stdout, "File access mode: O_RDONLY\n");

  /* Find file descriptor owner */
  ret = fcntl(fd, F_GETOWN);
  if (ret == -1)
  {
    fprintf(stderr, "fcntl() failed, errno=%d\n", errno);
    close(fd);
    return(-4);
  }
  fprintf(stdout, "Socket file descriptor owner: %d\n", ret);

  close(fd);
  return(0);
}

