/*
 * Check if a file or directory exists.
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>      /* stat(), fstat() */

#define SILENT 1

int file_exists(char *pathname)
{
  int    ret;
  struct stat  finfo;     /* information about a file or directory */

  if (pathname == NULL)
    return(EINVAL);

  /* Obtain information about the file or directory using stat(). */
  errno = 0;
  ret = stat(pathname, &finfo);
  /* Return 0 if the file exists. */
  if (ret == 0)
    return(0);

  if ((ret == (-1)) && (errno == ENOENT) && !SILENT)
    fprintf(stderr, "%s does not exist.\n", pathname);

  return(errno);  /* errno is ENOENT if the file doesn't exist */
}

int main(int argc, char *argv[])
{
  int   ret;
  char  *fname;    /* file/directory name */

  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  ret = file_exists(fname);
  switch (ret)
  {
    case 0: fprintf(stdout, "%s exists.\n", fname);
    break;
    case ENOENT: fprintf(stderr, "%s does not exist.\n", fname);
    break;
    default: fprintf(stderr, "Checking %s got error %d\n", fname, ret);
    break;
  }
}

