/*
 * symlink()
 * Copyright (c) 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>      /* symlink() */

int main(int argc, char *argv[])
{
  int    ret;
  char   *filename, *symlinkname;

  /* Get the names of the two files */
  if (argc > 2)
  {
    filename = argv[1];
    symlinkname = argv[2];
  }
  else
  {
    fprintf(stderr, "Usage: %s filename symlinkname\n", argv[0]);
    return(-1);
  }

  /* Create the symlink */
  ret = symlink(filename, symlinkname);
  if (ret == -1)
  {
    fprintf(stderr, "symlink() failed, errno=%d\n", errno);
    return(-2);
  }

  return(0);
}
