/*
 * Create a System V message queue and receive messages.
 * Create the unique file pathname (IPCKEYPATH) before running this program.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <stdlib.h>

#define  IPCKEYPATH  "./mymsgq"  /* pick an unique pathname */
#define  PROJID      'q'         /* project id to make the key */
#define  MSGSZ       1024        /* size of messages */
#define  MSGTYPE1    1           /* first type of message */

/* General format of messages for System V message queue.
 * "struct msgbuf" is already defined in sys/msg.h in Solaris, AIX, HPUX
 * except Linux.
 */
struct mymsgbuf {
  long mtype;         /* message type, must be > 0 */
  char mtext[MSGSZ];  /* message data */
};

int main (int argc, char *argv[])
{
  int      msgqid = 0;
  int      key;
  int      msgflags = (IPC_CREAT | 0660);
  int      msgrcvflg = 0;
  int      ret;
  int      msgtype = MSGTYPE1;
  struct   mymsgbuf    inbuf;         /* buffer for outgoing message */
  int      msgcnt = 0;                /* number of messages received */

  /* Get the message type from the user */
  if (argc > 1)
    msgtype = atoi(argv[1]);

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname (IPCKEYPATH) does not exist. */
  if ((key = ftok(IPCKEYPATH, PROJID)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Create or attach to a message queue using the derived key. */
  msgqid = msgget(key, msgflags);
  if (msgqid == (-1))
  {
    fprintf(stderr, "msgget() failed, errno=%d\n", errno);
    return(-errno);
  }
  fprintf(stdout, "msgget() succeeded, msgqid=%d\n", msgqid);

  /* Receive messages */
  while (msgcnt < 2)
  {
    ret = msgrcv(msgqid, (void *)&inbuf, (size_t)MSGSZ, (long)msgtype, msgrcvflg);
    if (ret == (-1))
    {
      fprintf(stderr, "msgrcv() failed, errno=%d\n", errno);
      return(-errno);
    }
    /* Remember to terminate the string */
    inbuf.mtext[ret] = '\0';
    fprintf(stdout, "The following message of %d bytes was received.\n", ret);
    fprintf(stdout, "msgtype=%ld\n", inbuf.mtype);
    fprintf(stdout, "%s\n", inbuf.mtext);
    msgcnt++;
  }

  return(0);
}
