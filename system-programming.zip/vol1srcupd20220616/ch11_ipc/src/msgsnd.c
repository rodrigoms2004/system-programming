/*
 * Create a System V message queue and send messages.
 * Create the unique file pathname (IPCKEYPATH) before running this program.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <stdlib.h>

#define  IPCKEYPATH  "./mymsgq"  /* pick an unique pathname */
#define  PROJID      'q'         /* project id to make the key */
#define  MSGSZ       1024        /* size of messages */
#define  MSGTYPE1    1           /* first type of messages */
#define  MSGTYPE2    2           /* second type of messages */
#define  NMSGS       2           /* number of messages to send for each type */

/* General format of messages for System V message queue.
 * "struct msgbuf" is already defined in sys/msg.h in Solaris, AIX, HPUX
 * except Linux. Therefore, make sure to use a different name here.
 */
struct mymsgbuf {
  long mtype;         /* message type, must be > 0 */
  char mtext[MSGSZ];  /* message data */
};

int main (int argc, char *argv[])
{
  int      msgqid = 0;
  int      key;
  int      msgflags = (IPC_CREAT | 0660);
  int      msgsndflg = 0;
  int      ret, i;
  int      msgtype = MSGTYPE1;
  struct   mymsgbuf    obuf;         /* buffer for outgoing message */

  /* Get the message type from user */
  if (argc > 1)
  {
    msgtype = atoi(argv[1]);
  }

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname (IPCKEYPATH) does not exist. */
  if ((key = ftok(IPCKEYPATH, PROJID)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Create or attach to a message queue using the derived key. */
  msgqid = msgget(key, msgflags);
  if (msgqid == (-1))
  {
    fprintf(stderr, "msgget() failed, errno=%d\n", errno);
    return(-errno);
  }
  fprintf(stdout, "msgget() succeeded, msgqid=%d\n", msgqid);

  /* Send  a couple of messages of the same type */
  obuf.mtype = (long)msgtype;
  for (i = 1; i <= NMSGS; i++)
  {
    sprintf(obuf.mtext, "This is message #%2d of type %2d from the message "
      "sender.", i, msgtype);
    ret = msgsnd(msgqid, (void *)&obuf, (size_t)strlen(obuf.mtext), msgsndflg);
    if (ret == (-1))
    {
      fprintf(stderr, "msgsnd() failed, errno=%d\n", errno);
      return(-errno);
    }
    fprintf(stdout, "A message of type %2d was successfully sent.\n", msgtype);
  }

  return(0);
}
