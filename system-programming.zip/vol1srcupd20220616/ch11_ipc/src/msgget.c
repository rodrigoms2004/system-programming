/*
 * Create a System V message queue.
 * Create the unique file pathname (IPCKEYPATH) before running this program.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2019, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define  IPCKEYPATH  "./mymsgq"  /* pick an unique pathname */
#define  PROJID      'q'         /* project id to make the key */

int main (int argc, char *argv[])
{
  int      msgqid = 0;
  int      key;
  int      msgflags = (IPC_CREAT | 0660);

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname (IPCKEYPATH) does not exist. */
  if ((key = ftok(IPCKEYPATH, PROJID)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Create or attach to a message queue using the derived key. */
  msgqid = msgget(key, msgflags);
  if (msgqid == (-1))
  {
    fprintf(stderr, "msgget() failed, errno=%d\n", errno);
    return(-errno);
  }
  fprintf(stdout, "msgget() succeeded, msgqid=%d\n", msgqid);

  return(0);
}

