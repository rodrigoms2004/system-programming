/*
 * Read a file using mmap() and print its contents.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>          /* open() */
#include <unistd.h>         /* lseek(), write() */
#include <string.h>
#include <sys/mman.h>       /* mmap(), munmap() */
#include <stdlib.h>

#define DEFAULT_FNAME  "./mymmap_file1"  /* default file name */
#define DEFAULT_KBS    1024  /* default file size in KB */
#define NMSGS          2000  /* number of messages to write */

int main (int argc, char *argv[])
{
  int     ret = 0;
  int     fd;                        /* file descriptor */
  char    *fname = DEFAULT_FNAME;    /* default file name */
  int     kbs = DEFAULT_KBS;         /* default file size in KBs */
  int     fsize = (DEFAULT_KBS*1024);  /* default file size in bytes */
  char    *mapstart;                 /* starting address of the mmap */
  char    *curptr;                   /* current pointer to memory map */
  int     bytes;                     /* number of bytes written */
  int     i;                         /* loop counter */

  /* Print usage */
  if ((argc > 1) &&
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [KBs] [fname]\n", argv[0]);
    return(-1);
  }

  /* Get file size and file name, if any */
  if (argc > 1)
  {
    kbs = atoi(argv[1]);
    if (kbs <= 0)
      kbs = DEFAULT_KBS;
  }

  if (argc > 2)
    fname = argv[2];

  /* Open the file. Wait until the writer starts. */
  fd = -1;
  while (fd < 0)
  {
    fd = open(fname, O_RDONLY);
    if (fd == -1)
      fprintf(stderr, "open() failed, errno=%d\n", errno);
  }

  /* Map the file into memory */
  mapstart = mmap(0, fsize, (PROT_READ), MAP_SHARED , fd, 0);
  if (mapstart == MAP_FAILED)
  {
    fprintf(stderr, "mmap() failed, errno=%d\n", errno);
    close(fd);
    return(errno);
  }

  /* Read from the file and dump its contents on stdout */
  ret = write(1, mapstart, fsize);
  if (ret == -1)
    fprintf(stderr, "Reading mapped file failed, errno=%d\n", errno);
  else
    fprintf(stdout, "%d bytes were read and printed.\n", ret);

  /* Unmap it */
  ret = munmap(mapstart, fsize);
  if (ret == -1)
  {
    fprintf(stderr, "munmap() failed, errno=%d\n", errno);
    close(fd);
    return(errno);
  }

  /* Close the file */
  close(fd);
  return(ret);
}

