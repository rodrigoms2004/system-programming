/*
 * A FIFO reader.
 * This program creates a FIFO and reads from it.
 * Copyright (c) 2013, 2014, 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define  FIFO_PATH  "/tmp/myfifo1" 
#define  MSGLEN  64
struct fifobuf
{
  int    pid;          /* pid of sender */
  char   msg[MSGLEN];  /* text message from sender */
};

int file_exists(char *pathname)
{
  int    ret;
  struct stat  finfo;     /* information about a file or directory */

  if (pathname == NULL)
    return(EINVAL);
  errno = 0;
  ret = stat(pathname, &finfo);
  if (ret == 0)  /* file exists */
    return(0);
  return(errno);  /* errno is ENOENT if the file doesn't exist */
}

int main(int argc, char *argv[])
{
  int   ret;
  int   fd;
  mode_t  mode=0644;
  struct fifobuf  buf;
  ssize_t  bytes;
 
  /* Check if the FIFO already exists */
  ret = file_exists(FIFO_PATH);

  /* Create the FIFO if it does not already exist */
  if (ret == ENOENT)
  {
    /* Create the FIFO */
    ret = mkfifo(FIFO_PATH, mode);
    if (ret == -1)
    {
      fprintf(stderr, "mkfifo() failed, errno=%d\n", errno);
      return(-1);
    }
  }

  /* This is the FIFO reader. It reads from the FIFO. */

  /* Open the FIFO for read only */
  fd = open(FIFO_PATH, O_RDONLY, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "FIFO reader: open() for read failed, errno=%d\n", errno);
    return(errno);
  }

  /* Read from the FIFO until it's done */
  do
  {
    bytes = read(fd, (char *)&buf, sizeof(struct fifobuf));
    if (bytes < 0)
    {
      fprintf(stderr, "FIFO reader: read() failed, errno=%d\n", errno);
      close(fd);
      return(errno);
    }
    buf.msg[strlen(buf.msg)] = '\0';
    if (bytes > 0)
      fprintf(stdout, "FIFO reader: just read pid=%d msg='%s'\n", buf.pid,
        buf.msg);
  } while (bytes > 0);

  close(fd);
  return(0);
}
