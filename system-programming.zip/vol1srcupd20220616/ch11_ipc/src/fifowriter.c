/*
 * A FIFO writer
 * This program creates a FIFO and writes messages to it.
 * Copyright (c) 2013, 2014, 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define  FIFO_PATH  "/tmp/myfifo1" 
#define  MSGLEN  64
struct fifobuf
{
  int    pid;          /* pid of sender */
  char   msg[MSGLEN];  /* text message from sender */
};

int file_exists(char *pathname)
{
  int    ret;
  struct stat  finfo;     /* information about a file or directory */

  if (pathname == NULL)
    return(EINVAL);
  ret = stat(pathname, &finfo);
  if (ret == 0)  /* file exists */
    return(0);
  return(errno);  /* errno is ENOENT if the file doesn't exist */
}

int main(int argc, char *argv[])
{
  int   ret;
  int   fd;
  mode_t  mode=0644;
  struct fifobuf  buf;
  ssize_t  bytes;
 
  /* Check if the FIFO already exists */
  ret = file_exists(FIFO_PATH);

  /* Create the FIFO if it does not already exist */
  if (ret == ENOENT)
  {
    /* Create the FIFO */
    ret = mkfifo(FIFO_PATH, mode);
    if (ret == -1)
    {
      fprintf(stderr, "FIFO writer: mkfifo() failed, errno=%d\n", errno);
      return(-1);
    }
  }

  /* This is the writer process. It writes to the FIFO. */
  fd = open(FIFO_PATH, O_WRONLY, mode);
  if (fd == -1)
  {
    fprintf(stderr, "FIFO writer: open() for write failed, errno=%d\n", errno);
    return(errno);
  }

  /* Write some messages to the FIFO */
  sprintf(buf.msg, "%s", "This is a message 1 from writer.");
  buf.pid = (int) getpid();
  bytes = write(fd, &buf, sizeof(buf));
  fprintf(stdout, "FIFO writer: just wrote pid=%d msg='%s'\n", buf.pid, buf.msg);
  sprintf(buf.msg, "%s", "This is a message 2 from writer.");
  bytes = write(fd, &buf, sizeof(buf));
  fprintf(stdout, "FIFO writer: just wrote pid=%d msg='%s'\n", buf.pid, buf.msg);

  sprintf(buf.msg, "%s", "Bye!");
  bytes = write(fd, &buf, sizeof(buf));
  fprintf(stdout, "FIFO writer: just wrote pid=%d msg='%s'\n", buf.pid, buf.msg);

  close(fd);
  /* Remove the FIFO */
  unlink(FIFO_PATH);
  return(0);
}
