/*
 * Print current state (IPC_STAT) of a message queue.
 * Create the unique file pathname (IPCKEYPATH) before running this program.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

#define  IPCKEYPATH  "./mymsgq"  /* pick an unique pathname */
#define  PROJID      'q'         /* project id to make the key */

int main (int argc, char *argv[])
{
  int      msgqid = 0;
  int      key;
  int      msgflags = (IPC_CREAT | 0660);
  int      ret;
  struct msqid_ds  buf;     /* buffer for IPC_STAT operation */

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname (IPCKEYPATH) does not exist. */
  if ((key = ftok(IPCKEYPATH, PROJID)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Create or attach to a message queue using the derived key. */
  msgqid = msgget(key, msgflags);
  if (msgqid == (-1))
  {
    fprintf(stderr, "msgget() failed, errno=%d\n", errno);
    return(-errno);
  }
  fprintf(stdout, "msgget() succeeded, msgqid=%d\n", msgqid);

  /* Perform an IPC_STAT operation on the message queue */
  ret = msgctl(msgqid, IPC_STAT, &buf);
  if (ret == (-1))
  {
    fprintf(stderr, "msgctl() failed, errno=%d\n", errno);
    return(-errno);
  }
  fprintf(stdout, "Number of messages in queue = %lu\n", buf.msg_qnum);
  fprintf(stdout, "Max. # of bytes allowed in queue = %lu\n", buf.msg_qbytes);
  fprintf(stdout, "Pid of last msgsnd() = %u\n", buf.msg_lspid);
  fprintf(stdout, "Time of last msgsnd() = %lu\n", buf.msg_stime);
  fprintf(stdout, "Pid of last msgrcv() = %u\n", buf.msg_lrpid);
  fprintf(stdout, "Time of last msgrcv() = %lu\n", buf.msg_rtime);
  
  return(0);
}
