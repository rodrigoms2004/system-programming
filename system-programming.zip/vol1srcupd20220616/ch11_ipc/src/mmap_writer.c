/*
 * Create a file and write messages to it using mmap().
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>          /* open() */
#include <unistd.h>         /* lseek(), write() */
#include <string.h>
#include <sys/mman.h>       /* mmap(), munmap() */
#include <stdlib.h>

#define DEFAULT_FNAME  "./mymmap_file1"  /* default file name */
#define DEFAULT_KBS    1024  /* default file size in KB */
#define NMSGS          2000  /* number of messages to write */

/* Create a file of the specified size and return the file descriptor */
int create_file(char *fname, unsigned int fsize, int flags, mode_t mode)
{
  int     fd;      /* file descriptor */
  int     ret;     

  if (fname == NULL)
    return(EINVAL);

  /* Create the file */
  fd = open(fname, flags, mode);
  if (fd == -1)
  {
    fprintf(stderr, "create_file(): open() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Stretch the file size to the size specified. */
  ret = lseek(fd, fsize, SEEK_SET);
  if (ret == -1)
  {
    fprintf(stderr, "create_file(): lseek() failed, errno=%d\n", errno);
    close(fd);
    return(-2);
  }
  
  /* Write a null byte at end of file */
  ret = write(fd, "", 1);
  if (ret == -1)
  {
    fprintf(stderr, "create_file(): write() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
  
  return(fd);
}

int main (int argc, char *argv[])
{
  int     ret;
  int     fd;                        /* file descriptor */
  char    *fname = DEFAULT_FNAME;    /* default file name */
  int     kbs = DEFAULT_KBS;         /* default file size in KBs */
  int     fsize = (DEFAULT_KBS*1024);  /* default file size in bytes */
  char    *mapstart;                 /* starting address of the mmap */
  char    *curptr;                   /* current pointer to memory map */
  int     bytes;                     /* number of bytes written */
  int     i;                         /* loop counter */

  /* Print usage */
  if ((argc > 1) &&
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [KBs] [fname]\n", argv[0]);
    return(-1);
  }

  /* Get file size and file name, if any */
  if (argc > 1)
  {
    kbs = atoi(argv[1]);
    if (kbs <= 0)
      kbs = DEFAULT_KBS;
  }

  if (argc > 2)
    fname = argv[2];

  /* Create the file */
  fsize = (kbs * 1024);
  fd = create_file(fname, fsize, (O_RDWR|O_CREAT|O_TRUNC), (mode_t)0664);

  /* Map the file into memory */
  mapstart = mmap(0, fsize, (PROT_READ|PROT_WRITE), MAP_SHARED , fd, 0);
  if (mapstart == MAP_FAILED)
  {
    fprintf(stderr, "mmap() failed, errno=%d\n", errno);
    close(fd);
    return(errno);
  }

  /* Write to the file by writing to the mapped memory */
  curptr = mapstart;
  for (i = 0; i < NMSGS; i++)
  { 
    bytes = sprintf(curptr, "%s%u%s", "This is message #", i, " from sender.\n"); 
    curptr = curptr + bytes;
  }

  /* Unmap it */
  ret = munmap(mapstart, fsize);
  if (ret == -1)
  {
    fprintf(stderr, "munmap() failed, errno=%d\n", errno);
    close(fd);
    return(errno);
  }

  /* Close the file */
  close(fd);
  return(0);
}
