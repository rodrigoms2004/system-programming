/*
 * lseek.c
 * This program opens a file, sets the file pointer to 1024 bytes beyond the
 * end of the file to create a gap at end, and then read from the last
 * 512 bytes of the gap. It got errno=9 (EBADF) error.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>  /* memset() */

#define  BUFSZ        512

int main(int argc, char *argv[])
{
  char *fname;
  int  fd;
  off_t  offset, offset_ret;
  ssize_t  bytes;
  size_t   count;
  char     buf[BUFSZ];

  /* Expect to get the file name from user */
  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Open a file for write only. This open() will fail with errno=2 
     if the file does not exist. */
  fd = open(fname, O_WRONLY, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Zero out the buffer */
  memset((void *)buf, 0, BUFSZ);

  /* Create a gap at end of the file */
  offset = 1024;
  offset_ret = lseek(fd, offset, SEEK_END);
  if (offset_ret == -1)
  {
    fprintf(stderr, "lseek() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
  fprintf(stdout, "offset_ret = %lld \n", offset_ret);

  /* Read the last 512 bytes of the gap */
  offset = -512;
  offset_ret = lseek(fd, offset, SEEK_CUR);
  if (offset_ret == -1)
  {
    fprintf(stderr, "lseek() failed, errno=%d\n", errno);
    close(fd);
    return(-4);
  }
  fprintf(stdout, "offset_ret = %lld \n", offset_ret);

  bytes = read(fd, buf, BUFSZ);
  if (bytes == -1)
  {
    fprintf(stderr, "read() failed, errno=%d\n", errno);
    close(fd);
    return(-5);
  }

  fprintf(stdout, "The bytes read: %s\n", buf);

  /* Close the file */
  close(fd);
  return(0);
}
