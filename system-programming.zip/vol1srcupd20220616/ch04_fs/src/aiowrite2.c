/*
 * aiowrite2.c
 * This program opens a file and writes a message to it starting at byte offset
 * 512 using asynchronous I/O.
 * $ cc -o aiowrite2 aiowrite2.c -lrtkaio -lrt
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>  /* memset() */
#include <aio.h>

#define  BUFSZ        512

int main(int argc, char *argv[])
{
  char *fname;
  int  fd;
  ssize_t  bytes;
  size_t   count;
  char     buf[BUFSZ];
  int      status;
  struct aiocb  aiocb;

  /* Expect to get the file name from user */
  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Open a file for write only */
  fd = open(fname, O_WRONLY|O_CREAT, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Fill the buffer with message to write */
  sprintf(buf, "%s", "This is a text message.");
  count = strlen(buf);

  /* Fill in the aio control block */
  memset((void *)&aiocb, 0, sizeof(aiocb));
  aiocb.aio_fildes = fd;
  aiocb.aio_buf = buf;
  aiocb.aio_nbytes = count;
  aiocb.aio_offset = 512;

  /* Write the contents of the buffer to the file. */
  status = aio_write(&aiocb);
  if (status == 0)
    fprintf(stdout, "The aio write request has been enqueued.\n");
  else if (status == -1)
  {
    fprintf(stderr, "aio_write() call failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
    
  /* Do some other processing here. Otherwise, we wouldn't need async I/O. */

  /* Wait for the async I/O operation to complete */
  status = EINPROGRESS;
  while (status == EINPROGRESS)
    status = aio_error(&aiocb);
  fprintf(stdout, "The async I/O operation completed. aio_error returned %d\n",
    status);
  switch (status)
  {
    case 0:
      fprintf(stdout, "The async I/O operation completed successfully.\n");
    break;
    case ECANCELED:
      fprintf(stdout, "The async I/O operation was cancelled.\n");
    break;
    default:
      fprintf(stdout, "The async I/O operation encountered error %d\n", status);
    break;
  }

  /* Get the final return value of the async I/O call */
  bytes = aio_return(&aiocb);
  if (status == -1)
  {
    fprintf(stderr, "Async write operation failed, errno=%d\n", errno);
    close(fd);
    return(-4);
  }
  fprintf(stdout, "%ld bytes were written into the file.\n", bytes);

  /* Close the file */
  close(fd);
  return(0);
}

