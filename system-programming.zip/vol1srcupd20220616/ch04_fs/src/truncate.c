/*
 * truncate.c
 * This program opens a file and writes a message to the beginning of it.
 * It creates the file if it does not already exist.
 * It truncates the file to zero length if it already exists.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>  /* memset() */

#define  BUFSZ        512

int main(int argc, char *argv[])
{
  char *fname;
  int  fd;
  ssize_t  bytes;
  size_t   count;
  char     buf[BUFSZ];

  /* Expect to get the file name from user */
  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Open a file for write only. Create it if it does not already exist.
   * Truncate the file (erase old contents) if it already exists.
   */
  fd = open(fname, O_WRONLY|O_CREAT|O_TRUNC, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Fill the buffer with message to write */
  sprintf(buf, "%s", "This is a text message.");
  count = strlen(buf);

  /* Write the contents of the buffer to the file.
   * This will write to the beginning of the file.
   */
  bytes = write(fd, buf, count);
  if (bytes == -1)
  {
    fprintf(stderr, "write() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
  fprintf(stdout, "%ld bytes were written into the file\n", bytes);

  /* Close the file */
  close(fd);
  return(0);
}

