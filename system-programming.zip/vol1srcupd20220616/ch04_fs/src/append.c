/*
 * append.c
 * This program appends to a file.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen  All rights reserved.
 *
 O_APPEND
        The file is opened in append mode. Before each write(), the file
        offset is positioned at the end of the file, as if with lseek().
        O_APPEND may lead to corrupted files on NFS file systems if more
        than one process appends data to a file at once. This  is
        because NFS does not support appending to a file, so the client
        kernel has to simulate it, which cannot be done without a race
        condition.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>  /* memset() */

#define  BUFSZ        512

int main(int argc, char *argv[])
{
  char *fname;
  int  fd;
  ssize_t  bytes;
  size_t   count;
  char     buf[BUFSZ];

  /* Expect to get the file name from user */
  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Open a new file for write only */
  fd = open(fname, O_WRONLY|O_APPEND, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Fill the buffer with message to write */
  sprintf(buf, "%s", "This is a newly appended message.\n");
  count = strlen(buf);

  /* Write the contents of the buffer to the file */
  bytes = write(fd, buf, count);
  if (bytes == -1)
  {
    fprintf(stderr, "write() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
  fprintf(stdout, "%ld bytes were written into the new file\n", bytes);

  /* Close the file */
  close(fd);
  return(0);
}

