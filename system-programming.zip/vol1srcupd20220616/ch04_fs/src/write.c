/*
 * write.c
 * This program opens a file and writes a message to the beginning of it.
 * It will fail if the file does not already exist.
 * Copyright (c) 2013, 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>  /* memset() */

#define  BUFSZ        512

int main(int argc, char *argv[])
{
  char *fname;
  int  fd;
  ssize_t  bytes;
  size_t   count;
  char     buf[BUFSZ];

  /* Expect to get the file name from user */
  if (argc > 1)
    fname = argv[1];
  else
  {
    fprintf(stderr, "Usage: %s filename\n", argv[0]);
    return(-1);
  }

  /* Open a file for write only. This open() will fail with errno=2 
     if the file does not exist. */
  fd = open(fname, O_WRONLY, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Fill the buffer with message to write */
  sprintf(buf, "%s", "This is a new string.");
  count = strlen(buf);

  /* Write the contents of the buffer to the file.
   * This will overwrite the beginning of the file if it already exists.
   */
  bytes = write(fd, buf, count);
  if (bytes == -1)
  {
    fprintf(stderr, "write() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }
  fprintf(stdout, "%ld bytes were written into the file\n", bytes);

  /* Close the file */
  close(fd);
  return(0);
}

