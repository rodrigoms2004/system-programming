/*
 * Signal -- the sigpending() function.
 * Copyright (c) 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>

/*
 * Check to see if a signal is pending.
 */
void check_pending(int sig)
{
  sigset_t sigset;
  int         ret;

  ret = sigpending(&sigset);
  if (ret != 0)
  {
    fprintf(stderr, "Calling sigpending() failed, errno=%d\n", errno);
    return;
  }

  ret = sigismember(&sigset, sig);
  if (ret == 1)
    fprintf(stdout, "A signal %d is pending.\n", sig);
  else
    fprintf(stdout, "No signal %d is pending.\n", sig);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int         ret;
  sigset_t    newset, oldset;

  /* Set up to block the SIGQUIT signal */
  
  /* Construct a signal set containing SIGQUIT */
  ret = sigemptyset(&newset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to empty the signal set, errno=%d\n", errno);
    return(-1);
  }
  ret = sigaddset(&newset, SIGQUIT);
  if (ret != 0)
  {
    fprintf(stderr, "  Failed to add SIGQUIT to the signal set, errno=%d\n", errno);
    return(-2);
  }

  /* Add the SIGQUIT signal to the current signal mask */
  fprintf(stdout, "Adding SIGQUIT to the current signal mask\n");
  ret = sigprocmask(SIG_BLOCK, &newset, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to change the current signal mask, errno=%d\n", errno);
    return(-3);
  }

  /* See if blocking the signal works by calling sigpending() */
  check_pending(SIGQUIT);
  fprintf(stdout, "Sending myself a SIGQUIT signal\n");
  kill(getpid(), SIGQUIT);
  check_pending(SIGQUIT);

  return(0);
}

