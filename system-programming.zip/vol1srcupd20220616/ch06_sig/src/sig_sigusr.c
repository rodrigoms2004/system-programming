/*
 * Signal -- using the SIGUSR1 signal as a command to do a clean shutdown.
 * Use two (parent and child) processes.
 * Copyright (c) 1997, 2014, 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>      /* exit() */
#include <signal.h>

/*
 * Signal handler.
 */
int signal_handler(int sig)
{
  /* Do a cleanup and release all resources held by this process */
  fprintf(stdout, "In signal_handler(), this process received a signal %d.\n",
    sig);
  fprintf(stdout, "In signal_handler(), this process is doing a cleanup and"
    " releasing all resources ...\n");
  /* Release all resources this process holds here */
  fprintf(stdout, "In signal_handler(), cleaning up is done. This process is shutting down. Bye!\n");
  /* Shut down this process */
  exit(0);
}

int main(int argc, char *argv[])
{
  pid_t  pid;
  int    stat;   /* child's exit value */
  int    ret;

  /* Create a child process */
  pid = fork();

  if (pid == -1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    return(-1);
  }
  else if (pid == 0)
  {
    /* This is the child process. */
    struct sigaction  newact, oldact;

    fprintf(stdout, "Child: I'm a new born child.\n");
    /* Specify an action for a signal */
    sigfillset(&newact.sa_mask);
    newact.sa_flags = 0;
    /* Specify (i.e. install) my own signal handler function */
    newact.sa_handler =  (void (*)(int))signal_handler;
    ret = sigaction(SIGUSR1, &newact, &oldact);
    if (ret != 0)
    {
      fprintf(stderr, "Child: sigaction() failed on SIGUSR1, errno=%d\n", errno);
      return(-2);
    }
    fprintf(stdout, "Child: A signal handler was successfully installed for "
      "signal SIGUSR1.\n");

    /* Perform the child process' task here and wait for shutdown signal */
    while (1)
      sleep(1);
    return(0);
  }
  else
  {
    /* This is the parent process. */
    fprintf(stdout, "Parent: I've just spawned a child.\n");

    /* Let child get on its feet first before sending it a signal */
    sleep(2);

    /* Test to see if the child is still alive. It must be. */
    ret = kill(pid, SIGUSR1);
    if (ret == 0)
      fprintf(stdout, "Parent: A SIGUSR1 signal was successfully sent to child.\n");
    else
      fprintf(stderr, "Parent: Sending a SIGUSR1 signal to child failed, "
        "errno = %d\n", errno);

    /* Wait for the child to exit */
    pid = wait(&stat);
    if (pid > 0)
    {
      fprintf(stdout, "Parent: My child has exited.\n");

      /* Test to see if the child is still alive again. It should be dead. */
      ret = kill(pid, 0);
      if (ret == 0)
        fprintf(stdout, "Parent: My child is still alive.\n");
      else
        fprintf(stdout, "Parent: My child is dead.\n");
    }

    return(0);
  }
}

