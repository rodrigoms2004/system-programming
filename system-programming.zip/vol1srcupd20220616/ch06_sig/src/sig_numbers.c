/*
 * Signal numbers of required signals.
 * Copyright (c) 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <signal.h>

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  printf("Signals required by the POSIX.1 and ISO/IEC 9945 Standards:\n");
  printf("SIGABRT =     %u\n", SIGABRT);
  printf("SIGALRM =     %u\n", SIGALRM);
  printf("SIGFPE  =     %u\n", SIGFPE);
  printf("SIGHUP  =     %u\n", SIGHUP);
  printf("SIGILL  =     %u\n", SIGILL);
  printf("SIGINT  =     %u\n", SIGINT);
  printf("SIGKILL =     %u\n", SIGKILL);
  printf("SIGPIPE =     %u\n", SIGPIPE);
  printf("SIGQUIT =     %u\n", SIGQUIT);
  printf("SIGSEGV =     %u\n", SIGSEGV);
  printf("SIGTERM =     %u\n", SIGTERM);
  printf("SIGUSR1 =     %u\n", SIGUSR1);
  printf("SIGUSR2 =     %u\n", SIGUSR2);

  printf("\nJob control signals defined by the POSIX.1 and ISO/IEC 9945 Standards:\n");
  printf("SIGCHLD =     %u\n", SIGCHLD);
  printf("SIGCONT =     %u\n", SIGCONT);
  printf("SIGSTOP =     %u\n", SIGSTOP);
  printf("SIGTSTP =     %u\n", SIGTSTP);
  printf("SIGTTIN =     %u\n", SIGTTIN);
  printf("SIGTTOU =     %u\n", SIGTTOU);

  printf("\nSome optional signals:\n");
  printf("SIGBUS  =     %u\n", SIGBUS);
  printf("SIGIOT  =     %u\n", SIGIOT);
#ifndef __APPLE__
  printf("SIGPOLL =     %u\n", SIGPOLL);
#endif
  printf("SIGTRAP =     %u\n", SIGTRAP);
  printf("SIGSYS  =     %u\n", SIGSYS);
  return(0);
}

