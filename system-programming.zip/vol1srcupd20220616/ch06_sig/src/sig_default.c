/*
 * Signal -- taking the default action for SIGQUIT signal.
 * Copyright (c) 2014, 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int         ret;
  struct sigaction  oldact, newact;

  /* Set sa_mask such that all signals are to be blocked during execution
     of the signal handler. */
  sigfillset(&newact.sa_mask);
  newact.sa_flags = 0;
  /* Specify to the default action for the signal */
  newact.sa_handler = SIG_DFL;
  ret = sigaction(SIGQUIT, &newact, &oldact);
  if (ret != 0)
  {
    fprintf(stderr, "sigaction failed, errno=%d\n", errno);
    return(-1);
  }

  fprintf(stderr, "Please send me a SIGQUIT signal (kill -3 pid) ...\n");

  while (1 == 1)
  {
    /* Hang around to receive signals */
  }

}

