/*
 * Signal -- test if a process is still alive using kill()
 * Copyright (c) 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
  pid_t  pid;
  int    stat;   /* child's exit value */
  int    ret;

  /* Create a child process */
  pid = fork();

  if (pid == -1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    return(-1);
  }
  else if (pid == 0)
  {
    /* This is the child process. */
    fprintf(stdout, "Child: I'm a new born child.\n");
    /* Perform the child process' task here */
    sleep(2);
    return(0);
  }
  else
  {
    /* This is the parent process. */
    fprintf(stdout, "Parent: I've just spawned a child.\n");

    /* Test to see if the child is still alive. It must be. */
    ret = kill(pid, 0);
    if (ret == 0)
      fprintf(stdout, "Parent: My child is still alive.\n");
    else
      fprintf(stdout, "Parent: My child is dead.\n");

    /* Wait for the child to exit */
    pid = wait(&stat);
    if (pid > 0)
    {
      fprintf(stdout, "My child has exited.\n");

      /* Test to see if the child is still alive again. It should be dead. */
      ret = kill(pid, 0);
      if (ret == 0)
        fprintf(stdout, "Parent: My child is still alive.\n");
      else
        fprintf(stdout, "Parent: My child is dead.\n");
    }

    return(0);
  }
}

