/*
 * Signal -- to catch a signal by specifying a signal handler.
 * Copyright (c) 2013-4, 2019-2020  Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>

/*
 * Signal handler.
 */
void signal_handler(int sig)
{
  fprintf(stdout, "This process received a signal %d.\n", sig);
  /* We cannot invoke pthread_exit() here. */
  return;
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int         ret;
  struct sigaction  oldact, newact;

  /* Set sa_mask such that all signals are to be blocked during execution
     of the signal handler. */
  sigfillset(&newact.sa_mask);
  newact.sa_flags = 0;
  /* Specify my signal handler function */
  newact.sa_handler = signal_handler;
  ret = sigaction(SIGQUIT, &newact, &oldact);
  if (ret != 0)
  {
    fprintf(stderr, "sigaction() failed, errno=%d\n", errno);
    return(-1);
  }

  fprintf(stderr, "Please send me a SIGQUIT signal (kill -3 pid) ...\n");

  while (1 == 1)
  {
    /* Hang around to receive signals */
  }

}
