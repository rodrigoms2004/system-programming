/*
 * Signal -- to synchronously receive a signal with the sigwait() function.
 * On Solaris, compile like this:
 *   cc -D_POSIX_PTHREAD_SEMANTICS  -o sig_sigwait sig_sigwait.c
 * Copyright (c) 2014, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>

/*
 * Check to see if a signal is pending.
 */
int check_pending(int sig)
{
  sigset_t sigset;
  int         ret;

  ret = sigpending(&sigset);
  if (ret != 0)
  {
    fprintf(stderr, "Calling sigpending() failed, errno=%d\n", errno);
    return(ret);
  }

  ret = sigismember(&sigset, sig);
  if (ret == 1)
    fprintf(stdout, "A signal %d is pending.\n", sig);
  else
    fprintf(stdout, "No signal %d is pending.\n", sig);

  return(ret);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int         ret, ret2, ret3;
  sigset_t    newset, oldset;
  int         done=0;
  int         sig;

  /* Set up to block the SIGQUIT signal */
  
  /* Construct a signal set containing SIGQUIT */
  ret = sigemptyset(&newset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to empty the signal set, errno=%d\n", errno);
    return(-1);
  }
  ret = sigaddset(&newset, SIGQUIT);
  if (ret != 0)
  {
    fprintf(stderr, "  Failed to add SIGQUIT to the signal set, errno=%d\n", errno);
    return(-2);
  }

  /* Add the SIGQUIT signal to the current signal mask */
  fprintf(stdout, "Adding SIGQUIT to the current signal mask\n");
  ret = sigprocmask(SIG_BLOCK, &newset, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to change the current signal mask, errno=%d\n", errno);
    return(-3);
  }

  /* Send myself the SIGQUIT signal twice */
  fprintf(stdout, "Sending myself a SIGQUIT signal\n");
  kill(getpid(), SIGQUIT);
  fprintf(stdout, "Sending myself a SIGQUIT signal\n");
  kill(getpid(), SIGQUIT);

  /* Wait and process the pending signals */
  while (!done)
  {
    ret2 = check_pending(SIGQUIT);
    if (ret2)
    {
      /* Wait for a signal and process it */
      ret3 = sigwait(&newset, &sig);
      if (ret3 == 0)
      {
        fprintf(stdout, "sigwait() returned signal %d\n", sig);
        fprintf(stdout, "Handling signal %d here ...\n", sig);
      }
    }
    else
      done = 1;
  }

  return(0);
}

