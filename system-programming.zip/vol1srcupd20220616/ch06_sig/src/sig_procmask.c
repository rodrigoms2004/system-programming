/*
 * Signal -- the sigprocmask() function.
 * Copyright (c) 2014, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>

/*
 * Check to see if SIGINT and SIGQUIT are in a signal set/mask.
 */
void check_two(sigset_t sigset)
{
  int         ret;

  ret = sigismember(&sigset, SIGINT);
  if (ret == 1)
    fprintf(stdout, "  SIGINT is a member of the current signal mask.\n");
  else
    fprintf(stdout, "  SIGINT is not a member of the current signal mask.\n");

  ret = sigismember(&sigset, SIGQUIT);
  if (ret == 1)
    fprintf(stdout, "  SIGQUIT is a member of the current signal mask.\n");
  else
    fprintf(stdout, "  SIGQUIT is not a member of the current signal mask.\n");
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int         ret;
  sigset_t    newset, oldset;

  /* Get the current signal mask */
  ret = sigprocmask(SIG_SETMASK, NULL, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to get the current signal mask, errno=%d\n", errno);
    return(-1);
  }
  fprintf(stdout, "This is what we started with:\n");
  check_two(oldset);

  /* Construct a signal set containing SIGINT and SIGQUIT */
  ret = sigemptyset(&newset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to empty the signal set, errno=%d\n", errno);
    return(-2);
  }
  ret = sigaddset(&newset, SIGINT);
  if (ret != 0)
  {
    fprintf(stderr, "  Failed to add SIGINT to the signal set, errno=%d\n", errno);
    return(-3);
  }
  ret = sigaddset(&newset, SIGQUIT);
  if (ret != 0)
  {
    fprintf(stderr, "  Failed to add SIGQUIT to the signal set, errno=%d\n", errno);
    return(-4);
  }

  /* Set the signal mask to the new set */
  fprintf(stdout, "Adding SIGINT and SIGQUIT to the current signal mask\n");
  ret = sigprocmask(SIG_BLOCK, &newset, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to change the current signal mask, errno=%d\n", errno);
    return(-5);
  }

  /* Retrieve the current signal mask */
  ret = sigprocmask(SIG_SETMASK, NULL, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to get the current signal mask, errno=%d\n", errno);
    return(-6);
  }
  check_two(oldset);

  /* Test getting a signal in the signal mask. Notice this does not kill. */
  fprintf(stdout, "Sending myself a SIGINT signal and see if we stay alive\n");
  kill(getpid(), SIGINT);
  fprintf(stdout, "Sending myself a SIGQUIT signal and see if we stay alive\n");
  kill(getpid(), SIGQUIT);
  fprintf(stdout, "Yes, we survived!\n");

  /* Make sure the SIGINT signal is the only thing in the newset */
  ret = sigdelset(&newset, SIGQUIT);
  if (ret != 0)
  {
    fprintf(stderr, "  Failed to drop SIGQUIT from the signal set, errno=%d\n", errno);
    return(-7);
  }

  /* Remove the SIGINT signal from the current signal mask */
  fprintf(stdout, "Removing SIGINT from the current signal mask\n");
  ret = sigprocmask(SIG_UNBLOCK, &newset, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to change the current signal mask, errno=%d\n", errno);
    return(-8);
  }

  /* Retrieve the current signal mask */
  ret = sigprocmask(SIG_SETMASK, NULL, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to get the current signal mask, errno=%d\n", errno);
    return(-9);
  }
  check_two(oldset);

  return(0);
}

