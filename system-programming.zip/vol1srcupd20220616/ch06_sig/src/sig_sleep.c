/*
 * Signal -- catching a signal during the sleep() call.
 * Copyright (c) 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

/*
 * Signal handler.
 */
void signal_handler(int sig)
{
  fprintf(stdout, "Received a signal %d\n", sig);
  /* We cannot invoke pthread_exit() here. */
  return;
}

int main(int argc, char *argv[])
{
  pid_t  pid;
  int    stat;   /* child's exit value */
  int    ret;
  unsigned int  ret2;
  struct sigaction  oldact, newact;

  /* Set it up to catch the SIGQUIT signal */
  /* Set sa_mask such that all signals are to be blocked during execution
     of the signal handler */
  sigfillset(&newact.sa_mask);
  newact.sa_flags = 0;
  /* Specify my signal handler function */
  newact.sa_handler = signal_handler;
  ret = sigaction(SIGQUIT, &newact, &oldact);
  if (ret != 0)
  {
    fprintf(stderr, "sigaction failed, errno=%d\n", errno);
    return(-1);
  }

  /* Create a child process */
  pid = fork();

  if (pid == -1)
  {
    fprintf(stderr, "fork() failed, errno=%d\n", errno);
    return(-2);
  }
  else if (pid == 0)
  {
    /* This is the child process. */
    fprintf(stdout, "Child: I'm a new born child.\n");

    /* Perform the child process' task here */
    fprintf(stdout, "Child: Go to sleep for a few seconds.\n");
    ret2 = sleep(5);
    fprintf(stdout, "Child: sleep() return %u\n", ret2);
    return(ret2);
  }
  else
  {
    /* This is the parent process. */
    fprintf(stdout, "Parent: I've just spawned a child.\n");

    /* Test to see if the child is still alive. It must be. */
    ret = kill(pid, 0);
    if (ret == 0)
      fprintf(stdout, "Parent: My child is still alive.\n");
    else
      fprintf(stdout, "Parent: My child is dead.\n");

    /* Send the child a signal */
    sleep(1);  /* comment this out to see what effect it has */
    fprintf(stdout, "Parent: Send my child a signal.\n");
    kill(pid, SIGQUIT);

    /* Wait for the child to exit */
    pid = wait(&stat);
    if (pid > 0)
    {
      fprintf(stdout, "My child has exited.\n");

      /* Test to see if the child is still alive again. It should be dead. */
      ret = kill(pid, 0);
      if (ret == 0)
        fprintf(stdout, "Parent: My child is still alive.\n");
      else
        fprintf(stdout, "Parent: My child is dead.\n");
    }

    return(0);
  }
}

