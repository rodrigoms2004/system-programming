/*
 * Signal -- to block a signal and receive it at convenient time
 * using the sigsuspend() function.
 * Copyright (c) 2014, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>

/*
 * Signal handler.
 */
void signal_handler(int sig)
{
  fprintf(stdout, "Received a signal %d\n", sig);
  /* We cannot invoke pthread_exit() here. */
  return;
}

/*
 * Check to see if a signal is pending.
 */
int check_pending(int sig)
{
  sigset_t sigset;
  int         ret;

  ret = sigpending(&sigset);
  if (ret != 0)
  {
    fprintf(stderr, "Calling sigpending() failed, errno=%d\n", errno);
    return(ret);
  }

  ret = sigismember(&sigset, sig);
  if (ret == 1)
    fprintf(stdout, "A signal %d is pending.\n", sig);
  else
    fprintf(stdout, "No signal %d is pending.\n", sig);

  return(ret);
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  int         ret, ret2, ret3;
  sigset_t    newset, oldset, blkset;
  int         done=0;
  int         sig;
  struct sigaction sigact;

  /* Set up to block the SIGQUIT signal */
  
  /* Construct a signal set containing SIGQUIT */
  ret = sigemptyset(&newset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to empty the signal set, errno=%d\n", errno);
    return(-1);
  }
  ret = sigaddset(&newset, SIGQUIT);
  if (ret != 0)
  {
    fprintf(stderr, "  Failed to add SIGQUIT to the signal set, errno=%d\n",
      errno);
    return(-2);
  }

  /* Add the SIGQUIT signal to the current signal mask */
  fprintf(stdout, "Adding SIGQUIT to the current signal mask\n");
  ret = sigprocmask(SIG_BLOCK, &newset, &oldset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to change the current signal mask, errno=%d\n",
      errno);
    return(-3);
  }

  /* After the signal is blocked, the critical section code can start here */

  /* Send myself the SIGQUIT signal twice. Typically, this is done by some
     other process. */
  fprintf(stdout, "Sending myself a SIGQUIT signal\n");
  kill(getpid(), SIGQUIT);
  fprintf(stdout, "Sending myself a SIGQUIT signal\n");
  kill(getpid(), SIGQUIT);

  /* The critical section ends here */

  /* Set up to catch the signal that we are about to receive.
   * We need to do so because otherwise the default action is to terminate.
   */
  sigfillset(&blkset);
  sigdelset(&blkset, SIGQUIT);
  sigemptyset(&sigact.sa_mask);
  sigact.sa_flags = 0;
  sigact.sa_handler = signal_handler;
  ret = sigaction(SIGQUIT, &sigact, NULL);
  if (ret != 0)
  {
    fprintf(stderr, "sigaction() failed, errno=%d\n", errno);
    return(-4);
  }

  /* Check if we have a pending SIGQUIT signal. Receive it if yes. */
  while (!done)
  {
    ret2 = check_pending(SIGQUIT);
    if (ret2)
    {
      /* Receive the pending signal */
      errno = 0;
      ret3 = sigsuspend(&blkset);
      fprintf(stdout, "sigsuspend() returned %d, errno=%d\n", ret3, errno);
    }
    else
      done = 1;  /* Done if no pending SIGQUIT signal */
  }

  return(0);
}

