/*
 * Signal set.
 * Copyright (c) 2014, 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <signal.h>

/*
 * Display sample contents of a signal set.
 */
void display_signal_set(sigset_t *sigset)
{
  int    ret;

  if (sigset == (sigset_t *)NULL)
    return;

  fprintf(stdout, "\nSampling current contents of the signal set:\n");
  ret = sigismember(sigset, SIGINT);
  if (ret == 1)
    fprintf(stdout, "  SIGINT is a member of the current signal set.\n");
  else
    fprintf(stdout, "  SIGINT is not a member of the current signal set.\n");

  ret = sigismember(sigset, SIGQUIT);
  if (ret == 1)
    fprintf(stdout, "  SIGQUIT is a member of the current signal set.\n");
  else
    fprintf(stdout, "  SIGQUIT is not a member of the current signal set.\n");

  ret = sigismember(sigset, SIGPIPE);
  if (ret == 1)
    fprintf(stdout, "  SIGPIPE is a member of the current signal set.\n");
  else
    fprintf(stdout, "  SIGPIPE is not a member of the current signal set.\n");

  ret = sigismember(sigset, SIGKILL);
  if (ret == 1)
    fprintf(stdout, "  SIGKILL is a member of the current signal set.\n");
  else
    fprintf(stdout, "  SIGKILL is not a member of the current signal set.\n");

  ret = sigismember(sigset, SIGTERM);
  if (ret == 1)
    fprintf(stdout, "  SIGTERM is a member of the current signal set.\n");
  else
    fprintf(stdout, "  SIGTERM is not a member of the current signal set.\n");
  fprintf(stdout,"\n");
}

/*
 * The main program.
 */
int main(int argc, char *argv[])
{
  sigset_t    sigset;
  int         ret;

  /* Fill a signal set */
  ret = sigfillset(&sigset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to fill the signal set, errno=%d\n", errno);
    return(-1);
  }
  fprintf(stdout, "The signal set is just being filled now.\n");
  display_signal_set(&sigset);

  /* Delete a couple of signals from the signal set */
  ret = sigdelset(&sigset, SIGINT);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to delete SIGINT from the signal set, errno=%d\n",
      errno);
    return(-2);
  }
  fprintf(stdout, "SIGINT has been successfully deleted from the signal set.\n");

  ret = sigdelset(&sigset, SIGQUIT);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to delete SIGQUIT from the signal set, errno=%d\n",
      errno);
    return(-3);
  }
  fprintf(stdout, "SIGQUIT has been successfully deleted from the signal set.\n");
  display_signal_set(&sigset);

  /* Empty a signal set */
  ret = sigemptyset(&sigset);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to empty the signal set, errno=%d\n", errno);
    return(-4);
  }
  fprintf(stdout, "The signal set is empty now.\n");
  display_signal_set(&sigset);

  /* Add a couple of signals to the signal set */
  ret = sigaddset(&sigset, SIGPIPE);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to add SIGPIPE to the signal set, errno=%d\n", errno);
    return(-5);
  }
  fprintf(stdout, "SIGPIPE has been successfully added to the signal set.\n");

  ret = sigaddset(&sigset, SIGTERM);
  if (ret != 0)
  {
    fprintf(stderr, "Failed to add SIGTERM to the signal set, errno=%d\n", errno);
    return(-6);
  }
  fprintf(stdout, "SIGTERM has been successfully added to the signal set.\n");
  display_signal_set(&sigset);

  return(0);
}

