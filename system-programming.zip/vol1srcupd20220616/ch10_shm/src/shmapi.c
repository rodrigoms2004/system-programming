/*
 * Full-range shared memory operations -- this does it all.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2015, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

#include "myshm.h"

int main (int argc, char *argv[])
{
  int      shmid = 0;
  key_t    key=5;
  size_t   size = 1;
  int      ret;
  void     *shmaddr = (void *)0;

  /* Create/get the shared memory segment */
  shmid = do_shmget(MYSHMKEY, MYSHMSIZE, 0);
  if (shmid == -1)
  {
    fprintf(stderr, "do_shmget() failed. Exiting ...\n");
    return(shmid);
  }
  fprintf(stdout, "Successfully created the shared memory segment, shmid=%d\n",
    shmid);

  /* Attach to the shared memory segment */
  errno = 0;
  shmaddr = shmat(shmid, (void *)NULL, 0);
  if (shmaddr == (void *)-1)
    fprintf(stderr, "shmat() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "Attached to shared memory at address %p\n", shmaddr);

  /* Get status of the shared memory segment */
  ret = do_shmstat(shmid);
  if (ret != 0)
    fprintf(stderr, "do_shmstat() failed, ret=%d\n", ret);

  /* Typically you do some shared memory read/write operations here. */

  /* Detach from the shared memory segment */
  errno = 0;
  ret = shmdt(shmaddr);
  if (ret == -1)
    fprintf(stderr, "shmdt() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "Detached from shared memory at address %p\n", shmaddr);

  /* Get status of the shared memory segment */
  ret = do_shmstat(shmid);
  if (ret != 0)
    fprintf(stderr, "do_shmstat() failed, ret=%d\n", ret);

  /* Remove the shared memory segment */
  errno = 0;
  ret = shmctl(shmid, IPC_RMID, 0);
  if (ret == -1)
    fprintf(stderr, "shmctl() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "Successfully removed the shared memory segment of "
      "shmid %d\n", shmid);

  return(0);
}

