/*
 * Change ownership and permissions of shared memory segment.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2015, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "myshm.h"

int main (int argc, char *argv[])
{
  int      shmid = 0;
  key_t    key=5;
  size_t   size = 1;
  int      ret;
  struct shmid_ds  buf;

  /* Create/get the shared memory segment */
  shmid = do_shmget(MYSHMKEY, MYSHMSIZE, 0);
  if (shmid == -1)
  {
    fprintf(stderr, "do_shmget() failed. Exiting ...\n");
    return(shmid);
  }
  fprintf(stdout, "The shared memory segment was successfully created."
    " shmid=%d\n", shmid);

  /* Get status of the shared memory segment */
  memset((void *)&buf, 0, sizeof(struct shmid_ds));
  ret = do_shmstat2(shmid, &buf);
  if (ret != 0)
    fprintf(stderr, "do_shmstat2() failed, ret=%d\n", ret);

  /* Change the ownership and permissions of the shared memory segment */
  buf.shm_perm.uid = 1100;
  buf.shm_perm.mode = 00600;

  errno = 0;
  ret = shmctl(shmid, IPC_SET, &buf);
  if (ret == -1)
    fprintf(stderr, "shmctl() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "Ownership and permissions were successfully changed.\n");

  /* Get status of the shared memory segment */
  ret = do_shmstat2(shmid, &buf);
  if (ret != 0)
    fprintf(stderr, "do_shmstat2() failed, ret=%d\n", ret);

  /* Remove the shared memory segment */
  errno = 0;
  ret = shmctl(shmid, IPC_RMID, 0);
  if (ret == -1)
    fprintf(stderr, "shmctl() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "The shared memory segment of shmid %d was successfully"
      " removed.\n", shmid);

  return(0);
}

