/*
 * Utility functions for shared memory example programs.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2015, 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>

#include "myshm.h"

/*
 * This function creates a shared memory segment corresponding to the pathname
 * provided if it does not already exist.
 * In either case it returns the id (shmid) of the shared memory segment.
 * INPUT parameters:
 *   pathname: A pathname used to uniquely identify the shared memory segment.
 *             This value is converted into a key of type key_t.
 *             If this input is NULL then IPC_PRIVATE is used as key.
 *   size: The size of the shared memory segment in bytes.
 *   shmflag: Flags used to create the shared memory segment.
 * OUTPUT:
 *   Return shmid on success and -1 on failure.
 */
int do_shmget(char *pathname, size_t size, int shmflag)
{
  key_t  key = 0;
  int    shmid = 0;
  int    projid = 1;  /* This cannot be 0 on AIX. */

  /* Always create the shared memory segment if it does not already exist. */
  if (shmflag == 0)
    shmflag = MYDEFFLAGS;
  shmflag = (shmflag | IPC_CREAT);

  /* Set the size to default size if it is not provided */
  if (size == 0)
    size = MYSHMSIZE;

  /* Convert the unique pathname provided to a System V IPC key */
  if (pathname == (char *)NULL)
    key = IPC_PRIVATE;
  else
  {
    errno = 0;
    key = ftok(pathname, projid);
    if (key == -1)
    {
      fprintf(stderr, "do_shmget(): ftok() failed, errno=%d\n", errno);
      return(key);
    }
  }

  /* Create/get the shared memory segment */
  errno = 0;
  shmid = shmget(key, size, shmflag);
  if (shmid == -1)
  {
    /* Unable to create/get the shared memory segment */
    fprintf(stderr, "do_shmget(): shmget() failed, errno=%d\n", errno);
    return(shmid);
  }

  return(shmid);
}

/*
 * This function gets and prints some (not all) of the status information
 * of a shared memory segment.
 */
int do_shmstat(int shmid)
{
  int              cmd = IPC_STAT;
  struct shmid_ds  buf;
  int              ret = 0;

  ret = shmctl(shmid, cmd, &buf);
  if (ret == -1)
  {
    fprintf(stderr, "do_shmstat(): shmctl() failed, errno=%d\n", errno);
    return(errno);
  }

  fprintf(stdout, "Current status of the shared memory of shmid %d:\n", shmid);
  fprintf(stdout, "  shm_perm.uid = %d\n", buf.shm_perm.uid);
  fprintf(stdout, "  shm_perm.gid = %d\n", buf.shm_perm.gid);
  fprintf(stdout, "  shm_perm.mode = 0%o\n", buf.shm_perm.mode);
  fprintf(stdout, "  shm_segsz = %lu\n", buf.shm_segsz);
  fprintf(stdout, "  shm_nattch = %d\n", buf.shm_nattch);
  fprintf(stdout, "  shm_cpid = %d\n", buf.shm_cpid);
  fprintf(stdout, "  shm_lpid = %d\n", buf.shm_lpid);
  return(0);
}

/*
 * Get, print and return the status of a shared memory segment. 
 */
int do_shmstat2(int shmid, struct shmid_ds *buf)
{
  int              cmd = IPC_STAT;
  int              ret = 0;

  if (buf == (struct shmid_ds *)NULL)
  {
    fprintf(stderr, "do_shmstat(): error, input buffer pointer is NULL\n");
    return(EINVAL);
  }

  /* Get the status */
  ret = shmctl(shmid, cmd, buf);
  if (ret == -1)
  {
    fprintf(stderr, "do_shmstat(): shmctl() failed, errno=%d\n", errno);
    return(errno);
  }

  fprintf(stdout, "Current status of the shared memory of shmid %d:\n", shmid);
  fprintf(stdout, "  shm_perm.uid = %d\n", buf->shm_perm.uid);
  fprintf(stdout, "  shm_perm.gid = %d\n", buf->shm_perm.gid);
  fprintf(stdout, "  shm_perm.mode = 0%o\n", buf->shm_perm.mode);
  fprintf(stdout, "  shm_segsz = %lu\n", buf->shm_segsz);
  fprintf(stdout, "  shm_nattch = %d\n", buf->shm_nattch);
  fprintf(stdout, "  shm_cpid = %d\n", buf->shm_cpid);
  fprintf(stdout, "  shm_lpid = %d\n", buf->shm_lpid);
  return(0);
}

/*
 * Initialize shared memory contents
 * This function does nothing and returns right away if the contents of the
 * shared memory have already been initialized (i.e. its magic number has
 * already been set) unless the force argument has a non-zero value
 * in which case the shared memory will be re-initialized again..
 * Parameters:
 *   shmaddr (input): starting address of the shared memory.
 *   force (input): flag indicating whether to re-initialize it or not
 *             if it has been initialized before.
 */
int init_shm(char *shmaddr, int force)
{
  char  *shmptr = shmaddr;
  uint   *magic = (uint *)shmaddr;
  uint   *gcount;
  int    *glock;
  struct task *ptask;
  uint   i;

  if (shmaddr == NULL)
    return(EINVAL);

  /* If it has been initialized before, return unless force is true. */
  if ((*magic == (uint)SHMMAGIC) && (!force))
    return(0);
  
  /* Set the magic number and advance the pointer */
  fprintf(stdout, "Initialize the shared memory contents...\n");
  *magic = (uint)SHMMAGIC;
  shmptr = shmptr + sizeof(uint);

  /* Set the banner string */
  strcpy(shmptr, MANNER_STR);
  shmptr = shmptr + BANNER_LEN;

  /* Initialize the global count and global lock */
  gcount = (uint *)shmptr;
  *gcount = (uint)0;  
  shmptr = shmptr + sizeof(uint);
  glock  = (int *)shmptr;
  *glock = (int)0;
  shmptr = shmptr + sizeof(int);

  /* Initialize the task data structures */
  ptask = (struct task *)shmptr;
  for (i = 0; i < NTASKS; i++)
  {
    ptask->taskid = (i + 1);
    sprintf(ptask->taskname, "%s%2d", "Task #", (i+1));
    ptask->count = 0;
    ptask->lock = 0;
    ptask = ptask + 1;
  }

  return(0);
}

/*
 * Read and print the contents of shared memory.
 */
int read_shm(char *shmaddr)
{
  char  *shmptr = shmaddr;
  uint   *magic = (uint *)shmaddr;
  uint   *gcount;
  int    *glock;
  struct task  *ptask;
  int    i;

  /* Print the header portion */
  if (shmaddr == NULL)
    return(EINVAL);
  glock  = (int *)(shmptr + (2*sizeof(uint)) + BANNER_LEN);
  fprintf(stdout, "Contents of the shared memory are:\n");
  spinlock(glock);  /* lock */
  fprintf(stdout, "  magic = %u\n", *magic);
  shmptr = shmptr + sizeof(uint);
  fprintf(stdout, "  banner = %s\n", shmptr);
  shmptr = shmptr + BANNER_LEN;
  gcount = (uint *)shmptr;
  fprintf(stdout, "  gcount = %u\n", *gcount);
  shmptr = shmptr + sizeof(uint);
  fprintf(stdout, "  glock = %u\n", *glock);
  unlock(glock);  /* unlock */
  shmptr = shmptr + sizeof(int);

  /* Print the task data structures */
  ptask = (struct task *)shmptr;
  for (i = 0; i < NTASKS; i++)
  {
    spinlock(&ptask->lock);  /* lock */
    fprintf(stdout, "  taskid[%2d]   = %u\n", i, ptask->taskid);
    fprintf(stdout, "  taskname[%2d] = %s\n", i, ptask->taskname);
    fprintf(stdout, "  count[%2d] = %u\n", i, ptask->count);
    fprintf(stdout, "  lock[%2d]  = %u\n", i, ptask->lock);
    unlock(&ptask->lock);  /* unlock */
    ptask = ptask + 1;
  }

  return(0);
}

/*
 * Initialize shared memory contents -- a simple, shorter version.
 * This version does not initialize the task data structures.
 * This function does nothing and returns right away if the contents of the
 * shared memory have already been initialized (i.e. its magic number has
 * already been set) unless the force argument has a non-zero value
 * in which case the shared memory will be re-initialized again..
 * Parameters:
 *   shmaddr (input): starting address of the shared memory.
 *   force (input): flag indicating whether to re-initialize it or not
 *             if it has been initialized before.
 */
int init_shm1(char *shmaddr, int force)
{
  char  *shmptr = shmaddr;
  uint   *magic = (uint *)shmaddr;
  uint   *gcount;
  int    *glock;

  if (shmaddr == NULL)
    return(EINVAL);

  /* If it has been initialized before, return unless force is true */
  if ((*magic == (uint)SHMMAGIC) && (!force))
    return(0);

  /* Set the magic number and advance the pointer */
  fprintf(stdout, "Initialize the shared memory contents...\n");
  *magic = (uint)SHMMAGIC;
  shmptr = shmptr + sizeof(uint);

  /* Set the banner string */
  strcpy(shmptr, MANNER_STR);
  shmptr = shmptr + BANNER_LEN;

  /* Initialize the global count and global lock */
  gcount = (uint *)shmptr;
  *gcount = (uint)0;
  shmptr = shmptr + sizeof(uint);
  glock  = (int *)shmptr;
  *glock = (int)0;

  return(0);
}

/*
 * Read and print the contents of shared memory -- a simple, shorter version
 * and without concurrency control.
 */
int read_shm1(char *shmaddr)
{
  char  *shmptr = shmaddr;
  uint   *magic = (uint *)shmaddr;
  uint   *gcount;
  int    *glock;

  if (shmaddr == NULL)
    return(EINVAL);
  fprintf(stdout, "Contents of the shared memory are:\n");
  fprintf(stdout, "  magic = %u\n", *magic);
  shmptr = shmptr + sizeof(uint);
  fprintf(stdout, "  banner = %s\n", shmptr);
  shmptr = shmptr + BANNER_LEN;
  gcount = (uint *)shmptr;
  fprintf(stdout, "  gcount = %u\n", *gcount);
  shmptr = shmptr + sizeof(uint);
  shmptr = shmptr + sizeof(uint);
  glock  = (int *)shmptr;
  fprintf(stdout, "  glock = %u\n", *glock);

  return(0);
}

/*
 * Update (write to) shared memory
 * Each process updates a few data items within the shared memory.
 * It increments the counter in task1 by one, the counter in task2 by 2,
 * the counter of in task3 by 3, and so on.
 * And then it increments the global counter gcount by 1.
 */
int update_shm(char *shmaddr, int updcnt, unsigned int delaycnt, int uselock)
{
  uint  n, i;
  uint  loopcnt;  /* number of updates to be performed */
  uint  *gcount;
  struct task  *ptask_start, *ptask;
  int    *glock;
  void some_delay(unsigned int);  /* remove this in real code */

  /* Get the offset of the data items to be updated */
  gcount = (uint *)(shmaddr + sizeof(uint) + BANNER_LEN);
  glock = (int *)(shmaddr + (2*sizeof(uint)) + BANNER_LEN);
  ptask_start = (struct task *)((shmaddr + (3*sizeof(uint)) + BANNER_LEN));

  /* Update the local counter of corresponding task structure */
  for (n = 0; n < updcnt; n++)
  {
    /* Update the local counters in task areas */
    /* Note: Make locking optional is only for demo purpose! */
    ptask = ptask_start;
    for (i = 0; i < NTASKS; i++)
    {
      if (uselock)
        spinlock(&ptask->lock);  /* lock */
      some_delay(delaycnt);      /* remove this in real code */
      ptask->count = ptask->count + (i + 1);
      if (uselock)
        unlock(&ptask->lock);    /* unlock */
      ptask = ptask + 1;         /* advance to next task */
    }

    /* Increment the global counter */
    if (uselock)
      spinlock(glock);     /* lock */
    some_delay(delaycnt);  /* remove this in real code */
    *gcount = (*gcount + 1);
    if (uselock)
      unlock(glock);       /* unlock */
  }
  
  return(0);
}

/*
 * Introduce some delay.
 */
void some_delay(unsigned int count)
{
  uint  i, x, y=2;

  for (i = 0; i < count; i++)
    x = (y-1);
}

