/*
 * Update shared memory.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2015, 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

#include "myshm.h"

int main (int argc, char *argv[])
{
  int      shmid = 0;
  key_t    key=5;
  size_t   size = 1;
  int      ret;
  void     *shmaddr = (void *)0;  /* starting address of shared memory */
  int      force = 0;             /* force initialization or not */
  int      taskid = 0;
  int      uselock = 1;              /* use locking for update or not */
  int      delaycnt = DELAYCNT;      /* delay loop count */
  size_t   updcnt = SHMDEFUPDCNT;    /* each thread's file update count */

  if ((argc > 1) &&
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [uselock] [updcnt] [delaycnt]\n", argv[0]);
    return(-1);
  }

  /* Get command line arguments */
  if (argc > 1)
  {
    uselock = atoi(argv[1]);
    if (uselock != 0)
      uselock = 1;
  }

  if (argc > 2)
    updcnt = atoi(argv[2]);
  if (updcnt <= 0)
    updcnt = SHMDEFUPDCNT;

  if (argc > 3)
    delaycnt = atoi(argv[3]);
  if (delaycnt <= 0)
    delaycnt = DELAYCNT;

  /* Create/get the shared memory segment */
  shmid = do_shmget(MYSHMKEY, MYSHMSIZE, 0);
  if (shmid == -1)
  {
    fprintf(stderr, "do_shmget() failed. Exiting ...\n");
    return(shmid);
  }
  fprintf(stdout, "\nThe shared memory segment was successfully created/got. "
    "shmid=%d\n", shmid);

  /* Attach to the shared memory segment */
  errno = 0;
  shmaddr = shmat(shmid, (void *)NULL, 0);
  if (shmaddr == (void *)-1)
    fprintf(stderr, "shmat() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "Attached to shared memory at address %p\n", shmaddr);

  /* Get status of the shared memory segment */
  ret = do_shmstat(shmid);
  if (ret != 0)
    fprintf(stderr, "do_shmstat() failed, ret=%d\n", ret);

  /* Initialize shared memory contents if it's not done yet */
  ret = init_shm(shmaddr, force);
  if (ret != 0)
    fprintf(stderr, "init_shm() failed, ret=%d\n", ret);

  /* Update shared memory contents */
  if (uselock)
    fprintf(stdout, "\nTo update shared variables in shared memory %lu times "
      "with locking and delaycnt=%u.\n", updcnt, delaycnt);
  else
    fprintf(stdout, "\nTo update shared variables in shared memory %lu times "
      "without locking and delaycnt=%u.\n", updcnt, delaycnt);
  ret = update_shm(shmaddr, updcnt, delaycnt, uselock);
  if (ret != 0)
    fprintf(stderr, "update_shm() failed, ret=%d\n", ret);

  /* Read shared memory contents */
  ret = read_shm(shmaddr);
  if (ret != 0)
    fprintf(stderr, "read_shm() failed, ret=%d\n", ret);

  /* Detach from the shared memory segment */
  errno = 0;
  ret = shmdt(shmaddr);
  if (ret == -1)
    fprintf(stderr, "shmdt() failed, errno=%d\n", errno);
  else
    fprintf(stdout, "Detached from shared memory at address %p\n\n", shmaddr);

  return(0);
}

