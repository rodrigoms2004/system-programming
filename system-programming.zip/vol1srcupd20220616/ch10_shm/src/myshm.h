/*
 * Header file for shared memory example programs
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2015, 2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

/*
 * Types
 */
#define  uint unsigned int

/*
 * Constants
 */

/* The pathname used to uniquely identify the shared memory segment */
#define MYSHMKEY "/var/tmp/AppXyzShmAbc"
/* Default size for the shared memory segment (in bytes) */
#define MYSHMSIZE  2048000
/* Default permissions and flags for the shared memory segment */
#define MYDEFFLAGS (00660 | IPC_CREAT)

/*
 * Contents of shared memory
 */
#define  SHMMAGIC    75432018
#define  BANNER_LEN  64
#define  MANNER_STR  "This is shared memory for application XYZ."
#define  TASKNAME_LEN  64
#define  NTASKS        2
#define  SHMDEFUPDCNT  500

/* Update counts for different tasks */
#define  LOOPCNT1  1000
#define  LOOPCNT2  1000
#define  LOOPCNT3  1000

#define  DELAYCNT  8000000  /* loop count for introducing some delay */

/* A simple data structure for shared memory updates */
struct task
{
  uint  taskid;  /* id of the task */
  char  taskname[TASKNAME_LEN];  /* name of the task */
  uint  count;   /* a local counter */
  int   lock;    /* a lock meant to protect concurrent updates of this data */
};

/*
 * Utility functions
 */

/* Create or get a shared memory segment */
int do_shmget(char *pathname, size_t size, int shmflag);

/* Get and print the status of a shared memory segment */
int do_shmstat(int shmid);

/* Get, print and return the status of a shared memory segment */
int do_shmstat2(int shmid, struct shmid_ds *buf);

/* Initialize shared memory contents */
int init_shm(char *shmaddr, int force);

/* Initialize shared memory contents without initializing task data */
int init_shm1(char *shmaddr, int force);

/* Read and print the contents of shared memory by taking a lock */
int read_shm(char *shmaddr);

/* Read and print the contents of shared memory without taking a lock */
int read_shm1(char *shmaddr);

/* Update (write to) shared memory */
int update_shm(char *shmaddr, int updcnt, unsigned int delaycnt, int uselock);

/* Our own lock/unlock routines */
int spinlock (int *lockvar);
int trylock (int *lockvar);
int unlock (int *lockvar);
