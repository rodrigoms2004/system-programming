/*
 * Create shared memory segment.
 * Authored by Mr. Jin-Jwei Chen
 * Copyright (c) 2015, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

#include "myshm.h"

int main (int argc, char *argv[])
{
  int      shmid = 0;

  /* Create the shared memory segment. Note: The file specified by
     MYSHMKEY must already exist. */
  shmid = do_shmget(MYSHMKEY, MYSHMSIZE, 0);

  if (shmid == -1)
  {
    fprintf(stderr, "shmget() failed. Exiting ...\n");
    return(shmid);
  }

  fprintf(stdout, "Shared memory segment was created, shmid = %d.\n", shmid); 

  /* Note that at this point the shared memory segment just created
     remains in the system. */

  return(0);
}

