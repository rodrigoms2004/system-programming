/*
 * Utility functions for semaphore example programs.
 * Copyright (c) 2013, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"
#include <string.h>      /* memset() */

/*
 * This function gets and returns the identifier of the semaphore set specified.
 * It also creates the semaphore set if it does not already exist.
 * It returns a negative value on failure.
 * Parameters:
 *   pathname (IN) : a pathname identifying the semaphore set
 *   projid   (IN) : combined with pathname to uniquely identifying the
 *                   semaphore set
 *   nsems    (IN) : number of semaphores in the semaphore set
 *   perm     (IN) : permission of the semaphore set
 * Return value:
 *   on success: semaphore id (a non-negative integer)
 *   on failure: negative value of the errno
 */

int get_semaphore_set(char *pathname, int projid, int nsems, size_t perm)
{
  key_t  ipckey;
  int    semid;

  if (pathname == NULL)
    return(-EINVAL);

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname does not exist. */
  if ((ipckey = ftok(pathname, projid)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Create the semaphore if it doesn't exist and get the identifier */
  semid = semget(ipckey, nsems, IPC_CREAT|perm);
  if (semid == -1)
  {
    fprintf(stderr, "semget() failed, errno=%d\n", errno);
    return(-errno);
  }

  return(semid);
}

/*
 * This function sets the value of each semaphore in a semaphore set.
 * Parameters:
 *   semid  (IN) : identifier of the semaphore set
 *   nsems  (IN) : number of semaphores in the semaphore set
 *   semval (IN) : new value of each semaphore
 * Return value:
 *   on success: 0
 *   on failure: the negative value of errno
 */
int init_semaphore_set(int semid, int nsems, int semval)
{
  semun  semarg;
  int    ret;
  int    i;

  if ((semid < 0) || (nsems <= 0))
    return(-EINVAL);

  semarg.array = (unsigned short *)malloc((size_t) (nsems * sizeof(short)));
  if (semarg.array == NULL)
    return(-ENOMEM);
  memset((void *)semarg.array, 0, (size_t) (nsems * sizeof(short)));

  /* Set the semaphores' values */
  for (i=0; i < nsems; i++)
    semarg.array[i] = semval;

  ret = semctl(semid, 0, SETALL, semarg);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to set all, errno=%d\n", errno);
    free(semarg.array);
    return(-errno);
  }

  free(semarg.array);
  return(0);
}

/*
 * This function prints the value of each semaphore in a semaphore set.
 * Parameters:
 *   semid  (IN) : identifier of the semaphore set
 *   nsems  (IN) : number of semaphores in the semaphore set
 * Return value:
 *   on success: 0
 *   on failure: the negative value of errno
 */
int print_semaphore_set(int semid, int nsems)
{
  semun  semarg;
  int    ret;
  int    i;

  if ((semid < 0) || (nsems <= 0))
    return(-EINVAL);

  semarg.array = (unsigned short *)malloc((size_t) (nsems * sizeof(short)));
  if (semarg.array == NULL)
    return(-ENOMEM);

  /* Get the semaphores' values */
  for (i=0; i < nsems; i++)
    semarg.array[i] = 0;

  ret = semctl(semid, 0, GETALL, semarg);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to get all, errno=%d\n", errno);
    free(semarg.array);
    return(-errno);
  }

  for (i=0; i < nsems; i++)
    fprintf(stdout, "  semval[%5u]=%d\n", i, semarg.array[i]);

  free(semarg.array);
  return(0);
}

/*
 * This function acquires the lock on a binary semaphore.
 * A semaphore value of 1 means the lock is available.
 * A semaphore value of 0 means the lock is unavailable.
 * This expects the semaphore's value to be initialized to 1 to begin with.
 * This function attempts to decrement the semaphore's value by 1 to obtain
 * the lock.
 */
int lock_semaphore(int semid, int semnum)
{
  struct sembuf   semoparg;
  int             ret;

  /* See if we can decrement the semaphore's value from 1 to 0 */
  semoparg.sem_num = semnum;   /* starting from 0 */
  semoparg.sem_op  = -1;  /* assume semval is 1 when the lock is not taken */
  semoparg.sem_flg = (SEM_UNDO);
  if ((ret = semop(semid, &semoparg, 1)) == -1) {
    fprintf(stderr, "semop() failed to lock, errno=%d\n", errno);
    return(-errno);
  }

  return(0);
}

/*
 * This function releases the lock on a binary semaphore.
 * A semaphore value of 1 means the lock is available.
 * A semaphore value of 0 means the lock is unavailable.
 * This expects the semaphore's value to be initialized to 1 to begin with.
 * This function attempts to increment the semaphore's value by 1 to make
 * it available.
 */
int unlock_semaphore(int semid, int semnum)
{
  struct sembuf   semoparg;
  int             ret;

  /* Increment the semaphore's value by 1 */
  semoparg.sem_num = semnum;   /* starting from 0 */
  semoparg.sem_op  = 1;  /* assume semval is 1 when the lock is not taken */
  semoparg.sem_flg = (SEM_UNDO);
  if ((ret = semop(semid, &semoparg, 1)) == -1) {
    fprintf(stderr, "semop() failed to unlock, errno=%d\n", errno);
    return(-errno);
  }

  return(0);
}

/*
 * This function creates a file of the specified name, size (in bytes) and
 * permission and fills it with the value specified.
 * Parameters:
 *   fname (IN) - pathname of the file to be created
 *   fsize (IN) - size of the file in bytes
 *   val   (IN) - initial byte value for the entire file
 *   perm  (IN) - permission of the file
 * Return value:
 *   0 if success, or a negative value if failure
 */

int create_file(char *fname, size_t fsize, unsigned char val, int perm)
{
  char  buf[BUFSZ];
  size_t  count, chunk;
  ssize_t  bytes;
  int      fd;
  int      ret=0;
  char     *bufadr;    /* starting address of the buffer to write */

  if (fname == NULL || (fsize <= 0))
    return(-1);

  /* Open the file for write only. Create it if it does not already exist.
   * Truncate it if it exists already.
   */
  fd = open(fname, O_WRONLY|O_CREAT|O_TRUNC, perm);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Fill the buffer with the value to write */
  memset(buf, val, BUFSZ);
  count = fsize;

  /* For easy identification, we start each block with a 'A'.
   * Remove this inserted additional step if you want a uniform file.
   */
  buf[0] = buf[BLKSZ] = 'A';

  /* Fill the file with the initial value specified */
  while (count > 0)
  {
    if (count > BUFSZ)
      chunk = BUFSZ;
    else
      chunk = count;
    count = count - chunk;

    bufadr = buf;
    while (chunk > 0)
    {
      bytes = write(fd, bufadr, chunk);
      if (bytes == -1)
      {
        fprintf(stderr, "failed to write to output file, errno=%d\n", errno);
        close(fd);
        return(-3);
      }
      chunk = chunk - bytes;
      bufadr = bufadr + bytes;
    }  /* inner while */
  }  /* outer while */

  /* Close the file */
  close(fd);
  return(ret);
}

/*
 * This function randomly picks a block from a file and updates the very
 * first byte of it that is not the initial value as specified by the
 * parameter oldval. It replaces the initial byte value with the new byte
 * value specified by the newval parameter.
 * The update repeats for the number of times specified by the updcnt
 * parameter.
 * Parameters:
 *   fd     (IN) - file descriptor of the file to be updated
 *   fsize  (IN) - size of the file in bytes
 *   oldval (IN) - initial byte value to be updated
 *   newval (IN) - new byte value to replace the old value
 * Return value:
 *    0 on success or a negative value if failure
 */

int random_file_update(int fd, size_t fsize, unsigned char oldval, unsigned char newval)
{
  char  buf[BLKSZ];
  size_t   count;        /* number of bytes to read/write */
  ssize_t  bytes_done;   /* number of bytes that were read/written */
  size_t   i, j;
  off_t    offset;
  size_t   nblks;
  size_t   blkno;
  char     *bufadr;

  if ((fd <= 0) || (fsize <= 0))
    return(-1);

  /* Compute the total number of full blocks in the file */
  nblks = (fsize / BLKSZ);
  if (nblks < 1)
    return(-1);

  /* Randomly select a block */
  blkno = (size_t) (rand() % nblks);

  /* Seek to the block selected */
  offset = lseek(fd, (blkno * BLKSZ), SEEK_SET);
  if (offset == (off_t)-1)
  {
    fprintf(stderr, "lseek() failed, errno=%d\n", errno);
    close(fd);
    return(-3);
  }

  /* Read the file block */
  count = BLKSZ;
  bufadr = buf;
  while (count > 0)
  {
    bytes_done = read(fd, bufadr, count);
    if (bytes_done == -1)
    {
      fprintf(stderr, "failed to read from file, errno=%d\n", errno);
      close(fd);
      return(-4);
    }
    count = count - bytes_done;
    bufadr = bufadr + bytes_done;
  }  /* while */

  /* Update the block by replacing first original byte with the new byte */
  for (j = 0; j < BLKSZ; j++)
    if (buf[j] == oldval)
      break;
  if (j < BLKSZ)
    buf[j] = newval;

  /* Seek to the block selected */
  offset = lseek(fd, (blkno * BLKSZ), SEEK_SET);
  if (offset == (off_t)-1)
  {
    fprintf(stderr, "lseek() failed before write, errno=%d\n", errno);
    close(fd);
    return(-5);
  }

  /* Write back the block */
  count = BLKSZ;
  bufadr = buf;
  while (count > 0)
  {
    bytes_done = write(fd, bufadr, count);
    if (bytes_done == -1)
    {
      fprintf(stderr, "failed to write to output file, errno=%d\n", errno);
      close(fd);
      return(-6);
    }
    count = count - bytes_done;
    bufadr = bufadr + bytes_done;
  }  /* while */

  sync();

  return(0);
}

/*
 * This function randomly picks a block from a file and updates the very
 * first byte of it that is not the initial value as specified by the
 * parameter oldval. It replaces the initial byte value with the new byte
 * value specified by the newval parameter.
 * The update repeats for the number of times specified by the updcnt
 * parameter.
 * Parameters:
 *   fname  (IN) - pathname of the file to be updated
 *   fsize  (IN) - size of the file in bytes
 *   oldval (IN) - initial byte value to be updated
 *   newval (IN) - new byte value to replace the old value
 *   updcnt (IN) - number of updates to be performed
 * Return value:
 *    0 on success or a negative value if failure
 */

int random_file_update_all(char *fname, size_t fsize, unsigned char oldval, unsigned char newval, size_t updcnt)
{
  char     buf[BLKSZ];
  size_t   count;        /* number of bytes to read/write */
  ssize_t  bytes_done;   /* number of bytes that were read/written */
  int      fd;
  size_t   i, j;
  off_t    offset;
  size_t   nblks;
  size_t   blkno;
  char     *bufadr;

  if ((fname == NULL) || (fsize <= 0))
    return(-1);

  /* Compute the total number of full blocks in the file */
  nblks = (fsize / BLKSZ);
  if (nblks < 1)
    return(-1);

  /* Open the file for read and write */
  fd = open(fname, O_RDWR, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Do the file update until done */
  for (i = updcnt; i > 0; i--)
  {
    /* Randomly select a block */
    blkno = (size_t) (rand() % nblks);

    /* Seek to the block selected */
    offset = lseek(fd, (blkno * BLKSZ), SEEK_SET);
    if (offset == (off_t)-1)
    {
      fprintf(stderr, "lseek() failed, errno=%d\n", errno);
      close(fd);
      return(-3);
    }

    /* Read the file block */
    count = BLKSZ;
    bufadr = buf;
    while (count > 0)
    {
      bytes_done = read(fd, bufadr, count);
      if (bytes_done == -1)
      {
        fprintf(stderr, "failed to read from file, errno=%d\n", errno);
        close(fd);
        return(-4);
      }
      count = count - bytes_done;
      bufadr = bufadr + bytes_done;
    }  /* while */

    /* Update the block by replacing first original byte with the new byte */
    for (j = 0; j < BLKSZ; j++)
      if (buf[j] == oldval)
        break;
    if (j < BLKSZ)
      buf[j] = newval;

    /* Seek to the block selected */
    offset = lseek(fd, (blkno * BLKSZ), SEEK_SET);
    if (offset == (off_t)-1)
    {
      fprintf(stderr, "lseek() failed before write, errno=%d\n", errno);
      close(fd);
      return(-5);
    }

    /* Write back the block */
    count = BLKSZ;
    bufadr = buf;
    while (count > 0)
    {
      bytes_done = write(fd, bufadr, count);
      if (bytes_done == -1)
      {
        fprintf(stderr, "failed to write to output file, errno=%d\n", errno);
        close(fd);
        return(-6);
      }
      count = count - bytes_done;
      bufadr = bufadr + bytes_done;
    }  /* while */
  }  /* for */

  close(fd);
  return(0);
}

/*
 * This function counts the number of occurrences of each character among
 * '1' ... '9', 'a' ... 'z'.
 */
#define  NCHARS  46
int count_char_occurrences(char *fname)
{
  char  buf[BLKSZ];
  unsigned int occurrences[NCHARS];
  size_t   count;        /* number of bytes to read/write */
  ssize_t  bytes;        /* number of bytes that were read */
  ssize_t  bytes_tot;    /* accumulated number of bytes that were read */
  int      fd;
  size_t   i;
  int      done=0, j;
  char     *bufadr;

  if (fname == NULL)
    return(-1);

  /* Open the file for read */
  fd = open(fname, O_RDONLY, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Reset the counters */
  for (i = 0; i < NCHARS; i++)
    occurrences[i] = 0;

  /* Read the file block by block and count the character occurrences */
  while (!done)
  {
    /* Read the next block */
    count = BLKSZ;
    bufadr = buf;
    bytes_tot = 0;
    while (count > 0)
    {
      bytes = read(fd, bufadr, count);
      if (bytes == -1)
      {
        fprintf(stderr, "failed to read from file, errno=%d\n", errno);
        close(fd);
        return(-3);
      }
      else if (bytes == 0)
      {
        done = 1;
        break;
      }
      count = count - bytes;
      bufadr = bufadr + bytes;
      bytes_tot = bytes_tot + bytes;
    }  /* while */

    /* Count the characters in the current blocks */
    for (i = 0; i < bytes_tot; i++)
    {
      j = -1;
      if ((buf[i] >= '1') && (buf[i] <= '9'))
        j = buf[i] - '0';
      else if ((buf[i] >= 'a') && (buf[i] <= 'z'))
        j = buf[i] - 'a' + 10;
      if (j >= 0)
        occurrences[j] = occurrences[j] + 1;
    }
  }

  /* Print the count -- starting from index 1 */
  fprintf(stdout, "Process/Thread  Updates\n");
  for (i = 1; i < NCHARS; i++)
   fprintf(stdout, "%8lu %12u\n", i, occurrences[i]);
 
  close(fd);
  return(0);
}


