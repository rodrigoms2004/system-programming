/*
 * Lock and unlock a semaphore.
 * Copyright (c) 2013, Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"

int main(int argc, char *argv[])
{
  key_t  ipckey;
  int    projid;
  int    semid;
  int    ret;
  int    exit_code=0;
  semun  semarg;
  struct sembuf   semoparg;
  int    i;

  if (argc > 1)
  {
    projid = atoi(argv[1]);
  }
  else
    projid = IPCSUBID;

  /* Compute the IPC key value from the pathname and project id */
  if ((ipckey = ftok(IPCKEYPATH, projid)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Create the semaphore */
  semid = semget(ipckey, 1, IPC_CREAT|0600);
  if (semid == -1)
  {
    fprintf(stderr, "semget() failed, errno=%d\n", errno);
    return(-2);
  }
  fprintf(stdout, "The semaphore was successfully created.\n");

  /* Initialize the value of the semaphore */
  semarg.val = 1;
  ret = semctl(semid, 0, SETVAL, semarg);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to set value, errno=%d\n", errno);
    exit_code = (-3);
    goto exit;
  }
  fprintf(stdout, "Initializing the semaphore value was successful.\n"); 

  /* Lock the semaphore */
  semoparg.sem_num = 0;   /* select the semaphore */
  semoparg.sem_op  = -1;  /* change its value from 1 to 0 to lock */
  semoparg.sem_flg = (SEM_UNDO);
  if ((ret = semop(semid, &semoparg, 1)) == -1) {
    fprintf(stderr, " semop() failed to lock the semaphore, errno=%d\n",
      errno);
    exit_code = (-errno);
    goto exit;
  }
  fprintf(stdout, "We have successfully acquired the lock!\n");

  fprintf(stdout, "  Updating the shared data ...\n");

  /* Unlock the semaphore */
  semoparg.sem_num = 0;   /* select the semaphore */
  semoparg.sem_op  = 1;   /* increment its value by 1 to unlock */
  semoparg.sem_flg = (SEM_UNDO);
  if ((ret = semop(semid, &semoparg, 1)) == -1) {
    fprintf(stderr, " semop() failed to unlock the semaphore, errno=%d\n",
      errno);
    exit_code = (-errno);
  }
  fprintf(stdout, "We have successfully released the lock!\n");

exit:

  /* Remove the semaphore */
  ret = semctl(semid, 0, IPC_RMID);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to remove, errno=%d\n", errno);
    return(-6);
  }
  fprintf(stdout, "The semaphore set was successfully removed.\n");
  
  return(exit_code);
}

