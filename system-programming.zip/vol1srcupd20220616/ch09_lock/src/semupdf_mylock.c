/*
 * Concurrent updates of a shared file by multiple threads using
 * our own locking routines in assembly language.
 * cc -o semupdf_mylock semupdf_mylock.c semlib.o spinlock.o unlock.o -lpthread
 * Copyright (c) 2013, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"

/* Default values related to the shared file */
#define  NMB         2                   /* number of megabytes */
#define  ONEMB       (1024*1024)         /* one megabytes */
#define  DEFFILESZ   (NMB*ONEMB)         /* default file size in bytes */
#define  NTHREADS    4                   /* number of concurrent threads */
#define  MAXNTHREADS 12                  /* max. number of concurrent threads */
#define  DEF_FNAME   "semsharedf1"       /* name of the shared file */
#define  DEFUPDCNT   1000                /* default update count */
#define  MAXDELAYCNT 10000               /* delay count */

/* Shared lock variable */
int     lockvar=0;

/* Shared file name and file size */
char    *fname;
size_t  filesz;

/* These are our own locking functions in assembly language. */
int spinlock(int *lockvar);
int unlock(int *lockvar);

int update_shared_file(char *fname, size_t fsize, int newval, size_t updcnt, int *lockvar);

/*
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  updcnt;
  int           ret;
  int           newval;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    updcnt = argp[1];
  }
  else
    pthread_exit((void *)(-1));

  fprintf(stdout, "Worker thread: myid=%u updcnt=%u\n", myid, updcnt);

  /* Do my job */
  if (myid < 10)
    newval = '0' + myid;
  else
    newval = 'a' + (myid - 10);

  ret = update_shared_file(fname, filesz, newval, updcnt, &lockvar);
  if (ret != 0)
  {
    fprintf(stderr, "Worker thread: myid=%u, update_shared_file() failed, "
      "ret=%d\n", myid, ret);
    pthread_exit((void *)(-2));
  }

  pthread_exit((void *)0);
}

int main(int argc, char *argv[])
{
  int     nthrd;                      /* actual number of worker threads */
  int     ret, retval;
  int     i;
  char    def_fname[64] = DEF_FNAME;  /* default file name */
  size_t  updcnt = DEFUPDCNT;         /* each thread's file update count */
  pthread_t     thrds[MAXNTHREADS];      /* threads */
  unsigned int  args[MAXNTHREADS][2];    /* arguments for each thread */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [nthrd] [MBs] [updcnt] [fname]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the number of concurrent threads, update count, file size and
   * file name from the user, if any.
   */
  nthrd = NTHREADS;
  if (argc > 1)
  {
    nthrd = atoi(argv[1]);
    if (nthrd <= 0)
      nthrd = NTHREADS;
    if (nthrd > MAXNTHREADS)
      nthrd = MAXNTHREADS;
  }

  filesz = DEFFILESZ;
  if (argc > 2)
  {
    filesz = atoi(argv[2]);
    if (filesz > 0)
      filesz = (filesz * ONEMB);
  }
  if (filesz <= 0)
    filesz = DEFFILESZ;

  updcnt = DEFUPDCNT;
  if (argc > 3)
    updcnt = atoi(argv[3]);
  if (updcnt <= 0)
    updcnt = DEFUPDCNT;

  fname = def_fname;
  if (argc > 4)
    fname = argv[4];

  fprintf(stdout, "Updating file %s of %lu bytes using %u concurrent threads,"
    " %lu updates each.\n" , fname, filesz, nthrd, updcnt);

  /* Create the shared file */
  ret = create_file(fname, filesz, INIT_VALUE, 0644);
  if (ret < 0)
  {
    fprintf(stderr, "Failed to create the shared file\n");
    return(-2);
  }

  /* Load up the input arguments for each worker thread */
  for (i = 0; i < nthrd; i++)
  {
    args[i][0] = i+1;      /* worker id starts with 1 */
    args[i][1] = updcnt;
  }

  /* Create the worker threads to concurrently update the shared file */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread\n");
      return(3);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_join(thrds[i], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  /* Report the update counts from all threads */
  ret = count_char_occurrences(fname);
}

/*
 * Code for the worker process to execute.
 * This function updates a shared file, one block at a time.
 */
int update_shared_file(char *fname, size_t fsize, int newval, size_t updcnt, int *lockvar)
{
  int   fd;
  int   i;
  int   ret=0;
  unsigned long long  j, k=0;
  struct timeval  tm1, tm2, tm3;

  /* Open the file for read and write */
  fd = open(fname, O_RDWR, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Do the file update until done */
  for (i = updcnt; i > 0; i--)
  {
    /* Acquire the lock */
    ret = spinlock(lockvar);
    if (ret != 0)
      break;

    /* Update the file */
    ret = random_file_update(fd, fsize, INIT_VALUE, newval);
  
    /* Introduce some delay here to create more overlap and contention */
    for (j = 0; j < MAXDELAYCNT; j++)
      k = k + 2;

    /* Release the lock */
    ret = unlock(lockvar);

    if (ret != 0)
      break;
  }

  /* close the file */
  close(fd);
  return(ret);
}

