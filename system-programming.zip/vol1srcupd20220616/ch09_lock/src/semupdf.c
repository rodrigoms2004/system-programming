/*
 * Concurrent updates of a shared file by multiple processes using semaphore.
 * Copyright (c) 2013, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"

/* Default values related to the shared file */
#define  NMB         2                   /* number of megabytes */
#define  ONEMB       (1024*1024)         /* one megabytes */
#define  DEFFILESZ   (NMB*ONEMB)         /* default file size in bytes */
#define  NPROC       4                   /* number of concurrent processes */
#define  DEF_FNAME   "semsharedf1"       /* name of the shared file */
#define  DEFUPDCNT   40                  /* default update count */
#define  MAXDELAYCNT 100000000           /* delay count */

int update_shared_file(char *fname, size_t fsize, int newval, size_t updcnt, int semid);

int main(int argc, char *argv[])
{
  key_t   ipckey;
  int     nproc;
  int     semid;
  int     ret;
  int     exit_code=0;
  semun   semarg;
  unsigned short semval[ONESEM];
  int     i;
  int     projid = IPCSUBID;
  char    def_fname[64] = DEF_FNAME;
  char    *fname;
  size_t  filesz;
  size_t  updcnt = DEFUPDCNT;
  pid_t   pid;
  int     stat;   /* child's exit value */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [nproc] [MBs] [updcnt] [fname]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the number of concurrent processes, update count, file size and
   * file name from the user, if any.
   */
  nproc = NPROC;
  if (argc > 1)
    nproc = atoi(argv[1]);
  if (nproc <= 0)
    nproc = NPROC;

  filesz = DEFFILESZ;
  if (argc > 2)
  {
    filesz = atoi(argv[2]);
    if (filesz > 0)
      filesz = (filesz * ONEMB);
  }
  if (filesz <= 0)
    filesz = DEFFILESZ;

  updcnt = DEFUPDCNT;
  if (argc > 3)
    updcnt = atoi(argv[3]);
  if (updcnt <= 0)
    updcnt = DEFUPDCNT;

  fname = def_fname;
  if (argc > 4)
    fname = argv[4];

  fprintf(stdout, "Updating file %s of %lu bytes using %u concurrent processes,"
    " %lu updates each.\n" , fname, filesz, nproc, updcnt);

  /* Create the shared file */
  ret = create_file(fname, filesz, INIT_VALUE, 0644);
  if (ret < 0)
  {
    fprintf(stderr, "Failed to create the shared file\n");
    return(-2);
  }

  /* Create the semaphore */
  semid = get_semaphore_set(IPCKEYPATH, IPCSUBID, ONESEM, 0600);
  if (semid < 0)
  {
    fprintf(stderr, "Failed to create the semaphore set, errno=%d\n", semid);
    return(-3);
  }

  /* Initialize the value of the semaphore (to be 1) */
  ret = init_semaphore_set(semid, ONESEM, 1);
  ret = print_semaphore_set(semid, ONESEM);


  /* Create the worker processes and let them go to work */
  for (i = 1; i <= nproc; i++)
  {
    pid = fork();

    if (pid == -1)
    {
      fprintf(stderr, "fork() failed, i=%u, errno=%d\n", i, errno);
    }
    else if (pid == 0)
    {
      /* This is the child process. */
      /* Perform the child process' task here */
      ret = update_shared_file(fname, filesz, '0'+i, updcnt, semid);
      return(ret);
    }
    else
    {
      /* This is the parent process. */
      /* Simply continue */
    }
  }

  /* Wait for all worker processes to finish */
  for (i = 0; i < nproc; i++)
  {
    pid = wait(&stat);
  }

  /* Remove the semaphore */
  ret = semctl(semid, 0, IPC_RMID);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to remove the semaphore set, errno=%d\n",
      errno);
    return(-9);
  }
  fprintf(stdout, "The semaphore set was successfully removed.\n");

  /* Report the update counts from all processes */
  ret = count_char_occurrences(fname);
}

/*
 * Code for the worker process to execute.
 * This function updates a shared file, one block at a time.
 */
int update_shared_file(char *fname, size_t fsize, int newval, size_t updcnt, int semid)
{
  int   fd;
  int   i;
  int   ret=0;
  unsigned long long  j, k=0;
  struct timeval  tm1, tm2, tm3;

  /* Open the file for read and write */
  fd = open(fname, O_RDWR, 0644);
  if (fd == -1)
  {
    fprintf(stderr, "open() failed, errno=%d\n", errno);
    return(-errno);
  }

  /* Do the file update until done */
  for (i = updcnt; i > 0; i--)
  {
    /* Acquire the lock */
    ret = lock_semaphore(semid, 0);
    if (ret != 0)
      break;

    /* Update the file */
    ret = random_file_update(fd, fsize, INIT_VALUE, newval);
  
    /* Introduce some delay here to be a bit more real */
    for (j = 0; j < MAXDELAYCNT; j++)
      k = k + 2;

    /* Release the lock */
    ret = unlock_semaphore(semid, 0);

    if (ret != 0)
      break;
  }

  /* close the file */
  close(fd);
  return(ret);
}

