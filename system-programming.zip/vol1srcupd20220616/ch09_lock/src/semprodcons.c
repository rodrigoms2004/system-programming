/*
 * Producer-consumer application using a binary semaphore.
 * Copyright (c) 2013, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"
#include <time.h>

/* Default values */
#define  NPROD      3     /* number of producers */
#define  NCONS      3     /* number of consumers */
#define  MAXPROC   50     /* maximum number of producers or consumers */
#define  RUNCNT     4     /* how many iterations we like to run each process */
#define  DELAYCNT  8000000  /* for introducing some time delay */

unsigned int prodcnt = 0; /* total product count */

int produce(size_t id, size_t capacity, size_t runcnt, int semid);
int consume(size_t id, size_t capacity, size_t runcnt, int semid);

int semlock(int semid)
{
  struct sembuf  semoparg;
  int    ret;

  semoparg.sem_num = 0;   /* first semaphore */
  semoparg.sem_op  = -1;  /* take away the lock */
  semoparg.sem_flg = (SEM_UNDO);
  if ((ret = semop(semid, &semoparg, 1)) == -1) {
    fprintf(stderr, "semop() failed to lock the semaphore, errno=%d\n", errno);
    return(-errno);
  }
  return(0);
}

int semunlock(int semid)
{
  struct sembuf  semoparg;
  int    ret;

  semoparg.sem_num = 0;   /* first semaphore */
  semoparg.sem_op  = 1;   /* release the lock */
  semoparg.sem_flg = (SEM_UNDO);
  if ((ret = semop(semid, &semoparg, 1)) == -1) {
    fprintf(stderr, "semop() failed to unlock the semaphore, errno=%d\n", errno);
    return(-errno);
  }
  return(0);
}

int main(int argc, char *argv[])
{
  key_t   ipckey;
  int     semid;
  int     ret;
  int     exit_code=0;
  semun   semarg;
  unsigned short semval[ONESEM];
  int     i;
  int     projid = IPCSUBID;
  int     nprod;  /* actual number of producers */
  int     ncons;  /* actual number of consumers */
  pid_t   pid;
  int     stat;   /* child's exit value */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [n_producers] [n_consumers]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the number of producers and/or consumers from the user.
   */
  nprod = NPROD;
  if (argc > 1)
    nprod = atoi(argv[1]);
  if (nprod <= 0)
    nprod = NPROD;
  if (nprod > MAXPROC)
    nprod = MAXPROC;

  ncons = NCONS;
  if (argc > 2)
    ncons = atoi(argv[2]);
  if (ncons <= 0)
    ncons = NCONS;
  if (ncons > MAXPROC)
    ncons = MAXPROC;

  fprintf(stdout, "Running with %u producers and %u consumers\n",
    nprod, ncons);
  fprintf(stdout, "The product count starts at %d.\n", prodcnt);

  /* Create the semaphore */
  semid = get_semaphore_set(IPCKEYPATH, IPCSUBID, ONESEM, 0600);
  if (semid < 0)
  {
    fprintf(stderr, "Failed to create the semaphore set, errno=%d\n", semid);
    return(-2);
  }

  /* Initialize the value of the semaphore (to be 1 -- lock is available) */
  ret = init_semaphore_set(semid, ONESEM, 1);
  ret = print_semaphore_set(semid, ONESEM);

  /* Create the producer processes */
  for (i = 1; i <= nprod; i++)
  {
    pid = fork();

    if (pid == -1)
    {
      fprintf(stderr, "fork() failed, i=%u, errno=%d\n", i, errno);
    }
    else if (pid == 0)
    {
      /* This is a child process. */
      ret = produce(i, i, RUNCNT, semid);
      return(ret);
    }
  }

  /* Create the consumer processes */
  for (i = 1; i <= ncons; i++)
  {
    pid = fork();

    if (pid == -1)
    {
      fprintf(stderr, "fork() failed, i=%u, errno=%d\n", i, errno);
    }
    else if (pid == 0)
    {
      /* This is a child process. */
      ret = consume(i, i, RUNCNT, semid);
      return(ret);
    }
  }

  /* Wait for all worker processes to finish */
  for (i = 0; i < nprod; i++)
  {
    pid = wait(&stat);
  }
  for (i = 0; i < ncons; i++)
  {
    pid = wait(&stat);
  }

  fprintf(stdout, "The product count ends at %d.\n", prodcnt);

  /* Remove the semaphore */
  ret = semctl(semid, 0, IPC_RMID);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to remove the semaphore set, errno=%d\n",
      errno);
    return(-3);
  }
  fprintf(stdout, "The semaphore set was successfully removed.\n");
}

/* Worker function for the producer process. */
int produce(size_t id, size_t capacity, size_t runcnt, int semid)
{
  struct sembuf   semoparg;
  int     ret;
  size_t  j;

  while (runcnt--)
  {
    fprintf(stdout, "Producer %lu try to produce %lu goods.\n", id, capacity);
    /* Increment the global product count by my capacity */
    ret = semlock(semid);
    if (ret != 0)
    {
      fprintf(stderr, "Producer failed to lock, errno=%d\n", ret);
      return(ret);
    }
    prodcnt = prodcnt + capacity;
    ret = semunlock(semid);
    if (ret != 0)
    {
      fprintf(stderr, "Producer failed to unlock, errno=%d\n", ret);
      return(ret);
    }

    fprintf(stdout, "Producer %lu produced %lu goods.\n", id, capacity);
    fflush(stdout);

    /* Cause some delay to create more overlap and contention */
    for (j = 0; j < DELAYCNT; j++);
  }

  return(0);
}

/* Worker function for the consumer process. */
int consume(size_t id, size_t capacity, size_t runcnt, int semid)
{
  struct sembuf   semoparg;
  int     ret;
  size_t  j;
  int     done;
  struct timespec  sleeptime;

  while (runcnt--)
  {
    fprintf(stdout, "Consumer %lu try to consume %lu goods.\n", id, capacity);
    /* Decrement the global product count by my capacity */
    ret = semlock(semid);
    if (ret != 0)
    {
      fprintf(stderr, "Consumer failed to lock, errno=%d\n", ret);
      return(ret);
    }
    prodcnt = prodcnt + capacity;
    ret = semunlock(semid);
    if (ret != 0)
    {
      fprintf(stderr, "Consumer failed to unlock, errno=%d\n", ret);
      return(ret);
    }

    fprintf(stdout, "Consumer %lu consumed %lu goods.\n", id, capacity);
    fflush(stdout);

    /* Cause some delay to create more overlap and contention */
    for (j = 0; j < DELAYCNT; j++);
  }

  return(0);
}

