/*
 * Demonstrate the IPCINFO command of the semctl function.
 * Note: The semctl() IPC_INFO command is not supported in AIX or Solaris.
 * Copyright (c) 2013, Mr. Jin-Jwei Chen.  All rights reserved.
 */

#define  _GNU_SOURCE    /* to get IPC_INFO, which is Linux specific */

#include "mysemutil.h"

void print_seminfo(struct seminfo *p);

int main(int argc, char *argv[])
{
  key_t  ipckey;
  int    projid;
  int    semid;
  int    ret;
  int    exit_code=0;
  semun  semarg;
  struct seminfo  seminfo;
  int    i;

  if (argc > 1)
    projid = atoi(argv[1]);
  else
    projid = IPCSUBID;

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname does not exist. */
  if ((ipckey = ftok(IPCKEYPATH, projid)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Create the semaphore */
  semid = semget(ipckey, 1, IPC_CREAT|0600);
  if (semid == -1)
  {
    fprintf(stderr, "semget() failed, errno=%d\n", errno);
    return(-2);
  }
  fprintf(stdout, "The semaphore was successfully created.\n");

  /* Get the system-wide semaphore limits and parameters */
  semarg.__buf = &seminfo;
  ret = semctl(semid, 0, IPC_INFO, semarg);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to do IPC_INFO, errno=%d\n", errno);
    exit_code = (-3);
  }
  else
    print_seminfo(&seminfo);

  /* Remove the semaphore */
  /* The second argument, semnum, is ignored for removal. */
  ret = semctl(semid, 0, IPC_RMID);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to remove, errno=%d\n", errno);
    return(-4);
  }
  fprintf(stdout, "The semaphore set was successfully removed.\n");
  
  return(exit_code);
}

void print_seminfo(struct seminfo *p)
{
  if (p == NULL)
    return;
  fprintf(stdout, "semmap = %d\n", p->semmap);
  fprintf(stdout, "semmni = %d\n", p->semmni);
  fprintf(stdout, "semmns = %d\n", p->semmns);
  fprintf(stdout, "semmnu = %d\n", p->semmnu);
  fprintf(stdout, "semmsl = %d\n", p->semmsl);
  fprintf(stdout, "semopm = %d\n", p->semopm);
  fprintf(stdout, "semume = %d\n", p->semume);
  fprintf(stdout, "semusz = %d\n", p->semusz);
  fprintf(stdout, "semvmx = %d\n", p->semvmx);
  fprintf(stdout, "semaem = %d\n", p->semaem);
}

