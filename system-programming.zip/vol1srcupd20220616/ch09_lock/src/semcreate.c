/*
 * Create a semaphore set.
 * Copyright (c) 2013, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#define  IPCKEYPATH  "/var/xyzinc/app1"  /* this file or directory must exist */
#define  IPCSUBID    'A'         /* project id identifying the semaphore set */
#define  NSEMS       3           /* number of semaphores in our semaphore set */

int main(int argc, char *argv[])
{
  key_t  ipckey;
  int    projid;
  int    semid;
  int    ret;

  if (argc > 1)
  {
    projid = atoi(argv[1]);
  }
  else
    projid = IPCSUBID;

  /* Compute the IPC key value from the pathname and project id */
  /* ftok() got error 2 if the pathname does not exist. */
  if ((ipckey = ftok(IPCKEYPATH, projid)) == (key_t)-1) {
    fprintf(stderr, "ftok() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Create the semaphore set */
  semid = semget(ipckey, NSEMS, IPC_CREAT|0600);
  if (semid == -1)
  {
    fprintf(stderr, "semget() failed, errno=%d\n", errno);
    return(-2);
  }
  fprintf(stdout, "The semaphore set was successfully created.\n");

  return(0);
}

