/*
 * Concurrent updates of two shared variables by multiple threads using
 * our own locking routines in assembly language.
 * Copyright (c) 2013, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"

/* Default values related to the shared file */
#define  NTHREADS    4                   /* number of concurrent threads */
#define  MAXNTHREADS 12                  /* max. number of concurrent threads */
#define  DEFUPDCNT   10000000            /* default update count */
#define  MAXDELAYCNT 1000                /* delay count */

/* Shared lock variable */
int     lockvar=0;

/* Shared data */
unsigned int globalcnt = 0;
unsigned int globalcnt2 = 0;

/* These are our own locking functions in assembly language. */
int spinlock(int *lockvar);
int unlock(int *lockvar);

/*
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  updcnt;
  int           ret = 0;
  int           i, j;
  int           uselock=1;

  /* Extract input arguments (two unsigned integers and one signed) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    updcnt = argp[1];
    uselock = argp[2];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u updcnt=%u\n", myid, updcnt);

  /* Do my job */
  for (i = 0; i < updcnt; i++)
  {
    if (uselock)
      spinlock(&lockvar);
    globalcnt = globalcnt + 1;         /* update shared variable 1 */
    for (j=0; j < MAXDELAYCNT; j++);   /* create a bit of delay */
    globalcnt2 = globalcnt2 + 1;       /* update shared variable 2 */
    if (uselock)
      unlock(&lockvar);
  }
    
#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

int main(int argc, char *argv[])
{
  int     nthrd;                      /* actual number of worker threads */
  int     ret, retval;
#ifdef SUN64
  int     *retvalp = &retval;         /* pointer to returned value */
#endif
  int     i;
  size_t  updcnt = DEFUPDCNT;         /* each thread's file update count */
  pthread_t     thrds[MAXNTHREADS];   /* threads */
  unsigned int  args[MAXNTHREADS][3]; /* arguments for each thread */
  int           uselock;              /* use locking for update or not */
  pthread_attr_t  attr;               /* pthread attributes */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [uselock] [nthrd] [updcnt]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the lock switch, number of concurrent threads and update count
   * from the user, if any.
   */
  uselock = 1;
  if (argc > 1)
  {
    uselock = atoi(argv[1]);
    if (uselock != 0)
      uselock = 1;
  }

  nthrd = NTHREADS;
  if (argc > 2)
    nthrd = atoi(argv[2]);
  if (nthrd <= 0 || nthrd > MAXNTHREADS)
    nthrd = NTHREADS;

  updcnt = DEFUPDCNT;
  if (argc > 3)
    updcnt = atoi(argv[3]);
  if (updcnt <= 0)
    updcnt = DEFUPDCNT;

  fprintf(stdout, "Increment the values of two shared variables using %u "
    "threads, with each doing it %lu times.\n", nthrd, updcnt);
  if (uselock)
    fprintf(stdout, "Locking is used during the updates.\n");
  else
    fprintf(stdout, "Locking is not used during the updates.\n");
  printf("At start, globalcnt=%d globalcnt2=%d\n", globalcnt, globalcnt2);

  /* Load up the input arguments for each worker thread */
  for (i = 0; i < nthrd; i++)
  {
    args[i][0] = i+1;      /* worker id starts with 1 */
    args[i][1] = updcnt;
    args[i][2] = uselock;
  }

  /* Initialize the pthread attributes */
  ret = pthread_attr_init(&attr);
  if (ret != 0)
  {
    fprintf(stderr, "pthread_attr_init() function failed, ret=%d\n", ret);
    return(-2);
  }

  /* Create the worker threads to concurrently update the shared variables */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)&attr,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread\n");
      return(-3);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthrd; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  /* Report the end results */
  printf("At end, globalcnt=%d globalcnt2=%d\n", globalcnt, globalcnt2);

  return(0);
}

