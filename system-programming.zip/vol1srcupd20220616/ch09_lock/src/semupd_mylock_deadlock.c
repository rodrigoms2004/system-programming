/*
 * Demonstration of deadlocks
 * Copyright (c) 2013, 2019-2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"

/* Default values related to the shared file */
#define  NTHREADS    2                   /* number of concurrent threads */
#define  MAXNTHREADS 12                  /* max. number of concurrent threads */
#define  NTASKS      5                   /* number of tasks */
#define  MAXDELAYCNT 1000000             /* delay count */

/* Shared lock variable */
int     lockvar=0;

/* These are our own locking functions in assembly language. */
int spinlock(int *lockvar);
int unlock(int *lockvar);

int funcA(unsigned int  myid, int nestedcall);
int funcB(unsigned int  myid);

void lockXYZ()
{
    spinlock(&lockvar);
}

void unlockXYZ()
{
    unlock(&lockvar);
}

int funcA(unsigned int  myid, int nestedcall)
{
  fprintf(stdout, "Thread %2d execute part 1 in function A\n", myid);
  lockXYZ();
  /* Do some funcA specific processing */
  fprintf(stdout, "Thread %2d execute part 2 in function A\n", myid);
  if (nestedcall)
    funcB(myid);
  unlockXYZ();
  fprintf(stdout, "Thread %2d return from function A\n", myid);
  return(0);
}

int funcB(unsigned int  myid)
{
  fprintf(stdout, "Thread %2d execute part 1 in function B\n", myid);
  lockXYZ();
  /* Do some funcB specific processing */
  fprintf(stdout, "Thread %2d execute part 2 in function B\n", myid);
  unlockXYZ();
  fprintf(stdout, "Thread %2d return from function B\n", myid);
  return(0);
}

/*
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  int           ret;
  int           i, j;
  int           nestedcall=1;

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
    nestedcall = argp[2];
  }
  else
    pthread_exit((void *)(-1));

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks);

  /* Do my job */
  for (i = 0; i < NTASKS; i++)
  {
    funcA(myid, nestedcall);
    for (j=0; j < MAXDELAYCNT; j++);   /* create a bit of delay */
  }
 
  pthread_exit((void *)0);
}

int main(int argc, char *argv[])
{
  int     nthrd;                      /* actual number of worker threads */
  int     ret, retval;
  int     i;
  size_t  ntasks = NTASKS;            /* each thread's task count */
  pthread_t     thrds[MAXNTHREADS];   /* threads */
  unsigned int  args[MAXNTHREADS][3]; /* arguments for each thread */
  int           nestedcall;           /* use locking for update or not */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [nestedcall] [nthrd] [ntasks]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the number of concurrent threads, number of tasks and nested call
   * switch from the user, if any.
   */
  nestedcall = 1;
  if (argc > 1)
  {
    nestedcall = atoi(argv[1]);
    if (nestedcall != 0)
      nestedcall = 1;
  }

  nthrd = NTHREADS;
  if (argc > 2)
    nthrd = atoi(argv[2]);
  if (nthrd <= 0 || nthrd > MAXNTHREADS)
    nthrd = NTHREADS;

  ntasks = NTASKS;
  if (argc > 3)
    ntasks = atoi(argv[3]);
  if (ntasks <= 0)
    ntasks = NTASKS;

  fprintf(stdout, "Demonstrating deadlock from nested calls of trying to "
    "acquire the same lock using %u threads, with each doing it %lu times.\n",
    nthrd, ntasks);
  if (nestedcall)
    fprintf(stdout, "Nested call is used in the demo.\n");
  else
    fprintf(stdout, "Nested call is not used in the demo.\n");

  /* Load up the input arguments for each worker thread */
  for (i = 0; i < nthrd; i++)
  {
    args[i][0] = i+1;      /* worker id starts with 1 */
    args[i][1] = ntasks;
    args[i][2] = nestedcall;
  }

  /* Create the worker threads to concurrently update the shared file */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread\n");
      return(-2);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_join(thrds[i], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  return(0);
}
