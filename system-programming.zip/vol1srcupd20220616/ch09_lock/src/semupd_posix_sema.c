/*
 * Concurrent updates of shared variables by multiple threads using
 * POSIX unnamed semaphore as synchronization facility.
 * Copyright (c) 2013, 2019, 2021 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>   /* for POSIX semaphore */

/* Default values related to the shared file */
#define  NTHREADS    4                   /* number of concurrent threads */
#define  MAXNTHREADS 12                  /* max. number of concurrent threads */
#define  DEFUPDCNT   100000000           /* default update count */
#define  MAXDELAYCNT 1000                /* delay count */

/* Shared data */
unsigned int globalcnt = 0;
unsigned int globalcnt2 = 0;

/*
 * This function acquires the lock on a binary semaphore.
 * A semaphore value of 1 means the lock is available.
 * A semaphore value of 0 means the lock is unavailable.
 * This expects the semaphore's value to be initialized to 1 to begin with.
 * This function attempts to decrement the semaphore's value by 1 to obtain
 * the lock.
 */
int lock_posix_semaphore(sem_t *mysem)
{
  int   ret;

  if (mysem == NULL)
    return(EINVAL);
  ret = sem_wait(mysem);

  return(ret);
}

/*
 * This function releases the lock on a binary semaphore.
 * A semaphore value of 1 means the lock is available.
 * A semaphore value of 0 means the lock is unavailable.
 * This expects the semaphore's value to be initialized to 1 to begin with.
 * This function attempts to increment the semaphore's value by 1 to make
 * it available.
 */
int unlock_posix_semaphore(sem_t *mysem)
{
  int   ret;

  if (mysem == NULL)
    return(EINVAL);
  ret = sem_post(mysem);

  return(ret);
}

/*
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned long  *argp;
  unsigned long  myid;
  unsigned long  updcnt;
  int           ret;
  int           i, j;
  long          uselock=1;
  sem_t         *mysemptr;    /* address of POSIX semaphore */

  /* Extract input arguments (two unsigned long integers and one signed) */
  argp = (unsigned long *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    updcnt = argp[1];
    uselock = argp[2];
    mysemptr = (sem_t *)argp[3];
  }
  else
    pthread_exit((void *)(-1));

  fprintf(stdout, "Worker thread: myid=%u updcnt=%u \n", myid, updcnt);

  /* Do my job */
  for (i = 0; i < updcnt; i++)
  {
    if (uselock)
    {
      ret = lock_posix_semaphore(mysemptr);
      if (ret == -1)
      {
         fprintf(stderr, "lock_posix_semaphore() failed, ret=%d\n", ret);
         pthread_exit((void *)-1);
      }
    }
    globalcnt = globalcnt + 1;         /* update shared variable 1 */
    globalcnt2 = globalcnt2 + 1;       /* update shared variable 2 */
    if (uselock)
    {
      ret = unlock_posix_semaphore(mysemptr);
      if (ret == -1)
      {
         fprintf(stderr, "unlock_posix_semaphore() failed, ret=%d\n", ret);
         pthread_exit((void *)-1);
      }
    }
  }
    
  pthread_exit((void *)0);
}

int main(int argc, char *argv[])
{
  int     nthrd;                      /* actual number of worker threads */
  int     ret, retval;
  int     i;
  size_t  updcnt = DEFUPDCNT;         /* each thread's file update count */
  pthread_t     thrds[MAXNTHREADS];   /* threads */
  unsigned long args[MAXNTHREADS][4]; /* arguments for each thread */
  int           uselock;              /* use locking for update or not */
  sem_t         mysem;                /* my POSIX semaphore */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [uselock] [nthrd] [updcnt]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the lock switch, number of concurrent threads and update count
   * from the user, if any.
   */
  uselock = 1;
  if (argc > 1)
  {
    uselock = atoi(argv[1]);
    if (uselock != 0)
      uselock = 1;
  }

  nthrd = NTHREADS;
  if (argc > 2)
    nthrd = atoi(argv[2]);
  if (nthrd <= 0 || nthrd > MAXNTHREADS)
    nthrd = NTHREADS;

  updcnt = DEFUPDCNT;
  if (argc > 3)
    updcnt = atoi(argv[3]);
  if (updcnt <= 0)
    updcnt = DEFUPDCNT;

  fprintf(stdout, "Increment the values of two shared variables using %u "
    "threads, with each doing it %u times.\n", nthrd, updcnt);
  if (uselock)
    fprintf(stdout, "Locking is used during the updates.\n");
  else
    fprintf(stdout, "Locking is not used during the updates.\n");
  printf("At start, globalcnt=%d globalcnt2=%d\n", globalcnt, globalcnt2);

  /* Initialize the value of the semaphore -- value 1 means available */
  /* To be shared between threads and initial value is 1. */
  ret = sem_init(&mysem, 0, 1); // initialize POSIX semaphore
  if (ret == -1)
  {
    fprintf(stderr, "sem_init() failed, errno=%d\n", errno);
    ret = (-3);
    goto exit;
  }
  fprintf(stdout, "Initializing the semaphore value was successful.\n");

  /* Load up the input arguments for each worker thread */
  for (i = 0; i < nthrd; i++)
  {
    args[i][0] = i+1;      /* worker id starts with 1 */
    args[i][1] = updcnt;
    args[i][2] = uselock;
    args[i][3] = (unsigned long)&mysem;
  }

  /* Create the worker threads to concurrently update the shared variables */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread\n");
      ret = (-4);
      goto exit;
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value. Using a for loop tends to terminate after the first thread exits.
   */
  ret = pthread_join(thrds[0], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", 0, retval);
  ret = pthread_join(thrds[1], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", 1, retval);
  ret = pthread_join(thrds[2], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", 2, retval);
  ret = pthread_join(thrds[3], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", 3, retval);

exit:
  /* Remove the semaphore */
  ret = sem_destroy(&mysem);
  if (ret == -1)
  {
    fprintf(stderr, "sem_destroy() failed to remove, errno=%d\n", errno);
  }
  fprintf(stdout, "The semaphore set was successfully removed.\n");

  /* Report the end results */
  printf("At end, globalcnt=%d globalcnt2=%d\n", globalcnt, globalcnt2);

  return(ret);
}

