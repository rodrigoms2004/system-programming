/*
 * Concurrent updates of a shared file by multiple processes using
 * POSIX named semaphore as synchronization facility.
 * Read a number in ASCII form from a file, increment its value by one and
 * then write it back.
 * Copyright (c) 2019, 2021 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>   /* sem_open() */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>      /* read(), write(), getpid() */
#include <stdlib.h>      /* atoi(), atol(), atoll() */
#include <string.h>
#include <semaphore.h>   /* for POSIX semaphore */

#define MYSEMNAME  "/emupdf2_posix_named_sem"  /* name of POSIX semaphore */
#define MYDATAFILE "semupf2_datafile"  /* name of shared file */
#define BUFSZ 128          /* maximum length of shared data in file */
#define NPROC   4          /* number of concurrent processes */
#define UPDCNT 1000000     /* default update count */

/* Lock POSIX semaphore */
int acquire_lock(sem_t *mysemptr)
{
  if (mysemptr == NULL)
    return(EINVAL);
  return(sem_wait(mysemptr));
}

/* Unlock POSIX semaphore */
int release_lock(sem_t *mysemptr)
{
  if (mysemptr == NULL)
    return(EINVAL);
  return(sem_post(mysemptr));
}

/* Update shared data value in a file */
int update_shared_file_data(int fd, long updcnt, sem_t *mysemptr)
{
  ssize_t    bytes;
  char       indata[BUFSZ];
  char       outdata[BUFSZ];
  long       dataval, i;
  int        ret;
  size_t     len;

  if (fd <= 0)
    return(EINVAL);

  for (i = 0; i < updcnt; i++)
  {
    /* Acquire the lock */
    ret = acquire_lock(mysemptr);
    if (ret != 0)
    {
      fprintf(stderr, "In update_shared_file_data(), acquire_lock() failed, "
        "ret=%d\n", ret);
      return(ret); 
    }

    /* Read the data from the file */
    ret = lseek(fd, 0, SEEK_SET);
    bytes = read(fd, indata, BUFSZ);
    if (bytes < 0)
    {
      fprintf(stderr, "In update_shared_file_data(), read() failed, errno=%d\n",
        errno);
      release_lock(mysemptr);
      return(errno);
    }
  
    /* Update the data */
    indata[bytes] = '\0';
    dataval = atol(indata);
    dataval++;

    /* Write the data back into the file */
    sprintf(outdata, "%ld", dataval);
    len = strlen(outdata);
    outdata[len] = '\0';
    ret = lseek(fd, 0, SEEK_SET);
    bytes = write(fd, outdata, (len+1));
    if (bytes < 0)
    {
      fprintf(stderr, "In update_shared_file_data(), write() failed, errno=%d\n",
        errno);
      release_lock(mysemptr);
      return(errno);
    }
  
    /* Release the lock */
    release_lock(mysemptr);
  }

  return(0);
}

int main(int argc, char *argv[])
{
  int    ret = 0;
  int    fd = 0;
  int     nproc;
  long   updcnt = UPDCNT, i;
  char   *pathname = MYSEMNAME;    /* name od POSIX named semaphore */
  sem_t  *mysemptr=SEM_FAILED;     /* pointer to my POSIX semaphore */
  pid_t   pid;
  int     stat;   /* child's exit value */

  /* Get command-line arguments */
  nproc = NPROC;
  if (argc > 1)
    nproc = atoi(argv[1]);
  if (nproc <= 0)
    nproc = NPROC;

  updcnt = UPDCNT;
  if (argc > 2)
    updcnt = atol(argv[2]);
  if (updcnt <= 0)
    updcnt = UPDCNT;

  fprintf(stdout, "Update shared data in a file for %d times each with %d "
    " processes using POSIX named semaphore.\n", updcnt, nproc);

  /* Create a named POSIX semaphore for synchronization between processes */
  mysemptr = sem_open(pathname, O_CREAT, 0660, 1);
  if (mysemptr == SEM_FAILED)
  {
    fprintf(stderr, "sem_open() failed, errno=%d\n", errno);
    return(-1);
  }
  fprintf(stdout, "Creating/Opening POSIX named semaphore was successful.\n");

  /* Open the file */
  fd = open(MYDATAFILE, (O_CREAT|O_RDWR), 0600);
  if (fd < 0)
  {
    fprintf(stderr, "open('%s') failed, errno=%d\n", MYDATAFILE, errno);
    ret = -2;
    goto exit;
  }

  /* Create the worker processes and let them go to work */
  for (i = 1; i <= nproc; i++)
  {
    pid = fork();

    if (pid == -1)
    {
      fprintf(stderr, "fork() failed, i=%u, errno=%d\n", i, errno);
    }
    else if (pid == 0)
    {
      /* This is the child process. */
      /* Perform the child process' task here */
      /* Update the file */
      ret = update_shared_file_data(fd, updcnt, mysemptr);
      if (ret != 0)
      {
        fprintf(stderr, "update_shared_file_data() failed, ret=%d\n", ret);
        close(fd);
        return(ret);
      }
      return(0);
    }
    else
    {
      /* This is the parent process. */
      /* Simply return */
      return(0);
    }
  }

  /* Wait for all worker processes to finish */
  for (i = 0; i < nproc; i++)
  {
    pid = wait(&stat);
  }

exit:

  sem_close(mysemptr);

  /* Close the file */
  if (fd > 0) close(fd);
  return(ret);
}

