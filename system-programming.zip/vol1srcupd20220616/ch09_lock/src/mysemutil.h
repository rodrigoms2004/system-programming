/*
 * Include files, defines and utility functions for semaphore example programs.
 * Copyright (c) 2013, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>  /* memset and strcmp */

#include <sys/ipc.h>
#include <sys/sem.h>

#include <sys/wait.h>
#include <pthread.h>

/*
 * Defines
 */

#define  IPCKEYPATH  "/var/xyzinc/app1"  /* this file or directory must exist */
#define  IPCSUBID    'A'         /* project id identifying the semaphore set */
#define  NSEMS       3           /* number of semaphores in our semaphore set */
#define  ONESEM      1           /* only one semaphore in the semaphore set */
#define  MAXSEMS     128         /* maximum number of semaphores in our set */

#define  BLKSZ       512         /* block size */
#define  BUFSZ       (2*BLKSZ)   /* buffer size */
#define  INIT_VALUE  '0'         /* initial byte value */

/* Apple Darwin does not define struct seminfo. */
#ifdef __APPLE__
struct seminfo {
    int     semmap,             /* # of entries in semaphore map */
	    semmni,             /* # of semaphore identifiers */
	    semmns,             /* # of semaphores in system */
	    semmnu,             /* # of undo structures in system */
	    semmsl,             /* max # of semaphores per id */
	    semopm,             /* max # of operations per semop call */
	    semume,             /* max # of undo entries per process */
	    semusz,             /* size in bytes of undo structure */
	    semvmx,             /* semaphore maximum value */
	    semaem;             /* adjust on exit max value */
};
#endif

/* Trying to undefine "union semun" does not seem to work. */
#ifdef __APPLE__
#define _POSIX_C_SOURCE
#undef _DARWIN_C_SOURCE
#endif

/* Apple Darwin wrongly defines this in user space, against POSIX standard */
/* Besides, its definition is missing member "struct seminfo  *__buf" */
#ifndef __APPLE__
/*
 * The data type for the fourth argument to semctl() function.
 * The type 'union semun'.
 */
union semun {
    int              val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                (Linux specific) */
};
typedef union semun semun;
#else
typedef union semun semun;
#endif

/*
 * -------------------------------------------------------------------------
 * Declaration of utility functions.
 * -------------------------------------------------------------------------
 */

/*
 * This function gets and returns the identifier of the semaphore set specified.
 * It also creates the semaphore set if it does not already exist.
 */
int get_semaphore_set(char *pathname, int projid, int nsems, size_t perm);

/* This function sets the value of each semaphore in a semaphore set. */
int init_semaphore_set(int semid, int nsems, int semval);


/*
 * This function creates a file of the specified name, size (in bytes) and
 * permission and fills it with the value specified.
 */
int create_file(char *fname, size_t fsize, unsigned char val, int perm);

/*
 * This function randomly picks a block from a file and updates the very
 * first byte of it that is not the initial value as specified by the
 * parameter oldval. It replaces the initial byte value with the new byte
 * value specified by the newval parameter.
 */
int random_file_update(int fd, size_t fsize, unsigned char oldval, unsigned char newval);

/*
 * This function randomly picks a block from a file and updates the very
 * first byte of it that is not the initial value as specified by the
 * parameter oldval. It replaces the initial byte value with the new byte
 * value specified by the newval parameter.
 * The update repeats for the number of times specified by the updcnt
 * parameter.
 */
int random_file_update_all(char *fname, size_t fsize, unsigned char oldval, unsigned char newval, size_t updcnt);

/*
 * Count the number of occurrences of each character in '1' ... '9',
 * 'a' ... 'z' in a file.
 */
int count_char_occurrences(char *fanme);

/*
 * Semaphore functions.
 */
int lock_semaphore(int semid, int semnum);
int unlock_semaphore(int semid, int semnum);
int print_semaphore_set(int semid, int nsems);
