/*
 * Concurrent updates of two shared variables by multiple threads using
 * System V semaphore as locking facility.
 * Create the path "/var/xyzinc/app1" before running the program.
 * Copyright (c) 2013, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"
#include <time.h>        /* clock_gettime() */
#include <sys/time.h>    /* gettimeofday() */

/* Default values related to the shared file */
#define  NTHREADS    4                   /* number of concurrent threads */
#define  MAXNTHREADS 12                  /* number of concurrent threads */
#define  DEFUPDCNT   10000000            /* default update count */
#define  MAXDELAYCNT 1000                /* delay count */

/* Shared data */
unsigned int globalcnt = 0;
unsigned int globalcnt2 = 0;

/* These are our own locking functions in assembly language. */
int spinlock(int *lockvar);
int unlock(int *lockvar);

/*
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  updcnt;
  int           ret;
  int           i, j;
  int           uselock=1;
  int           semid;

  /* Extract input arguments (two unsigned integers and one signed) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    updcnt = argp[1];
    uselock = argp[2];
    semid = argp[3];
  }
  else
    pthread_exit((void *)(-1));

  fprintf(stdout, "Worker thread: myid=%u updcnt=%u semid=%u\n", 
    myid, updcnt, semid);

  /* Do my job */
  for (i = 0; i < updcnt; i++)
  {
    if (uselock)
    {
      ret = lock_semaphore(semid, 0);
      if (ret == -1)
      {
         fprintf(stderr, "semop() failed to lock, errno=%d\n", errno);
         pthread_exit((void *)-1);
      }
    }
    globalcnt = globalcnt + 1;         /* update shared variable 1 */
    for (j=0; j < MAXDELAYCNT; j++);   /* create a bit of delay */
    globalcnt2 = globalcnt2 + 1;       /* update shared variable 2 */
    if (uselock)
    {
      ret = unlock_semaphore(semid, 0);
      if (ret == -1)
      {
         fprintf(stderr, "semop() failed to unlock, errno=%d\n", errno);
         pthread_exit((void *)-1);
      }
    }
  }
    
  pthread_exit((void *)0);
}

int main(int argc, char *argv[])
{
  int     nthrd;                      /* actual number of worker threads */
  int     ret, retval;
  int     i;
  size_t  updcnt = DEFUPDCNT;         /* each thread's file update count */
  pthread_t     thrds[MAXNTHREADS];   /* threads */
  unsigned int  args[MAXNTHREADS][4]; /* arguments for each thread */
  int           uselock;              /* use locking for update or not */
  key_t  ipckey;
  int    semid;
  semun  semarg;
  struct timeval     tv1, tv2;     /* time structure for gettimeofday() */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [uselock] [nthrd] [updcnt]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the lock switch, number of concurrent threads and update count
   * from the user, if any.
   */
  uselock = 1;
  if (argc > 1)
  {
    uselock = atoi(argv[1]);
    if (uselock != 0)
      uselock = 1;
  }

  nthrd = NTHREADS;
  if (argc > 2)
    nthrd = atoi(argv[2]);
  if (nthrd <= 0 || nthrd > MAXNTHREADS)
    nthrd = NTHREADS;

  updcnt = DEFUPDCNT;
  if (argc > 3)
    updcnt = atoi(argv[3]);
  if (updcnt <= 0)
    updcnt = DEFUPDCNT;

  fprintf(stdout, "Increment the values of two shared variables using %u "
    "threads, with each doing it %lu times.\n", nthrd, updcnt);
  if (uselock)
    fprintf(stdout, "Locking is used during the updates.\n");
  else
    fprintf(stdout, "Locking is not used during the updates.\n");
  printf("At start, globalcnt=%d globalcnt2=%d\n", globalcnt, globalcnt2);

  /* Get current time */
  ret = gettimeofday(&tv1, (struct timezone *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "gettimeofday() failed, errno=%d\n", errno);
    return(ret);
  }
  fprintf(stdout, "current time at start  = %ld.%d\n",
    tv1.tv_sec, tv1.tv_usec);

  /* Create the semaphore */
  semid = get_semaphore_set(IPCKEYPATH, IPCSUBID, ONESEM, 0600);
  if (semid == -1)
  {
    fprintf(stderr, "get_semaphore_set() failed\n");
    return(-2);
  }
  fprintf(stdout, "The semaphore was successfully created, semid=%d.\n", semid);

  /* Initialize the value of the semaphore -- value 1 means available */
  ret = init_semaphore_set(semid, ONESEM, 1);
  if (ret == -1)
  {
    fprintf(stderr, "init_semaphore_set() failed\n");
    ret = (-3);
    goto exit;
  }
  fprintf(stdout, "Initializing the semaphore value was successful.\n");

  /* Load up the input arguments for each worker thread */
  for (i = 0; i < nthrd; i++)
  {
    args[i][0] = i+1;      /* worker id starts with 1 */
    args[i][1] = updcnt;
    args[i][2] = uselock;
    args[i][3] = semid;
  }

  /* Create the worker threads to concurrently update the shared variables */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread\n");
      ret = (-4);
      goto exit;
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_join(thrds[i], (void **)&retval);
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  /* Get current time */
  ret = gettimeofday(&tv2, (struct timezone *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "gettimeofday() failed, errno=%d\n", errno);
    return(ret);
  }
  fprintf(stdout, "current time at end    = %ld.%d\n",
    tv2.tv_sec, tv2.tv_usec);

exit:
  /* Remove the semaphore */
  ret = semctl(semid, 0, IPC_RMID);
  if (ret == -1)
  {
    fprintf(stderr, "semctl() failed to remove, errno=%d\n", errno);
  }
  fprintf(stdout, "The semaphore set was successfully removed.\n");

  /* Report the end results */
  printf("At end, globalcnt=%d globalcnt2=%d\n", globalcnt, globalcnt2);

  return(ret);
}

