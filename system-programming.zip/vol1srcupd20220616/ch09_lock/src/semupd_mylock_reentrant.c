/*
 * Making functions taking and releasing locks reentrantly.
 * Copyright (c) 2013, 2019, 2020 Mr. Jin-Jwei Chen.  All rights reserved.
 */

#include "mysemutil.h"

/* Default values related to the shared file */
#define  NTHREADS    2                   /* number of concurrent threads */
#define  MAXNTHREADS 12                  /* max. number of concurrent threads */
#define  NTASKS      5                   /* number of tasks */
#define  MAXDELAYCNT 10000000            /* delay count */

/* Shared lock variable */
int     lockvar=0;

/* Shared data for making locking functions thread reentrant */
static pthread_key_t   has_lock;      /* Thread specific data */

/* These are our own locking functions in assembly language. */
int spinlock(int *lockvar);
int unlock(int *lockvar);

int funcA(unsigned int  myid, int nestedcall);
int funcB(unsigned int  myid);

/* Routine used to lock resource XYZ */
void lockXYZ()
{
    spinlock(&lockvar);
}

/* Routine used to unlock resource XYZ */
void unlockXYZ()
{
    unlock(&lockvar);
}

/* Function A updates resource XYZ and also calls function B which
 * updates resource XYZ. too. */
int funcA(unsigned int  myid, int nestedcall)
{
  unsigned int  islocked=0;
  unsigned int  mylock=0;  /* remember if this invocation gets the lock */

  fprintf(stdout, "Thread %2d execute part 1 in function A\n", myid);

  /* Get information about if this thread has the lockXYZ or not */
  islocked = pthread_getspecific(has_lock);

  /* Try to acquire the lock only if this thread does not have the lock */
  if (islocked <= 0)
  {
    lockXYZ();
    islocked = 1;
    pthread_setspecific(has_lock, (void *)islocked);
    mylock++;
  }

  /* Do some funcA specific processing */
  fprintf(stdout, "Thread %2d execute part 2 in function A\n", myid);
  if (nestedcall)
    funcB(myid);

  /* Try to release the lock only if this thread has the lock AND
   * it's this invocation that actually acquired the lock */
  if (islocked > 0 && mylock > 0)
  {
    unlockXYZ();
    islocked = 0;
    pthread_setspecific(has_lock, (void *)islocked);
    mylock--;
  }
  fprintf(stdout, "Thread %2d return from function A\n", myid);
  return(0);
}

/* Function B updates resource XYZ, too. */
int funcB(unsigned int  myid)
{
  unsigned int  islocked=0;
  unsigned int  mylock=0;  /* remember if this invocation gets the lock */

  fprintf(stdout, "Thread %2d execute part 1 in function B\n", myid);

  /* Get information about if this thread has the lockXYZ or not */
  islocked = pthread_getspecific(has_lock);

  /* Try to acquire the lock only if this thread does not have the lock */
  if (islocked <= 0)
  {
    lockXYZ();
    islocked = 1;
    pthread_setspecific(has_lock, (void *)islocked);
    mylock++;
  }

  /* Do some funcB specific processing */
  fprintf(stdout, "Thread %2d execute part 2 in function B\n", myid);

  /* Try to release the lock only if this thread has the lock AND
   * it's this invocation that actually acquired the lock */
  if (islocked > 0 && mylock > 0)
  {
    unlockXYZ();
    islocked = 0;
    pthread_setspecific(has_lock, (void *)islocked);
    mylock--;
  }
  fprintf(stdout, "Thread %2d return from function B\n", myid);
  return(0);
}

/*
 * The worker thread.
 */

int worker_thread(void *args)
{
  unsigned int  *argp;
  unsigned int  myid;
  unsigned int  ntasks;
  int           ret = 0;
  int           i, j;
  int           nestedcall=1;
  unsigned int  islocked=0;      /* initial value of thread-specific data */

  /* Extract input arguments (two unsigned integers) */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    myid = argp[0];
    ntasks = argp[1];
    nestedcall = argp[2];
  }
  else
#ifdef SUN64
  {
    ret = (-1);
    pthread_exit((void *)&ret);
  }
#else
    pthread_exit((void *)(-1));
#endif

  fprintf(stdout, "Worker thread: myid=%u ntasks=%u\n", myid, ntasks);

  /* Initialize thread-specific data */
  ret = pthread_setspecific(has_lock, (void *)islocked);
  if (ret != 0)
  {
    fprintf(stderr, "worker_thread(): pthread_setspecific() failed, ret=%d\n",
      ret);
#ifdef SUN64
    ret = (-2);
    pthread_exit((void *)&ret);
#else
    pthread_exit((void *)(-2));
#endif
  }

  /* Do my job */
  for (i = 0; i < NTASKS; i++)
  {
    funcA(myid, nestedcall);
    for (j=0; j < MAXDELAYCNT; j++);   /* create a bit of delay */
  }
 
#ifdef SUN64
  pthread_exit((void *)&ret);
#else
  pthread_exit((void *)0);
#endif
}

int main(int argc, char *argv[])
{
  int     nthrd;                      /* actual number of worker threads */
  int     ret, retval;
#ifdef SUN64
  int     *retvalp = &retval;         /* pointer to returned value */
#endif
  int     i;
  size_t  ntasks = NTASKS;            /* each thread's task count */
  pthread_t     thrds[MAXNTHREADS];   /* threads */
  unsigned int  args[MAXNTHREADS][3]; /* arguments for each thread */
  int           nestedcall;           /* use locking for update or not */

  if ((argc > 1) && 
      ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "-help") == 0)))
  {
    fprintf(stdout, "Usage: %s [nestedcall] [nthrd] [ntasks]\n", argv[0]);
    return(-1);
  }

  /*
   * Get the number of concurrent threads, number of tasks to perform for
   * each thread and doing nested calls or not from the user, if any.
   */
  nestedcall = 1;
  if (argc > 1)
  {
    nestedcall = atoi(argv[1]);
    if (nestedcall != 0)
      nestedcall = 1;
  }

  nthrd = NTHREADS;
  if (argc > 2)
    nthrd = atoi(argv[2]);
  if (nthrd <= 0 || nthrd > MAXNTHREADS)
    nthrd = NTHREADS;

  ntasks = NTASKS;
  if (argc > 3)
    ntasks = atoi(argv[3]);
  if (ntasks <= 0)
    ntasks = NTASKS;

  fprintf(stdout, "Demonstration of making functions reentrant to prevent "
    "deadlock using %u threads, with each doing it %lu times.\n",
    nthrd, ntasks);
  if (nestedcall)
    fprintf(stdout, "Nested call is used in the demo.\n");
  else
    fprintf(stdout, "Nested call is not used in the demo.\n");

  /* Create the thread-specific data key and initialize its value to 0 */
  ret = pthread_key_create(&has_lock, (void *)NULL);
  if (ret != 0)
  {
    fprintf(stderr, "pthread_key_create() failed, ret=%d\n", ret);
    return(ret);
  }

  /* Load up the input arguments for each worker thread */
  for (i = 0; i < nthrd; i++)
  {
    args[i][0] = i+1;      /* worker id starts with 1 */
    args[i][1] = ntasks;
    args[i][2] = nestedcall;
  }

  /* Create the worker threads to concurrently update the shared file */
  for (i = 0; i < nthrd; i++)
  {
    ret = pthread_create(&thrds[i], (pthread_attr_t *)NULL,
          (void *(*)(void *))worker_thread, (void *)args[i]);
    if (ret != 0)
    {
      fprintf(stderr, "Failed to create the worker thread\n");
      return(-2);
    }
  }

  /*
   * Wait for each of the child threads to finish and retrieve its returned
   * value.
   */
  for (i = 0; i < nthrd; i++)
  {
#ifdef SUN64
    ret = pthread_join(thrds[i], (void **)&retvalp);
#else
    ret = pthread_join(thrds[i], (void **)&retval);
#endif
    fprintf(stdout, "Thread %u exited with return value %d\n", i, retval);
  }

  /* Destroy the thread-specific data key */
  ret = pthread_key_delete(has_lock);
  if (ret != 0)
  {
    fprintf(stderr, "pthread_key_delete() failed, ret=%d\n", ret);
    return(ret);
  }

  return(0);
}

