/*
 * A connection-oriented client program using Stream socket.
 * With socket buffer size options (SO_SNDBUF and SO_RCVBUF).
 * Turn on SO_LINGER socket option. 
 * Usage: tcpclnt_bufsz_linger srvname srvport linger
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2016, 2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <arpa/inet.h>     /* inet_addr(), inet_ntoa(), inet_ntop() */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <netdb.h>         /* gethostbyname() */
#include <sys/time.h>      /* gettimeofday *//* TEST ONLY */
#include <ctype.h>         /* isalpha() */
#include <unistd.h>        /* close() */

#define  BUFLEN      1024    /* size of input message buffer */
#define  DEFSRVPORT  2344    /* default server port number */
#define  MAXMSGS        4    /* Maximum number of messages to send */
#define  NAMELEN       63
#define  SOCKBUFSZ  1048576  /* socket buffer size */
#define  OUTBUFSZ   1048576  /* socket output buffer size */

int main(int argc, char *argv[])
{
  int    ret, i;
  int    sfd;                      /* file descriptor of the socket */
  struct sockaddr_in    server;    /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    fromaddr;  /* socket structure */
  socklen_t    fromaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   inbuf[BUFLEN];            /* input message buffer */
  char      *outbufp = NULL;       /* pointer to output message buffer */
  size_t    msglen;                /* length of reply message */
  size_t    msgnum=0;              /* count of request message */
  size_t    len;
  unsigned int addr;
  char   server_name[NAMELEN+1] = "localhost";
  int    socket_type = SOCK_STREAM;
  struct hostent *hp;
  int    option;
  socklen_t  optlen;
  int    bigbuf = 1;         /* increase socket buffer size (on by default) */
  struct linger   solinger;  /* for SO_LINGER option */
  int    lingeron = 0;       /* socket linger option (off by default) */
  int    totalBytes = 0;     /* total # of bytes received */

  fprintf(stdout, "Connection-oriented client program ...\n\n");

  /* Get the host name or IP address from command line. */
  if (argc > 1)
  {
    len = strlen(argv[1]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[1], len);
    server_name[len] = '\0';
  }

  /* Get the port number from command line. */
  if (argc > 2)
    portnum = atoi(argv[2]);
  if (portnum <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }

  /* Get switch to turn on/off linger option. */
  if (argc > 3)
    lingeron = atoi(argv[3]);
  if (lingeron < 0)
  {
    fprintf(stderr, "%s is an invalid switch value, use 1 or 0.\n", argv[3]);
    lingeron = 0;  /* By default, socket linger option off. */
  }

  /* Allocate output buffer */
  outbufp = (char *)malloc(OUTBUFSZ);
  if (outbufp == NULL)
  {
    fprintf(stderr, "malloc() failed to allocate output buffer memory.\n");
    return(ENOMEM);
  }

  /* Translate the host name or IP address into server socket address. */
  if (isalpha(server_name[0]))
  {  /* A host name is given. */
    hp = gethostbyname(server_name);
  }
  else
  {  /* Convert the n.n.n.n IP address to a number. */
    addr = inet_addr(server_name);
    hp = gethostbyaddr((char *)&addr, sizeof(addr), AF_INET);
  }
  if (hp == NULL )
  {
    fprintf(stderr,"Error: cannot get address for [%s], errno=%d\n",
      server_name, errno);
    return(-1);
  }

  /* Copy the resolved information into the sockaddr_in structure. */
  memset(&server, 0, sizeof(server));
  memcpy(&(server.sin_addr), hp->h_addr, hp->h_length);
  server.sin_family = hp->h_addrtype;
  server.sin_port = htons(portnum);

  /* Open a socket. */
  sfd = socket(AF_INET, socket_type, 0);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d\n", errno);
    return (-2);
  }

  /* Get socket output buffer size set by the OS. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
  }
  else
    fprintf(stdout, "originally, SO_SNDBUF was set to be %u\n", option);

  if (bigbuf)
  {
    /* Set socket output buffer size. */
    option = SOCKBUFSZ;
    ret = setsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, sizeof(option));
    if (ret < 0)
    {
      fprintf(stderr, "Error: setsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    }
    else
      fprintf(stdout, "SO_SNDBUF is set to be %u\n", option);

    /* Get socket output buffer size. */
    option = 0;
    optlen = sizeof(option);
    ret = getsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, &optlen);
    if (ret < 0)
    {
      fprintf(stderr, "Error: getsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    }
    else
      fprintf(stdout, "SO_SNDBUF now is %u\n", option);
  }

  fprintf(stdout, "\nSend request messages to server at port %d\n", portnum);

  /* Turn on SO_LINGER option if user says so. */
  if (lingeron)
  {
    solinger.l_onoff = 1;
    solinger.l_linger = 15;
    ret = setsockopt(sfd, SOL_SOCKET, SO_LINGER, &solinger, sizeof(solinger));
    if (ret < 0)
    {
      fprintf(stderr, "Error: setsockopt(SO_LINGER) failed, errno=%d\n", errno);
      close(sfd);
      return(-4);
    }
    else
      fprintf(stdout, "SO_LINGER socket option was successfully turned on.\n");
  }

  /* Connect to the server. */
  ret = connect(sfd, (struct sockaddr *)&server, srvaddrsz);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d\n", errno);
    close(sfd);
    return(-3);
  }

  /* Fill up output message buffer */
  for (i = 0; i < OUTBUFSZ; i++)
    outbufp[i] = 'A';

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    msgnum++;
    msglen = OUTBUFSZ;
    errno = 0;

    ret = send(sfd, outbufp, msglen, 0);
    if (ret >= 0)
    {
      totalBytes = totalBytes + ret;
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
      {
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
        /* For testing linger option only */
        if (msgnum >= MAXMSGS)
        {
          close(sfd);
          fprintf(stdout, "Total number of bytes sent is %d.\n", totalBytes);
          return(0);
        }
      }
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
          fprintf(stderr, "Error: recv() failed, errno=%d\n", errno);
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d\n", errno);

  }  /* while */

  close(sfd);
}

