/*
 * A connection-oriented server program using Stream socket.
 * Demonstrating use of SO_REUSEADDR socket option.
 * Support for multiple platforms including Linux, Windows, Solaris, AIX, HPUX.
 * Usage: tcpsrv_reuseaddr_all [port#] [reuseAddr]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017, 2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;                      /* return code */
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in6   srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in6);
  struct sockaddr_in6   clntaddr;  /* socket structure */
  socklen_t clntaddrsz = sizeof(struct sockaddr_in6);
  in_port_t portnum = DEFSRVPORT;  /* port number */
  int    portnum_in;               /* port number entered by user */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */
  unsigned int  msgcnt = 1;        /* message count */
  int    reuseAddr = 0;            /* SO_REUSEADDR option off by default */
  int    sw;                       /* value of option */
  int    v6only = 0;               /* IPV6_V6ONLY socket option off */
#if !WINDOWS
  struct timespec  sleeptm;        /* sleep time */
#endif
#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif
  int        option;               /* option value */
  socklen_t  optlen;               /* length of option value */

  fprintf(stdout, "Connection-oriented server program ...\n");

  /* Get the server's port number from user, if any. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = portnum_in;
  }

  /* Get switch on SO_REUSEADDR. */
  if (argc > 2)
    reuseAddr = atoi(argv[2]);

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET6, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* If instructed, turn on SO_REUSEADDR socket option so that the server can
     restart right away before the required TCP wait time period expires. */
  if (reuseAddr)
    sw = 1;
  else
    sw = 0;

  errno = 0;
  if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, (char *)&sw, sizeof(sw)) < 0)
  {
    fprintf(stderr, "setsockopt(SO_REUSEADDR) failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
  }
  else
  {
    if (sw)
      fprintf(stdout, "SO_REUSEADDR socket option is turned on.\n");
    else
      fprintf(stdout, "SO_REUSEADDR socket option is turned off.\n");
  }

  /* Get the current setting of the SO_SNDBUF socket option. */
  optlen = sizeof(option);
  option = 0;
  ret = getsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_REUSEADDR) failed, errno=%d\n", errno);
  }
  fprintf(stdout, "TCP SO_REUSEADDR's current setting is %u.\n", option);

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin6_family = AF_INET6;                 /* Internet socket */
  srvaddr.sin6_addr= in6addr_any;                 /* server's IP address */
  srvaddr.sin6_port = htons(portnum);             /* server's port number */

  /* Turn off IPV6_V6ONLY socket option. Default is on in Windows. */
  if (setsockopt(sfd, IPPROTO_IPV6, IPV6_V6ONLY, (char*)&v6only,
    sizeof(v6only)) != 0)
  {
    fprintf(stderr, "Error: setsockopt(IPV6_V6ONLY) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-5);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return(-6);
    }

    fprintf(stdout, "Client Connected.\n");

    while (1)
    {
      /* Receive a request from a client. */
      errno = 0;
      inbuf[0] = '\0';
      ret = recv(newsock, inbuf, BUFLEN, 0);
      if (ret > 0)
      {
        /* The three lines below are FOR TEST ONLY */
        CLOSE1(newsock);
        CLOSE(sfd);
        return(-1);

        /* Process the request. We simply print the request message here. */
        inbuf[ret] = '\0';
        fprintf(stdout, "\nReceived the following request from client:\n%s\n",
          inbuf);

        /* Construct a reply */
        sprintf(outbuf, "This is reply #%3u from the server program.", msgcnt++);
        msglen = strlen(outbuf);

        /* Send a reply. */
        errno = 0;
        ret = send(newsock, outbuf, msglen, 0);
        if (ret == -1)
          fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
        else
          fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
        /* Break here to create a situation where the server close first. */
        break;
      }
      else if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
          ERRNOSTR);
        break;
      }
      else
      {
        /* The client may have disconnected. */
        fprintf(stdout, "The client may have disconnected.\n");
        break;
      }
    }  /* while - inner */

    CLOSE1(newsock);
  }  /* while - outer */

  CLOSE(sfd);
  return(0);
}
