/*
 * A connection-oriented client program using Stream socket.
 * Demonstrating use of SO_REUSEADDR socket option.
 * This version works on Linux, Solaris, AIX, HPUX and Windows.
 * Usage: tcpclnt_reuse_all portnum server_hostname/IP 
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017, 2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                     /* socket file descriptor */
  in_port_t  portnum=DEFSRVPORT;  /* port number */
  char   *portnumstr  = DEFSRVPORTSTR; /* port number in string format */
  char   inbuf[BUFLEN];           /* input message buffer */
  char   outbuf[BUFLEN];          /* output message buffer */
  size_t msglen;                  /* length of reply message */
  size_t msgnum=0;                /* count of request message */
  size_t len;
  char   server_name[NAMELEN+1] = "localhost";
  struct addrinfo hints, *res=NULL;   /* address info */

#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  int winerror;                       /* error in Windows */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented client program ...\n");

  /* Get the server's port number from command line. */
  if (argc > 1)
  {
    portnum = atoi(argv[1]);
    portnumstr = argv[1];
  }
  if (portnum <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum, DEFSRVPORT);
    portnum = DEFSRVPORT;
    portnumstr = DEFSRVPORTSTR;
  }

  /* Get the server's host name or IP address from command line. */
  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2], len);
    server_name[len] = '\0';
  }

#if WINDOWS
  /* Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Translate the server's host name or IP address into socket address.
   * Fill in the hint information.
   */
  memset(&hints, 0x00, sizeof(hints));
    /* This works on AIX but not on Solaris, nor on Windows. */
    /* hints.ai_flags    = AI_NUMERICSERV; */
  hints.ai_family   = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  /* Get the address information of the server using getaddrinfo().  */
  ret = getaddrinfo(server_name, portnumstr, &hints, &res);
  if (ret != 0)
  {
    fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
      gai_strerror(ret));
#if !WINDOWS
    if (ret == EAI_SYSTEM)
      fprintf(stderr,"System error: errno=%d, %s\n", errno, strerror(errno));
#else
    WSACleanup();
#endif
    return(-2);
  }

  /* Create a socket. */
  sfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return (-3);
  }

  /* Connect to the server. */
  ret = connect(sfd, res->ai_addr, res->ai_addrlen);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  fprintf(stdout, "Send request messages to server(%s) at port %d\n",
   server_name, portnum);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
        {
          fprintf(stdout, "Warning: Zero bytes were received.\n");
          /* FOR TEST ONLY */
          if (msgnum == 1)
          {
#if WINDOWS
            Sleep(15000);
#else
            sleep(15);
#endif
            exit(0);
           }
        }
        else
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);

    /* Client waits a bit to ensure server closes its socket first. */
#if WINDOWS
    Sleep(1000); /* Unit is ms. For demo only. Remove this in real code. */
#else
    sleep(1);  /* For demo only. Remove this in real code. */
#endif
  }  /* while */

  /* Free the memory allocated by getaddrinfo() and close the socket. */
  freeaddrinfo(res);
  CLOSE(sfd);
  return(0);
}
