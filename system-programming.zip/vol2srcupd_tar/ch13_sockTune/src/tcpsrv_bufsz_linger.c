/*
 * A connection-oriented server program using Stream socket.
 * Single-threaded server.
 * With socket buffer size options (SO_SNDBUF and SO_RCVBUF).
 * Also turning on SO_KEEPALIVE and SO_LINGER socket options.
 * Usage: tcpsrv_bufsz_linger port_num bigbuf linger
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2016, 2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <sys/time.h>      /* gettimeofday *//* TEST ONLY */
#include <unistd.h>        /* close() */

#define  BUFLEN      1024    /* size of message buffer */
#define  DEFSRVPORT  2344    /* default server port number */
#define  BACKLOG        5    /* length of listener queue */
#define  SOCKBUFSZ  1048576  /* socket buffer size */
#define  INBUFSZ    1048576  /* socket input buffer size */

int main(int argc, char *argv[])
{
  int    ret, portnum_in=0;
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   *inbufp = NULL;           /* pointer to input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */
  int    option;
  socklen_t  optlen;
  int    bigbuf = 0;         /* increase socket buffer size (off by default) */
  int    lingeron = 0;       /* socket linger option (off by default) */
  struct linger   solinger;  /* for SO_LINGER option */
  int    totalBytes = 0;     /* total # of bytes received */

  fprintf(stdout, "Connection-oriented server program ...\n\n");

  /* Get the port number from user, if any. */
  if (argc > 1)
    portnum_in = atoi(argv[1]);
  if (portnum_in <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n\n",
      portnum_in, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }
  else
    portnum = portnum_in;

  /* Get switch to increase socket receive buffer size. */
  if (argc > 2)
    bigbuf = atoi(argv[2]);
  if (bigbuf < 0)
  {
    fprintf(stderr, "%s is an invalid switch value, use 1 or 0.\n", argv[2]);
    bigbuf = 0;  /* By default, do not increase socket buffer size. */
  }

  /* Get switch to turn on/off linger option. */
  if (argc > 3)
    lingeron = atoi(argv[3]);
  if (lingeron < 0)
  {
    fprintf(stderr, "%s is an invalid switch value, use 1 or 0.\n", argv[3]);
    lingeron = 0;  /* By default, socket linger option off. */
  }

  /* Allocate input buffer */
  inbufp = (char *)malloc(INBUFSZ+1);
  if (inbufp == NULL)
  {
    fprintf(stdout, "malloc() failed to allocate input buffer memory.\n");
    return(ENOMEM);
  }

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Get socket input buffer size set by the OS. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_RCVBUF, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_RCVBUF) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_RCVBUF was originally set to be %u\n", option);

  if (bigbuf)
  {
    /* Set socket input buffer size. */
    option = SOCKBUFSZ;
    ret = setsockopt(sfd, SOL_SOCKET, SO_RCVBUF, &option, sizeof(option));
    if (ret < 0)
      fprintf(stderr, "Error: setsockopt(SO_RCVBUF) failed, errno=%d\n", errno);
    else
      fprintf(stdout, "SO_RCVBUF is set to be %u\n", option);

    /* Get socket input buffer size. */
    option = 0;
    optlen = sizeof(option);
    ret = getsockopt(sfd, SOL_SOCKET, SO_RCVBUF, &option, &optlen);
    if (ret < 0)
      fprintf(stderr, "Error: getsockopt(SO_RCVBUF) failed, errno=%d\n", errno);
    else
      fprintf(stdout, "SO_RCVBUF now is %u\n", option);
  }

  /* Turn on SO_KEEPALIVE socket option. */
  option = 1;
  ret = setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_KEEPALIVE) failed, errno=%d\n", errno);
  }
  else
    fprintf(stdout, "SO_KEEPALIVE socket option is set.\n");

  /* Turn on SO_LINGER option. */
  if (lingeron)
  {
    solinger.l_onoff = 1;
    solinger.l_linger = 15;
    ret = setsockopt(sfd, SOL_SOCKET, SO_LINGER, &solinger, sizeof(solinger));
    if (ret < 0)
    {
      fprintf(stderr, "Error: setsockopt(SO_LINGER) failed, errno=%d\n", errno);
      close(sfd);
      return(-4);
    }
    else
      fprintf(stdout, "SO_LINGER socket option is successfully turned on.\n");
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin_family = AF_INET;                   /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d\n", errno);
    return(-2);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d\n", errno);
    close(sfd);
    return(-3);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d\n", errno);
      close(sfd);
      return(-4);
    }

    fprintf(stdout, "Client Connected.\n");

    /* Set the reply message */
    sprintf(outbuf, "%s", "This is a reply from the server program.");
    msglen = strlen(outbuf);
    totalBytes = 0;

    /* Receive and service requests from the current client. */
    while (1)
    {
      /* Receive a request from a client. */
      errno = 0;
      inbufp[0] = '\0';
      /* Note: recv() may return with buffer partially filled. */
      ret = recv(newsock, inbufp, INBUFSZ, 0);
      if (ret > 0)
      {
        /* Process the request. We simply print the request message here. */
        inbufp[ret] = '\0';
        fprintf(stdout, "\n%u bytes of data received at the server.\n", ret);
        totalBytes = totalBytes + ret;

        /* Send a reply. */
        errno = 0;
        ret = send(newsock, outbuf, msglen, 0);
        if (ret == -1)
          fprintf(stderr, "Error: send() failed, errno=%d\n", errno);
        else
          fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
      }
      else if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d\n", errno);
        break;
      }
      else
      {
        /* The client may have disconnected. */
        fprintf(stdout, "The client may have disconnected.\n");
        break;
      }
    }  /* while - inner */
    close(newsock);

    fprintf(stdout, "Total number of bytes received is %d.\n", totalBytes);

    break; /* TEST ONLY */

  }  /* while - outer */
}

