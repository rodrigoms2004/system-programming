/*
 * A connection-oriented server program using Stream socket.
 * Single-threaded server.
 * Tune parameters of SO_KEEPALIVE socket option in Oracle/Sun Solaris.
 * Copyright (c) 2002, 2014, 2018-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <unistd.h>        /* close() */
#include <netinet/tcp.h>   /* TCP_KEEPIDLE, TCP_KEEPCNT, TCP_KEEPINTVL */

#define  BUFLEN      1024    /* size of message buffer */
#define  DEFSRVPORT  2344    /* default server port number */
#define  BACKLOG        5    /* length of listener queue */

int main(int argc, char *argv[])
{
  int    ret, portnum_in=0;
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */
  int    option;

  fprintf(stdout, "Connection-oriented server program ...\n");

  /* Get the port number from user, if any. */
  if (argc > 1)
    portnum_in = atoi(argv[1]);
  if (portnum_in <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum_in, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }
  else
    portnum = portnum_in;

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Turn on SO_KEEPALIVE socket option. */
  option = 1;
  ret = setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_KEEPALIVE) failed, errno=%d\n", errno);
    close(sfd);
    return(-2);
  }
  else
    fprintf(stdout, "SO_KEEPALIVE socket option is enabled.\n");

  /* Set the TCP_KEEPALIVE_THRESHOLD socket option. This overrides the
   * tcp_keepalive_interval setting in Solaris kernel for the current socket.
   */
  option = 120000;  /* unit is ms */
  ret = setsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_THRESHOLD, &option, sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(TCP_KEEPALIVE_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-4);
  }
  fprintf(stdout, "TCP_KEEPALIVE_THRESHOLD is reset to (%d)\n", option);

  /* Set the TCP_KEEPALIVE_ABORT_THRESHOLD socket option. */
  option = 60000;  /* unit is ms */
  ret = setsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_ABORT_THRESHOLD, &option,
        sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(TCP_KEEPALIVE_ABORT_THRESHOLD) failed,"
      " errno=%d\n", errno);
    close(sfd);
    return(-5);
  }
  fprintf(stdout, "TCP_KEEPALIVE_ABORT_THRESHOLD is reset to (%d)\n", option);

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin_family = AF_INET;                   /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d\n", errno);
    close(sfd);
    return(-6);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d\n", errno);
    close(sfd);
    return(-7);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d\n", errno);
      close(sfd);
      return(-8);
    }

    fprintf(stdout, "Client Connected.\n");

    /* Set the reply message */
    sprintf(outbuf, "%s", "This is a reply from the server program.");
    msglen = strlen(outbuf);

    /* Receive and service requests from the current client. */
    while (1)
    {
      /* Receive a request from a client. */
      errno = 0;
      inbuf[0] = '\0';
      ret = recv(newsock, inbuf, BUFLEN, 0);
      if (ret > 0)
      {
        /* Process the request. We simply print the request message here. */
        inbuf[ret] = '\0';
        fprintf(stdout, "\nReceived the following request from client:\n%s\n",
          inbuf);

        /* Send a reply. */
        errno = 0;
        ret = send(newsock, outbuf, msglen, 0);
        if (ret == -1)
          fprintf(stderr, "Error: send() failed, errno=%d\n", errno);
        else
          fprintf(stdout, "%u of %u bytes of the reply was sent.\n", ret, msglen);
      }
      else if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d\n", errno);
        break;
      }
      else
      {
        /* The client may have disconnected. */
        fprintf(stdout, "The client may have disconnected.\n");
        break;
      }
    }  /* while - inner */
    close(newsock);

    /* The following two statements are for test only */
    close(sfd);
    break;

  }  /* while - outer */
}

