/*
 * Get and set socket options related to socket buffer sizes.
 * With TCP socket buffer size options.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2016, 2018 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <unistd.h>        /* close() */
#include <netinet/tcp.h>

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                      /* file descriptor of the socket */
  int        option;               /* option value */
  socklen_t  optlen;               /* length of option value */

  /* Create a Stream socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Get the original setting of the SO_SNDBUF socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    close(sfd);
    return(-2);
  }
  fprintf(stdout, "TCP SO_SNDBUF's original setting is %u.\n", option);

  /* Set the SO_SNDBUF socket option. */
  option = option + 2048;
  ret = setsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    close(sfd);
    return(-3);
  }
  fprintf(stdout, "TCP SO_SNDBUF is reset to %u.\n", option);

  /* Get the current setting of the SO_SNDBUF socket option. */
  option = 0;
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    close(sfd);
    return(-4);
  }
  fprintf(stdout, "TCP SO_SNDBUF's current setting is %u.\n", option);

  /* Set the SO_SNDBUF option to be above default maximum. This may fail. */ 
  /* By default, max. value allowed is 2 MB in AIX and 1 MB on Solaris. */
  option = 1024000;
  fprintf(stdout, "Trying to reset TCP SO_SNDBUF to %u.\n", option);
  ret = setsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    close(sfd);
    return(-5);
  }

  /* Get the current setting of the SO_SNDBUF socket option. */
  option = 0;
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
    close(sfd);
    return(-6);
  }
  fprintf(stdout, "TCP SO_SNDBUF's current setting is %u.\n", option);

  /* Make the connection after setting the socket buffer size(s) */

  close(sfd);
}

