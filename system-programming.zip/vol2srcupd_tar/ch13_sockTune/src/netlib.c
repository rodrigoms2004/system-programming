/*
 * Network utility functions
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2015, 2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "netlib.h"

/*
 * =========================================================================
 * Utility functions for getting the name or IP address of a host.
 */

/*
 * This function returns the name of this host (i.e. the local host).
 * The caller must provide the buffer (the buf parameter) to hold the returned
 * hostname. The size of this buffer (specified by the buflen parameter)
 * must be at least HOST_NAME_MAX bytes.
 * The function returns 0 on success or a non-zero value otherwise.
 */
int get_hostname(char *buf, size_t buflen)
{
  int   ret;

  if ((buf == NULL ) || (buflen < HOST_NAME_MAX))
    return(EINVAL);

  /* Get the hostname */
  memset((void *)buf, 0, buflen);
  errno = 0;
  ret = gethostname(buf, buflen);
  if (ret != 0)
  {
    fprintf(stderr, "get_hostname(): gethostname() failed, errno=%d\n", errno);
    return(errno);
  }

  return(0);
}

/*
 * This function returns the name of this host (i.e. the local host).
 * A NULL pointer is returned in case of error or failure.
 * The caller is responsible for freeing the memory associated with
 * the returned pointer.
 */
char *get_hostname2()
{
  int   ret;
  char  *hostnamep;

  /* Dynamically allocate the buffer holding the returned hostname string */
  hostnamep = malloc(HOST_NAME_MAX+1);
  if (hostnamep == NULL)
    return((char *)NULL);

  /* Get the hostname */
  memset((void *)hostnamep, 0, (HOST_NAME_MAX+1));
  ret = gethostname(hostnamep, HOST_NAME_MAX);
  if (ret != 0)
  {
    fprintf(stderr, "get_hostname2(): gethostname() failed, errno=%d\n", errno);
    free(hostnamep);
    return((char *)NULL);
  }

  return(hostnamep);
}

/*
 * Get the IP address of the specified host as a string.
 * If the hostname argument is null, IP address of the current host is returned.
 * Parameters:
 *   hostname - INPUT: name of host whose IP address is being looked up
 *              If NULL, the IP address of the local host will be returned.
 *   ipaddr - IN/OUT: starting address of buffer to hold returned IP address
 *            The IP address of the host will be returned in this buffer.
 *   ipaddrlen - INPUT: length (in bytes) of buffer in the second parameter
 *               The minimum size is MINIPADDRSZ bytes, just in case it's IPv6.
 * Return value: 0 if success, non-zero if failure
 */
int get_ipaddr_host(char *hostname, char *ipaddr, size_t ipaddrlen)
{
  char  hostname1[HOST_NAME_MAX+1];
  char  *hostnamep;
  struct hostent  *hp;
  char   **addrlp;
  char   *ptr;
  int    ret;

  if (ipaddr == NULL || ipaddrlen < MINIPADDRSZ)
    return(EINVAL);

  /* If host name is not given, get it here */
  if (hostname != NULL)
    hostnamep = hostname;
  else
  {
    hostnamep = hostname1;
    memset((void *)hostnamep, 0, (HOST_NAME_MAX+1));
    errno = 0;
    ret = gethostname(hostnamep, HOST_NAME_MAX);
    if (ret != 0)
    {
      fprintf(stderr, "get_ipaddr_host(): gethostname() failed, errno=%d\n",
        errno);
      return(errno);
    }
  }

  /* Get the IP address of the host */
  if ((hp = gethostbyname(hostnamep)) == NULL) {
    fprintf(stderr, "get_ipaddr_host(): gethostbyname() failed, h_errno=%d\n",
      h_errno);
    return(h_errno);
  }

  addrlp = hp->h_addr_list;
  if (addrlp == NULL) return(ENOENT);
  if (*addrlp == NULL) return(ENOENT);
  else
  {
    /* Convert IP address from number to text */
    memset((void *)ipaddr, 0, ipaddrlen);
    errno = 0;
    ptr = (char *)inet_ntop(hp->h_addrtype, *addrlp, ipaddr, ipaddrlen);
    if (ptr == NULL)
    {
      fprintf(stderr, "get_ipaddr_host(): inet_ntop() failed, errno=%d\n",
        errno);
      return(errno);
    }
  }

  return(0);
}

/*
 * Get the IP address of this host (i.e. the local host).
 * The caller needs to provide the output buffer for the IP address.
 * Parameters:
 *   ipaddr: (INPUT) - starting address of the buffer to receive the IP address
 *   ipaddrlen: (INPUT) - size in bytes of the buffer pointed to by ipaddr
 *             This buffer size must be at least MINIPADDRSZ bytes.
 */
int get_ipaddr(char *ipaddr, size_t ipaddrlen)
{
  int   ret;
  char  hostname[HOST_NAME_MAX+1];

  if (ipaddr == NULL || ipaddrlen < MINIPADDRSZ)
    return(EINVAL);

  ipaddr[0] = '\0';

  /* Get the hostname of this host */
  ret = get_hostname(hostname, HOST_NAME_MAX);
  if (ret != 0)
  {
    fprintf(stderr, "get_ipaddr(): get_hostname() failed, ret=%d\n", ret);
    return(ret);
  }
  hostname[HOST_NAME_MAX] = '\0';

  /* Get the IP address of this host */
  ret = get_ipaddr_host(hostname, ipaddr, ipaddrlen);
  if (ret != 0)
    fprintf(stderr, "get_ipaddr(): get_ipaddr_host() failed, ret=%d\n", ret);

  return(ret);
}

/*
 * Get the IP address of this host (i.e. the local host).
 * A pointer to the IP address string is returned on success.
 * The caller must free the memory pointed at by the returned pointer.
 * A NULL pointer is returned in case of failure.
 */
char *get_ipaddr2()
{
  int   ret = 0;
  char  *hostnamep = (char *)NULL;
  char  *ipaddrp = (char *)NULL;

  /* Get the hostname of this host */
  hostnamep = get_hostname2();
  if (hostnamep == (char *)NULL)
  {
    fprintf(stderr, "get_ipaddr2(): get_hostname2() failed.\n");
    return((char *)NULL);
  }

  /* Allocate the memory for the buffer holding the returned IP address */
  ipaddrp = malloc(MINIPADDRSZ+1);
  if (ipaddrp == (char *)NULL)
  {
    fprintf(stderr, "get_ipaddr2(): malloc() failed.\n");
    free(hostnamep);
    return((char *)NULL);
  }

  /* Get the IP address of this host */
  ipaddrp[0] = '\0';
  ret = get_ipaddr_host(hostnamep, ipaddrp, MINIPADDRSZ);
  if (ret != 0)
  {
    fprintf(stderr, "get_ipaddr2(): get_ipaddr_host() failed, ret=%d\n", ret);
    free(ipaddrp);
    ipaddrp = (char *)NULL;
  }

  ipaddrp[MINIPADDRSZ] = '\0';
  free(hostnamep);
  return(ipaddrp);
}

/* ==========================================================================
 * Utility functions for making network connections
 */

/*
 * Connect to a connection-oriented server
 * This function supports both IPv4 and IPv6 protocols.
 * Parameters:
 *   sfdp - OUTPUT, retruns socket file descriptor
 *   host - INPUT, hostname or IP address of the target server
 *   portnum - INPUT, port number of the server
 * The function return 0 on success and a non-zero value on failure.
 */
int connect_to_server(int *sfdp, char *host, int portnum)
{
  int    sfd;                      /* socket file descriptor */
  struct sockaddr_in    server;    /* IPv4 server socket's address */
  struct sockaddr_in6   server6;   /* IPv6 server socket's address */
  int    option;                   /* socket option */
  struct hostent *hp;
  struct in_addr   inaddr;         /* IPv4 address as an integer */
  struct in6_addr  inaddr6;        /* IPv6 address as an integer */
  int    protocol;
  int    ret;

  /* Check input arguments */
  if (sfdp == NULL || host == NULL)
    return(EINVAL);

  *sfdp = 0;

  /* For IPv6 this needs to be changed to have a more generic solution.
   * We need to include the case of numeric IPv6 addresses.
   */
  /* Translate the server's host name or IP address into socket address. */
  if (!strcmp(host, "::1"))
  {
    protocol = AF_INET6;
    hp = gethostbyname2(host, protocol);
  }
  else if (isdigit(host[0]))
  {
    /* Convert the numeric IP address to an integer. */
    protocol = AF_INET;
    ret = inet_pton(protocol, host, (void *)&inaddr);
    if (ret <= 0)
    {
      /* ret<0 means EAFNOSUPPORT, ret=0 means net addr invalid */
      protocol = AF_INET6;
      ret = inet_pton(protocol, host, (void *)&inaddr6);
      if (ret <= 0)
      {
        fprintf(stderr, "connect_to_server(): error, inet_pton() failed for"
          " [%s]," " errno=%d\n", host, errno);
        return(errno);
      }
    }
    if (protocol == AF_INET)
      hp = gethostbyaddr((char *)&inaddr, sizeof(inaddr), protocol);
    else if (protocol == AF_INET6)
      hp = gethostbyaddr((char *)&inaddr6, sizeof(inaddr6), protocol);
  }
  else
  {
    /* Assume a host name is given if it starts with a letter . */
    protocol = AF_INET;
    hp = gethostbyname(host);
    if (hp == NULL)
    {
      protocol = AF_INET6;
      hp = gethostbyname2(host, AF_INET6);
    }
  }

  if (hp == NULL )
  {
    fprintf(stderr, "connect_to_server(): error, cannot get address for [%s],"
      " errno=%d\n", host, errno);
    return(errno);
  }

  /* Copy the resolved information into sockaddr_in/sockaddr_in6 structure. */
  if (protocol == AF_INET)
  {
    memset((void *)&server, 0, sizeof(struct sockaddr_in));
    server.sin_family = hp->h_addrtype;    /* protocol */
    server.sin_port = htons(portnum);
    memcpy(&(server.sin_addr), hp->h_addr, hp->h_length);
  }
  else if (protocol == AF_INET6)
  {
    memset((void *)&server6, 0, sizeof(struct sockaddr_in6));
    server6.sin6_family = hp->h_addrtype;    /* protocol */
    server6.sin6_port   = htons(portnum);
    memcpy(&(server6.sin6_addr), hp->h_addr, hp->h_length);
  }

  /* Create a Stream socket. */
  sfd = socket(protocol, SOCK_STREAM, 0);
  if (sfd < 0)
  {
    fprintf(stderr, "connect_to_server(): error, socket() failed, errno=%d\n",
      errno);
    return (errno);
  }

  /* Set the SO_KEEPALIVE socket option. Do this before connect. */
  option = 1;
  ret = setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "connect_to_server(): warning, setsockopt(SO_KEEPALIVE) "
      "failed, errno=%d\n", errno);
  }

  /* Connect to the server. */
  if (protocol == AF_INET)
    ret = connect(sfd, (struct sockaddr *)&server, sizeof(struct sockaddr_in));
  else if (protocol == AF_INET6)
    ret = connect(sfd, (struct sockaddr *)&server6, sizeof(struct sockaddr_in6));
  if (ret == -1)
  {
    fprintf(stderr, "connect_to_server(): error, connect() failed on port %d,"
      " errno=%d\n", portnum, errno);
    close(sfd);
    return(errno);
  }

  *sfdp = sfd;
  return(0);
}

/*
 * Create a bound network communication endpoint
 * Bind to a well-known port
 * INPUT and OUTPUT:
 *   sfdp : pointer to a file descriptor
 *   srvaddrp: pointer to a sockaddr_in or sockaddr_in6 structure
 * INPUT:
 *   protocol: specify AF_INET for IPv4 or AF_INET6 for IPv6
 *   port : specify the server's port number or 0 for a client
 * Return 0 on success or other values if failure.
 */
int new_bound_endpt(int *sfdp, struct sockaddr *srvaddrp,
  sa_family_t protocol, int portnum)
{
  int    sfd;       /* socket file descriptor */
  struct sockaddr_in   *sap;     /* pointer to IPv4 socket address */
  struct sockaddr_in6  *sa6p;    /* pointer to IPv6 socket address */
  int    option;    /* socket option */
  int    ret;

  /* Check input arguments */
  if (sfdp == NULL || srvaddrp == NULL)
    return(EINVAL);
  if (!((protocol == AF_INET) || (protocol == AF_INET6)))
    return(EINVAL);

  *sfdp = 0;

  /* Create a Stream socket. */
  if ((sfd = socket(protocol, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "new_bound_endpt(): error, socket() failed,"
      " errno=%d\n", errno);
    return(errno);
  }

  /* Turn on SO_KEEPALIVE socket option. */
  option = 1;
  ret = setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "new_bound_endpt(): warning, setsockopt(SO_KEEPALIVE)"
      " failed, errno=%d\n", errno);
  }

  /* Fill in the socket address. */
  if (protocol == AF_INET)
  {
    sap = (struct sockaddr_in *)srvaddrp;
    memset((void *)sap, 0, sizeof(struct sockaddr_in));
    sap->sin_family = protocol;
    sap->sin_port   = htons(portnum);
    sap->sin_addr.s_addr = htonl(INADDR_ANY);
  }
  else if (protocol == AF_INET6)
  {
    sa6p = (struct sockaddr_in6 *)srvaddrp;
    memset((void *)sa6p, 0, sizeof(struct sockaddr_in6));
    sa6p->sin6_family = protocol;
    sa6p->sin6_port   = htons(portnum);
    sa6p->sin6_addr   = in6addr_any;
  }

  /* Bind the server or client socket to its address. */
  if (protocol == AF_INET)
    ret = bind(sfd, (struct sockaddr *)sap, sizeof(struct sockaddr_in));
  else if (protocol == AF_INET6)
    ret = bind(sfd, (struct sockaddr *)sa6p, sizeof(struct sockaddr_in6));

  if (ret != 0)
  {
    fprintf(stderr, "new_bound_endpt(): error, bind() failed,"
      " errno=%d\n", errno);
    close(sfd);
    return(errno);
  }

  /* If server, set maximum connection request queue length. */
  if (portnum > 0)
  {
    if (listen(sfd, LSNRBACKLOG) == -1) {
      fprintf(stderr, "new_bound_endpt(): error, listen() failed,"
        " errno=%d\n", errno);
      close(sfd);
      return(errno);
    }
  }

  *sfdp = sfd;
  return(0);
}

/*
 * Create a bound server network communication endpoint
 * Bind to a well-known port on the local host
 * INPUT and OUTPUT:
 *   sfdp : pointer to a file descriptor
 *   srvaddrp: pointer to a sockaddr_in or sockaddr_in6 structure
 * INPUT:
 *   protocol: specify AF_INET for IPv4 and AF_INET6 for IPv6
 *   port : specify the server's port number
 * Return 0 on success or other values if failure.
 */
int new_bound_srv_endpt(int *sfdp, struct sockaddr *srvaddrp,
  sa_family_t protocol, int portnum)
{
  int     ret;

  if (sfdp == NULL || srvaddrp == NULL)
    return(EINVAL);
  if (!((protocol == AF_INET) || (protocol == AF_INET6)))
    return(EINVAL);
  /* A server must use a known port number */
  if (portnum <= 0)
    return(EINVAL);

  ret = new_bound_endpt(sfdp, srvaddrp, protocol, portnum);
  return(ret);
}

/*
 * Create a bound client network communication endpoint
 * Bind to an available port number picked by the operating system
 * INPUT and OUTPUT:
 *   sfdp : pointer to a file descriptor
 *   srvaddrp: pointer to a sockaddr_in or sockaddr_in6 structure
 * INPUT only:
 *   protocol: specify AF_INET for IPv4 and AF_INET6 for IPv6
 * Return 0 on success or other values if failure.
 */
int new_bound_clnt_endpt(int *sfdp, struct sockaddr *srvaddrp, sa_family_t  protocol)
{
  int     ret;

  if (sfdp == NULL || srvaddrp == NULL)
    return(EINVAL);
  if (!((protocol == AF_INET) || (protocol == AF_INET6)))
    return(EINVAL);

  /* A client can bind to the next available port picked by the O.S. */
  ret = new_bound_endpt(sfdp, srvaddrp, protocol, 0);
  return(ret);
}

/* =====================  Network I/O functions  ========================== */

/*
 * Send a message whose fixd size is known using a socket.
 * Parameters:
 *   sfd (INPUT): socket file descriptor to be used
 *   bufp (INPUT): starting address of the message buffer
 *   msgsz (INPUT): length in bytes of the message to be sent
 *   flags (INPUT): flags for send() call
 * Return value:
 *   0 is returned on success. errno is returned if the send() call
 *   encounters an error. -1 is returned if the peer has closed its socket.
 */
int send_msg(int sfd, unsigned char *bufp, size_t msgsz, int flags)
{
  int      ret;         /* return code */
  ssize_t  nbytes;      /* number of bytes just being sent */
  size_t   total;       /* total number of bytes that have been sent */

  if ((sfd == 0) || (bufp == NULL) || (msgsz <= 0))
    return(EINVAL);

  errno = 0;
  total = 0;
  /* Make sure the entire message is sent */
  do
  {
    nbytes = send(sfd, bufp+total, msgsz-total, flags);
    if (nbytes > 0)
      total += nbytes;
    else
      break;
  } while (total < msgsz);

  if (total != msgsz)
  {
    if (nbytes < 0)
    {
      /* send() encounters an error */
      fprintf(stderr, "send_msg(): error, send() failed, errno=%d\n", errno);
      ret = errno;
    }
    else
    {
      /* Peer might have closed its socket */
      fprintf(stderr, "send_msg(): error, send() expected to send"
        " %lu bytes but sent only %lu bytes\n", msgsz, total);
      ret = (-1);
    }
  }
  else
    ret = 0;

  return(ret);
}

int receive_msg(int sfd, unsigned char *bufp, size_t msgsz, int flags)
{
  int      ret;         /* return code */
  ssize_t  nbytes;      /* number of bytes just received */
  size_t   total;       /* total number of bytes that have been received */

  if ((sfd == 0) || (bufp == NULL) || (msgsz <= 0))
    return(EINVAL);

  errno = 0;
  total = 0;
  /* Make sure the entire message is received */
  do
  {
    nbytes = recv(sfd, bufp+total, msgsz-total, flags);
    if (nbytes > 0)
      total += nbytes;
    else
      break;
  } while (total < msgsz);

  if (total != msgsz)
  {
    if (nbytes < 0)
    {
      /* recv() encounters an error */
      fprintf(stderr, "recv_msg(): error, recv() failed, errno=%d\n", errno);
      ret = errno;
    }
    else
    {
      /* Peer might have closed its socket */
      fprintf(stderr, "receive_msg(): error, recv() expected to receive"
        " %lu bytes but got only %lu bytes\n", msgsz, total);
      ret = (-1);
    }
  }
  else
    ret = 0;

  return(ret);
}

/* Print the contents of a binary buffer */
void print_binary_buf(unsigned char *buf, unsigned int buflen)
{
  int   i;

  if (buf == NULL) return;
  printf("0x");
  for (i = 0; i < buflen; i++)
    printf("%02x", buf[i]);
  printf("\n");
}

