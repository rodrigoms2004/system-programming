/*
 * A connection-oriented client program using Stream socket.
 * Demonstration of SO_RCVTIMEO socket option.
 * Connecting to a server program on any host using a hostname or IP address.
 * Support for IPv4 and IPv6 and multiple platforms including 
 * Linux, Windows, Solaris, AIX and HPUX.
 * Usage: tcpclnt_timeo_all [srvport# [server-hostname | server-ipaddress]]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"
#define TOSECONDS  10

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                     /* socket file descriptor */
  in_port_t  portnum=DEFSRVPORT;  /* port number */
  int    portnum_in = 0;          /* port number user provides */
  char   *portnumstr  = DEFSRVPORTSTR; /* port number in string format */
  char   inbuf[BUFLEN];           /* input message buffer */
  char   outbuf[BUFLEN];          /* output message buffer */
  size_t msglen;                  /* length of reply message */
  size_t msgnum=0;                /* count of request message */
  size_t len;
  char   server_name[NAMELEN+1] = SERVER_NAME;
  struct addrinfo hints, *res=NULL;  /* address info */
  int    option;
  socklen_t  optlen;
  struct timeval tmout;            /* timeout value */

#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented client program ...\n");

  /* Get the server's port number from command line. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
      portnumstr = DEFSRVPORTSTR;
    }
    else
    {
      portnum = (in_port_t)portnum_in;
      portnumstr = argv[1];
    }
  }

  /* Get the server's host name or IP address from command line. */
  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2], len);
    server_name[len] = '\0';
  }

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Translate the server's host name or IP address into socket address.
   * Fill in the hint information.
   */
  memset(&hints, 0x00, sizeof(hints));
    /* This works on AIX but not on Solaris, nor on Windows. */
    /* hints.ai_flags    = AI_NUMERICSERV; */
  hints.ai_family   = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_protocol = IPPROTO_TCP;

  /* Get the address information of the server using getaddrinfo().
   * This function returns errors directly or 0 for success. On success,
   * argument res contains a linked list of addrinfo structures.
   */
  ret = getaddrinfo(server_name, portnumstr, &hints, &res);
  if (ret != 0)
  {
    fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
      gai_strerror(ret));
#if !WINDOWS
    if (ret == EAI_SYSTEM)
      fprintf(stderr,"System error: errno=%d, %s\n", errno, strerror(errno));
#else
    WSACleanup();
#endif
    return(-2);
  }

  /* Create a socket. */
  sfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return (-3);
  }

  /* Connect to the server. */
  ret = connect(sfd, res->ai_addr, res->ai_addrlen);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Get the socket receive timeout value set by the OS. */
  optlen = sizeof(tmout);
  memset((void *)&tmout, 0, optlen);
  ret = getsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, &tmout, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_RCVTIMEO) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
  }
  else
    fprintf(stdout, "SO_RCVTIMEO was originally set to be %lu:%u\n",
      tmout.tv_sec, tmout.tv_usec);

  /* Set the socket receive timeout value. */
#if WINDOWS
  tmout.tv_sec = TOSECONDS*1000;  /* Unit is milliseconds in Windows */
#else
  tmout.tv_sec = TOSECONDS;  /* Unit is seconds in Linux and Unix */
#endif
  tmout.tv_usec = 0;
  ret = setsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, &tmout, optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_RCVTIMEO) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
  }
  else
    fprintf(stdout, "SO_RCVTIMEO is set to be %lu:%u\n",
      tmout.tv_sec, tmout.tv_usec);

  /* Get the socket receive timeout value. */
  memset((void *)&tmout, 0, optlen);
  ret = getsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, &tmout, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_RCVTIMEO) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
  }
  else
    fprintf(stdout, "SO_RCVTIMEO now is %lu:%u\n",
      tmout.tv_sec, tmout.tv_usec);

  fprintf(stdout, "Send request messages to server(%s) at port %d\n",
   server_name, portnum);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
        {
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
          break;  /* For demo only. Remove this in real code. */
        }
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);

    /* Sleep a second. For demo only. Remove this in real code. */
#if WINDOWS
    Sleep(1000); /* Unit is ms. For demo only. Remove this in real code. */
#else
    sleep(1);  /* For demo only. Remove this in real code. */
#endif
  }  /* while */

  /* Free the memory allocated by getaddrinfo() */
  freeaddrinfo(res);
  CLOSE(sfd);
  return(0);
}
