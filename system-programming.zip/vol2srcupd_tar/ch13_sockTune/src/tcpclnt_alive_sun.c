/*
 * A connection-oriented client program using Stream socket.
 * Tune parameters of SO_KEEPALIVE socket option in Oracle/Sun Solaris.
 * Copyright (c) 2002, 2014, 2018-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <netdb.h>         /* gethostbyname() */
#include <unistd.h>        /* close() */
#include <netinet/tcp.h>   /* TCP_KEEPIDLE, TCP_KEEPCNT, TCP_KEEPINTVL */
#include <arpa/inet.h>
#include <ctype.h>

#define  BUFLEN      1024    /* size of input message buffer */
#define  DEFSRVPORT  2344    /* default server port number */
#define  MAXMSGS        4    /* Maximum number of messages to send */
#define  NAMELEN       63

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                      /* file descriptor of the socket */
  struct sockaddr_in    server;    /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    fromaddr;  /* socket structure */
  socklen_t    fromaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t    msglen;                /* length of reply message */
  size_t    msgnum=0;              /* count of request message */
  size_t    len;
  unsigned int addr;
  char   server_name[NAMELEN+1] = "localhost";
  int    socket_type = SOCK_STREAM;
  struct hostent *hp;
  int    option;
  socklen_t  optlen;

  fprintf(stdout, "Connection-oriented client program ...\n\n");

  /* Get the host name or IP address from command line. */
  if (argc > 1)
  {
    len = strlen(argv[1]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[1], len);
    server_name[len] = '\0';
  }

  /* Get the port number from command line. */
  if (argc > 2)
    portnum = atoi(argv[2]);
  if (portnum <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }

  /* Translate the host name or IP address into server socket address. */
  if (isalpha(server_name[0]))
  {  /* A host name is given. */
    hp = gethostbyname(server_name);
  }
  else
  {  /* Convert the n.n.n.n IP address to a number. */
    addr = inet_addr(server_name);
    hp = gethostbyaddr((char *)&addr, sizeof(addr), AF_INET);
  }
  if (hp == NULL )
  {
    fprintf(stderr,"Error: cannot get address for [%s], errno=%d\n",
      server_name, errno);
    return(-1);
  }

  /* Copy the resolved information into the sockaddr_in structure. */
  memset(&server, 0, sizeof(server));
  memcpy(&(server.sin_addr), hp->h_addr, hp->h_length);
  server.sin_family = hp->h_addrtype;
  server.sin_port = htons(portnum);

  /* Open a socket. */
  sfd = socket(AF_INET, socket_type, 0);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d\n", errno);
    return (-2);
  }

  /* Get the SO_KEEPALIVE socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(SO_KEEPALIVE) failed, errno=%d\n", errno);
    close(sfd);
    return(-3);
  }
  if (option == 0)
    fprintf(stdout, "SO_KEEPALIVE socket option was not set (%d) by default.\n",
      option);

  /* Set the SO_KEEPALIVE socket option. Do this before connect. */
  option = 1;
  ret = setsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_KEEPALIVE) failed, errno=%d\n", errno);
    close(sfd);
    return(-4);
  }
  else
    fprintf(stdout, "SO_KEEPALIVE socket option is now enabled.\n");

  /* Get the TCP_KEEPALIVE_THRESHOLD socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_THRESHOLD, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(TCP_KEEPALIVE_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-5);
  }
  fprintf(stdout, "TCP_KEEPALIVE_THRESHOLD's original setting is (%d)\n", option);

  /* Set the TCP_KEEPALIVE_THRESHOLD socket option. This overrides the
   * tcp_keepalive_interval setting in Solaris kernel for the current socket.
   */
  option = 300000;  /* unit is ms */
  ret = setsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_THRESHOLD, &option, optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(TCP_KEEPALIVE_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-6);
  }
  fprintf(stdout, "TCP_KEEPALIVE_THRESHOLD is reset to (%d)\n", option);

  /* Get the TCP_KEEPALIVE_THRESHOLD socket option. */
  option = 0;
  ret = getsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_THRESHOLD, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(TCP_KEEPALIVE_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-7);
  }
  fprintf(stdout, "TCP_KEEPALIVE_THRESHOLD's current setting is (%d)\n", option);

  /* Get the TCP_KEEPALIVE_ABORT_THRESHOLD socket option. */
  option = 0;
  ret = getsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_ABORT_THRESHOLD, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(TCP_KEEPALIVE_ABORT_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-8);
  }
  fprintf(stdout, "TCP_KEEPALIVE_ABORT_THRESHOLD's original setting is (%d)\n", option);

  /* Set the TCP_KEEPALIVE_ABORT_THRESHOLD socket option. */
  option = 60000;  /* unit is ms */
  ret = setsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_ABORT_THRESHOLD, &option, optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: setsockopt(TCP_KEEPALIVE_ABORT_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-9);
  }
  fprintf(stdout, "TCP_KEEPALIVE_ABORT_THRESHOLD is reset to (%d)\n", option);

  /* Get the TCP_KEEPALIVE_ABORT_THRESHOLD socket option. */
  option = 0;
  ret = getsockopt(sfd, IPPROTO_TCP, TCP_KEEPALIVE_ABORT_THRESHOLD, &option, &optlen);
  if (ret < 0)
  {
    fprintf(stderr, "Error: getsockopt(TCP_KEEPALIVE_ABORT_THRESHOLD) failed, errno=%d\n", errno);
    close(sfd);
    return(-10);
  }
  fprintf(stdout, "TCP_KEEPALIVE_ABORT_THRESHOLD's current setting is (%d)\n", option);

  /* Connect to the server. */
  ret = connect(sfd, (struct sockaddr *)&server, srvaddrsz);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d\n", errno);
    close(sfd);
    return(-11);
  }

  fprintf(stdout, "\nSend request messages to server at port %d\n", portnum);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4d%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%u bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %u bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
          fprintf(stderr, "Error: recv() failed, errno=%d\n", errno);
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d\n", errno);

    sleep(5);  /* Pause so we can pull the cable. For testing only. */
  }  /* while */

  close(sfd);
}

