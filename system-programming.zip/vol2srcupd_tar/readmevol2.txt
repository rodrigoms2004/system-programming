These are example programs in the book
"System Programming vol II by Jin-Jwei Chen".
