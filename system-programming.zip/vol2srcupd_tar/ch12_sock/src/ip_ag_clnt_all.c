/*
 * This is a cross-platform IP-agnostic TCP client program.
 * It uses getaddrinfo() to find out if the server is a IPv4 or IPv6.
 * If the user provides a server host name or IP address, that is used.
 * Otherwise, localhost is used. 2345 is the default port number.
 * This program allows users to easily test IPv4 and IPv6 combinations
 * using the same program without recompilation.
 * This program also prints the communication partner's IP address.
 * Support for multiple platforms including Linux, Windows, Solaris, AIX, HPUX
 * and Apple Darwin.
 * Usage: ip_ag_clnt_all [srvport [server_hostname_or_IP]]
 * Use -DWINDOWS compiler flag to build in Windows.
 * Authored by Jin-Jwei Chen.
 * Copyright (c) 2005-2018, 2020-2022 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

/*
 * First command line argument is expected to be either the IP address
 * or host name of the server. Second argument is server's port number.
 */
int main(int argc, char *argv[])
{
  /* Variables and structures */
  int    sfd=-1;                      /* socket file descriptor */
  int    ret;                         /* function's return code */
  int    bytesRead=0;                 /* number of bytes received so far */
  char   buffer[BUFLEN1];       /* I/O data buffer */
  char   server[NETDB_MAX_HOST_NAME_LENGTH];  /* server's name or address */
  char   servport[12] = DEFSRVPORTSTR;        /* server's port number */
  struct in6_addr serveraddr;         /* server's socket address */
  struct addrinfo hints;              /* hints to getaddrinfo() */
  struct addrinfo *res=NULL;          /* results from getaddrinfo() */
  char srvipaddr[INET6_ADDRSTRLEN+1]; /* server's IP address in string format */
  int niflags = (NI_NUMERICHOST|NI_NUMERICSERV);  /* flags for getnameinfo() */
#if WINDOWS
  short        addrFam;               /* address/protocol family */
#else
  sa_family_t  addrFam;               /* address/protocol family */
#endif
#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  /* Get the server's hostname or IP address and port number from user */
  if (argc > 1)
    strcpy(servport, argv[1]);

  if (argc > 2)
    strcpy(server, argv[2]);
  else
    strcpy(server, SERVER_NAME);

#if WINDOWS
  /* Use at least Winsock version 2.2 */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0) {
    fprintf(stderr, "WSAStartup failed with error %d: %s\n",
            ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  do
  {
    memset(&hints, 0x00, sizeof(hints));
    /* AI_NUMERICSERV flag works on AIX but not on Solaris, nor on Windows.
    hints.ai_flags    = AI_NUMERICSERV;
    */
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    /* Look up the server's address information. The input parameter
       'server' can be a host name or IP address. */
    ret = getaddrinfo(server, servport, &hints, &res);
    if (ret != 0)
    {
      fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
        gai_strerror(ret)); 
#if !WINDOWS
      if (ret == EAI_SYSTEM)
        fprintf(stderr, "System error: errno=%d, %s\n", errno, strerror(errno));
#endif
      break;
    }

    /* Get and print the server's IP address. */
    if (res->ai_family == AF_INET)
    {
      fprintf(stdout, "Server %s is IPv4.\n", server);
      ret = getnameinfo(res->ai_addr, sizeof(struct sockaddr_in),
          srvipaddr, INET6_ADDRSTRLEN, NULL, 0,  niflags);
    }
    else if (res->ai_family == AF_INET6)
    {
      fprintf(stdout, "Server %s is IPv6.\n", server);
      ret = getnameinfo(res->ai_addr, sizeof(struct sockaddr_in6),
          srvipaddr, INET6_ADDRSTRLEN, NULL, 0,  niflags);
    }
    else
    {
      fprintf(stderr, "Unexpected address family %u\n", res->ai_family);
      break;
    }

    if (ret == 0)
      fprintf(stdout, "Server IP address is %s.\n", srvipaddr);
    else
      fprintf(stderr, "Error: getnameinfo() failed, error %d, %s\n", ret,
        gai_strerror(ret));

    addrFam = res->ai_family;

    /* Create the socket */
    sfd = socket(addrFam, res->ai_socktype, res->ai_protocol);
    if (sfd < 0)
    {
      fprintf(stderr, "First socket() failed with error %d: %s.\n",
              ERRNO, ERRNOSTR);

      /* First IP-type fails. Try another IP type. */
      if (addrFam == AF_INET) {
        addrFam = AF_INET6;
        fprintf(stdout, "Try to switch to IPv6 ...\n");
      } else if (addrFam == AF_INET6) {
        addrFam = AF_INET;
        fprintf(stdout, "Try to switch to IPv4 ...\n");
      } else
        break;

      sfd = socket(addrFam, res->ai_socktype, res->ai_protocol);
      if (sfd < 0)
      {
        fprintf(stderr, "Second socket() failed with error %d: %s\n",
                ERRNO, ERRNOSTR);
        break;
      }
    }
    fprintf(stdout, "Client is using an IPv%1d socket.\n", 
      (addrFam == AF_INET6)?6:4);

    /* Connect to the server */
    ret = connect(sfd, res->ai_addr, res->ai_addrlen);
    if (ret < 0)
    {
      /* Note that the res returned by getaddrinfo() contains a linked list
       * of the server's addresses found. So one could potentially try the
       * next one in the list if the current one fails.
       */
       fprintf(stderr, "connect() failed with error %d: %s\n",
              ERRNO, ERRNOSTR);
       break;
    }

    /* Send a message to the server */
    memset(buffer, 'a', sizeof(buffer));
    ret = send(sfd, buffer, sizeof(buffer), 0);
    if (ret < 0)
    {
      fprintf(stderr, "send() failed with error %d: %s\n",
              ERRNO, ERRNOSTR);
      break;
    }
    fprintf(stdout, "A message of %lu bytes was sent to server.\n",
        sizeof(buffer));

    /* Receive the reply from the server */
    while (bytesRead < BUFLEN1)
    {
      ret = recv(sfd, & buffer[bytesRead], BUFLEN1 - bytesRead, 0);
      if (ret < 0)
      {
        fprintf(stderr, "recv() failed with error %d: %s\n",
             ERRNO, ERRNOSTR);
        break;
      }
      else if (ret == 0)
      {
        fprintf(stdout, "The server may have closed the connection.\n");
        break;
      }

      bytesRead += ret;
    }  /* while */

    buffer[bytesRead] = '\0';
    fprintf(stdout, "Server's reply message:\n%s\n", buffer);

  } while (FALSE);

  /* Close the socket */
  if (sfd != -1)
    CLOSE1(sfd);

  /* Free the results returned from getaddrinfo() */
  if (res != NULL)
    freeaddrinfo(res);

#if WINDOWS
  WSACleanup();
#endif
  return(0);
}
