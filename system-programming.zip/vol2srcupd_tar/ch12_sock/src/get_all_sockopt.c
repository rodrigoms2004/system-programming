/*
 * Get all socket options at the socket level (SOL_SOCKET).
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2016, 2018-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <unistd.h>        /* close() */
#include <netinet/tcp.h>
#include <string.h>        /* memset() */
#include <sys/time.h>      /* struct timeval */

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                      /* file descriptor of the socket */
  int        option;               /* option value */
  socklen_t  optlen;               /* length of option value */
  struct linger  linger;           /* linger on/off & time */
  struct timeval  tmout;           /* send/receive timeout */

  /* Create a Stream socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d\n", errno);
    return(-1);
  }

  /* Get the SO_ACCEPTCONN socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_ACCEPTCONN, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_ACCEPTCONN) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_ACCEPTCONN's current setting is %d\n", option);

  /* Get the SO_BROADCAST socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_BROADCAST, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_BROADCAST) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_BROADCAST's current setting is %d\n", option);

  /* Get the SO_DEBUG socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_DEBUG, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_DEBUG) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_DEBUG's current setting is %d\n", option);

  /* Get the SO_DONTROUTE socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_DONTROUTE, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_DONTROUTE) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_DONTROUTE's current setting is %d\n", option);

  /* Get the SO_ERROR socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_ERROR, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_ERROR) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_ERROR's current setting is %d\n", option);

  /* Get the SO_KEEPALIVE socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_KEEPALIVE, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_KEEPALIVE) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_KEEPALIVE's current setting is %d\n", option);

  /* Get the SO_LINGER socket option. */
  optlen = sizeof(struct linger);
  memset((void *)&linger, 0, optlen);
  ret = getsockopt(sfd, SOL_SOCKET, SO_LINGER, &linger, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_LINGER) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_LINGER's current setting is onoff=%u linger_time=%u\n",
      linger.l_onoff, linger.l_linger);

  /* Get the SO_OOBINLINE socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_OOBINLINE, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_OOBINLINE) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_OOBINLINE's current setting is %d\n", option);

  /* Get the SO_RCVBUF socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_RCVBUF, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_RCVBUF) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_RCVBUF's current setting is %d\n", option);

  /* Get the SO_RCVLOWAT socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_RCVLOWAT, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_RCVLOWAT) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_RCVLOWAT's current setting is %d\n", option);

  /* Get the SO_RCVTIMEO socket option. */
  optlen = sizeof(struct timeval);
  memset((void *)&tmout, 0, optlen);
  ret = getsockopt(sfd, SOL_SOCKET, SO_RCVTIMEO, &tmout, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_RCVTIMEO) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_RCVTIMEO's current setting is %lu:%u\n",
      tmout.tv_sec, tmout.tv_usec);

  /* Get the SO_REUSEADDR socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_REUSEADDR) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_REUSEADDR's current setting is %d\n", option);

  /* Get the SO_REUSEPORT socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_REUSEPORT, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_REUSEPORT) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_REUSEPORT's current setting is %d\n", option);

  /* Get the SO_SNDBUF socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDBUF, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_SNDBUF) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_SNDBUF's current setting is %d\n", option);

  /* Get the SO_SNDLOWAT socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDLOWAT, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_SNDLOWAT) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_SNDLOWAT's current setting is %d\n", option);

  /* Get the SO_SNDTIMEO socket option. */
  optlen = sizeof(struct timeval);
  memset((void *)&tmout, 0, optlen);
  ret = getsockopt(sfd, SOL_SOCKET, SO_SNDTIMEO, &tmout, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_SNDTIMEO) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_SNDTIMEO's current setting is %lu:%u\n",
      tmout.tv_sec, tmout.tv_usec);

  /* Get the SO_TYPE socket option. */
  option = 0;
  optlen = sizeof(option);
  ret = getsockopt(sfd, SOL_SOCKET, SO_TYPE, &option, &optlen);
  if (ret < 0)
    fprintf(stderr, "Error: getsockopt(SO_TYPE) failed, errno=%d\n", errno);
  else
    fprintf(stdout, "SO_TYPE's current setting is %d\n", option);

  close(sfd);
}
