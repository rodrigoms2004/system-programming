/*
 * Multicast message sender
 * This program sends a message via multicasting.
 * Usage: multicast_snd ip_address_of_local_interface
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2017-8, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main (int argc, char *argv[ ])
{
  struct sockaddr_in mcastgrp;    /* address of the multicast group */
  struct in_addr localintf;       /* IP address of the local interface */
  int    sfd;                     /* socket file descriptor */
  char   databuf[BUFLEN];         /* IN/OUT data buffer */
  unsigned char  loopval;         /* value of socket option */
  unsigned int   ttlval;          /* value of socket option */
  socklen_t ttlvalsz = sizeof(ttlval);   /* size of option value */
  char   *localintfaddr = LOCALINTFIPADDR;  /* IP addr of local interface */

#if WINDOWS
  int  ret = 0;
  WSADATA wsaData;
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  /* Get local interface IP address from user, if any */
  if (argc > 1)
    localintfaddr = argv[1];

#if WINDOWS
  /* Start up Windows socket. Use at least Winsock version 2.2 */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    WSACleanup();
    return (-1);
  }
#endif

  /* Create a Datagram socket */
  sfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sfd < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Fill in the multicast group's address */
  memset((char *) &mcastgrp, 0, sizeof(mcastgrp));
  mcastgrp.sin_family = AF_INET;
  mcastgrp.sin_addr.s_addr = inet_addr(MULTICASTGROUP);
  mcastgrp.sin_port = htons(MCASTPORT);

  /* Enable loopback so multicast messages we send get delivered to
   * to this local host as well. */
  /* On Linux, this is sort of redundant because, by default, this is on.
     That is, applications on this same host can receive multicast message. */
  loopval = 1;
  if (setsockopt(sfd, IPPROTO_IP, IP_MULTICAST_LOOP, (char *)&loopval,
    sizeof(loopval)) < 0)
  {
    fprintf(stderr, "Error: setsockopt(IP_MULTICAST_LOOP) failed, "
      "errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }

  /* Set the local interface for outbound multicast messages. The local IP
     address specified must be a multicast capable interface. */
  localintf.s_addr = inet_addr(localintfaddr);
  if (setsockopt(sfd, IPPROTO_IP, IP_MULTICAST_IF, (char *)&localintf,
      sizeof(localintf)) < 0)
  {
    fprintf(stderr, "Error: setsockopt(IP_MULTICAST_IF) failed, "
      "errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Send a message to the multicast group */
  strcpy(databuf, "This is a multicast datagram message.");
  if (sendto(sfd, databuf, BUFLEN, 0, (struct sockaddr*)&mcastgrp,
      sizeof(mcastgrp)) < 0)
  {
    fprintf(stderr, "Error: sendto() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-5);
  }
  fprintf(stdout, "The multicast message was successfully sent.\n");

  CLOSE(sfd);
  return(0);
}

