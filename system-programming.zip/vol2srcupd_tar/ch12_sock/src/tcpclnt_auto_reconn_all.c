/*
 * A connection-oriented client program using Stream socket.
 * Detecting the death of a server and reconnecting with it automatically.
 * Using getaddrinfo().
 * This version works on Linux, Solaris, AIX, HPUX, Apple Darwin and Windows.
 * Usage: tcpclnt_auto_reconn_all [port [hostname/IPaddr]] 
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017-8, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

#undef   SLEEPMS
#define  SLEEPMS      500    /* number of milliseconds to sleep & wait */

int auto_reconnect(char *server_name, in_port_t portnum);

int main(int argc, char *argv[])
{
  int       ret;
  size_t    len;
  in_port_t portnum=DEFSRVPORT;      /* port number */
  int       portnum_in = 0;          /* port number user provides */
  char      server_name[NAMELEN+1];  /* hostname or IP address */

  fprintf(stdout, "Connection-oriented client program detecting server death...\n\n");

  /* Get the server's port number from user, if there is one. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr,"Error: invalid port number %s. Use default port %d.\n",
        argv[1], DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = (in_port_t)portnum_in;
  }

  /* Get the server's host name or IP address from user, if there is one. */
  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2], len);
    server_name[len] = '\0';
  } else
    strcpy(server_name, SERVER_NAME);

  ret = auto_reconnect(server_name, portnum);

  return(ret);
}

int auto_reconnect(char *server_name, in_port_t portnum)
{
  int    ret;
  int    sfd;                      /* file descriptor of the socket */
  struct addrinfo hints;           /* address info hints */
  struct addrinfo *res=NULL;       /* address info result */
  char   portnumstr[16];           /* port number in string form */
  char   inbuf[BUFLEN];            /* input message buffer */
#if WINDOWS
  WSADATA wsaData;                 /* Winsock data */
  char* GetErrorMsg(int ErrorCode); /* print error string in Windows */
  unsigned long opt = 1;
#else
  struct timespec  sleeptm;        /* time to sleep - seconds and nanoseconds */
#endif

  if (server_name == NULL || portnum <= 0)
    return(EINVAL);

#if WINDOWS
  /* Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-3);
  }
#endif

  /* Translate the server's host name or IP address into socket address.
   * Fill in the hints information.
   */
  sprintf(portnumstr, "%d", portnum);
  memset(&hints, 0x00, sizeof(hints));
    /* This works on AIX but not on Solaris, nor on Windows. */
    /* hints.ai_flags    = AI_NUMERICSERV; */
  hints.ai_family   = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  /* Get the address information of the server using getaddrinfo().  */
  ret = getaddrinfo(server_name, portnumstr, &hints, &res);
  if (ret != 0)
  {
    fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
      gai_strerror(ret));
#if !WINDOWS
    if (ret == EAI_SYSTEM)
      fprintf(stderr,"System error: errno=%d, %s\n", errno, strerror(errno));
#else
    WSACleanup();
#endif
    return(-4);
  }

  /* Set sleep time. */
#if !WINDOWS
  sleeptm.tv_sec = 0;
  sleeptm.tv_nsec = (SLEEPMS*1000000);
#endif

  /* Try to detect if the server has terminated. If yes, try to re-connect. */
  while (1)
  {
    fprintf(stderr,"Try to (re-)create a new socket and (re-)connect to "
      "the server ...\n");

    /* Create or re-create a socket for the client. */
    errno = 0;
    sfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sfd < 0)
    {
      fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
      WSACleanup();
#endif
      return (-5);
    }

    /* Connect to the server. */
    errno = 0;
    ret = connect(sfd, res->ai_addr, res->ai_addrlen);

    /* Try it again a bit later if connect has failed. */
    if (ret != 0)
    {
      fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      goto tryAgain;;
    }

    /* Connect has succeeded. */
    fprintf(stdout, "\n*** Server is up. Connecting to server is successful.\n\n");

    /* The main loop that exchanges messages with the server. */
    while(1)
    {
      /* Receive next message. */
      ret = 0;
      errno = 0;
      inbuf[0] = '\0';
      ret = recv(sfd, inbuf, BUFLEN, 0);

      /* Break if error occurred during recv(). */
      if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
        break;
      }
      /* No error during recv(). */
      else if (ret > 0)
      {
        /* Print the message received, if any. */
        inbuf[ret] = '\0';
        fprintf(stdout, "Received the following message:\n%s\n",
          inbuf);
      }
      else if (ret == 0)
      {
        fprintf(stdout, "\n*** The server may have terminated.\n\n");
        break;
      }
    }  /* inner while */

tryAgain:
    /* Close the current socket */
    CLOSE1(sfd);
    sfd = 0;

    /* Wait a little bit for the server to restart and be ready. */
    fprintf(stdout, "Sleep for %2d ms and wait for server to be ready...\n",
      SLEEPMS);
#if WINDOWS
    Sleep(SLEEPMS);  /* Unit is ms. */
#else
    nanosleep(&sleeptm, (struct timespec *)NULL);
#endif
  }  /* outer while (1) */

#if WINDOWS
  WSACleanup();
#endif
  return(0);
}
