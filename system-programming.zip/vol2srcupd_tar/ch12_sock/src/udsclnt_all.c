/*
 * A connection-oriented client program using Unix domain stream socket.
 * Support for Linux, Solaris, AIX, HPUX, Apple Darwin and Windows.
 * Usage: udsclnt_all 
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                     /* socket file descriptor */
  struct sockaddr_un    server;   /* server socket structure */
  int    srvaddrsz = sizeof(struct sockaddr_un);
  struct sockaddr_un    client;   /* client socket structure */
  int    clntaddrsz = sizeof(struct sockaddr_un);
  struct sockaddr_un    fromaddr; /* socket structure */
  socklen_t    fromaddrsz = sizeof(struct sockaddr_un);
  char   inbuf[BUFLEN];           /* input message buffer */
  char   outbuf[BUFLEN];          /* output message buffer */
  size_t msglen;                  /* length of reply message */
  size_t msgnum=0;                /* count of request message */
  size_t len;

#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented client program using Unix domain socket"
    " ...\n");

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Create a socket. */
  sfd = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return (-2);
  }

  /* Set up the client's address. */
  client.sun_family = AF_UNIX;   
  strcpy(client.sun_path, CLIENT_PATH); 
    
  /* Unlink the file and bind client socket to its address. */
  unlink(CLIENT_PATH);
  ret = bind(sfd, (struct sockaddr *) &client, clntaddrsz);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }

  /* Set up the server's address. */
  server.sun_family = AF_UNIX;
  strcpy(server.sun_path, SERVER_PATH);

  /* Connect to the server. */
  ret = connect(sfd, (struct sockaddr *) &server, srvaddrsz);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Get server's address. */
  ret = getpeername(sfd, (struct sockaddr *) &fromaddr, &fromaddrsz);
  if (ret == -1)
    fprintf(stderr, "Error: getpeername() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
  else
    fprintf(stdout, "Connected to server. Server socket filepath: %s\n",
      fromaddr.sun_path);

  fprintf(stdout, "Send request messages to server\n");

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
        {
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
          break;
        }
      }
    }
    else
    {
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      break;
    }

#if WINDOWS
    Sleep(1000); /* Unit is ms. For demo only. Remove this in real code. */
#else
    sleep(1);  /* For demo only. Remove this in real code. */
#endif
  }  /* while */

  CLOSE(sfd);
  return(0);
}
