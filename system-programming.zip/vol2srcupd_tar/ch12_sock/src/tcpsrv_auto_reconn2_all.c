/*
 * A connection-oriented server program using Stream socket.
 * This version is for testing client detecting server's death.
 * Support for multiple platforms including Linux, Windows, Solaris, AIX, HPUX
 * and Apple Darwin.
 * Usage: tcpsrv_auto_reconn2_all [port#] 
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017, 2018 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  int    portnum_in = 0;           /* port number entered by user */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */
  int    myid;                     /* my id number */
  int    messages;                 /* number of message to send */
  int    i, on=1;
#if !WINDOWS
  struct timespec  sleeptm;        /* sleep time - seconds and nanoseconds */
#endif
#if WINDOWS
  WSADATA wsaData;                 /* Winsock data */
  int winerror;                    /* error in Windows */
  char* GetErrorMsg(int ErrorCode); /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented server program ...\n");

  /* Get the server port number from user, if any. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = (in_port_t)portnum_in;
  }

#if WINDOWS
  /* Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Turn on SO_REUSEADDR socket option so that the server can restart
     right away before the required wait time period expires. */
  if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0)
  {
    fprintf(stderr, "setsockopt(SO_REUSEADDR) failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin_family = AF_INET;                   /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Set sleep time to be 5 ms. */
#if !WINDOWS
  sleeptm.tv_sec = SLEEPS;
  sleeptm.tv_nsec = (SLEEPMS*1000000);
#endif

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return(-5);
    }

    fprintf(stdout, "Client Connected.\n");

    /* Exchange messages with the client here in real code. Do the real work. */
    /* For demo purposes, we wait a little bit and then exit here. */
#if WINDOWS
    Sleep(SLEEPMS);  /* Unit is ms. */
#else
    nanosleep(&sleeptm, (struct timespec *)NULL);
#endif

    /* For demo purposes, terminate the communication with the client. */
    CLOSE1(newsock);

    /* Simulate server down. For demo only. Remove these 2 lines in real code. */
    CLOSE1(sfd);
    break;
  }  /* while - outer */

#if WINDOWS
  WSACleanup();
#endif
  return(0);
}
