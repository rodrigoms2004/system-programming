/*
 * A connection-oriented client program using Stream socket and
 * making asynchronous recv().
 * A single thread handling inputs from multiple data sources at the same time.
 * Run multiple servers and a single client to test.
 * This version works on Linux, Solaris, AIX, HPUX, Apple Darwin and Windows.
 * Usage: tcpclnt_async_io_all nsources hostname1/IP1 port1 hostname2/IP2 port2 ..
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017-8, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd[MAXSOURCES];          /* file descriptors of the sockets */
  struct sockaddr_in    server;    /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   inbuf[BUFLEN];            /* input message buffer */
  size_t    len;
  unsigned int addr;
  char   server_name[NAMELEN+1];
  int    socket_type = SOCK_STREAM;
  struct hostent *hp;
  int    nsources;                 /* number of message sources */
  unsigned int  done_cnt = 0, i;
  int    maxsfd = 0;               /* maximum socket file descriptor */
  int    status[MAXSOURCES];       /* remember if each input is done */
  int    dataRead = 0;             /* Did we read any data from any input? */
#if !WINDOWS
  struct timespec  sleeptm;        /* time to sleep - seconds and nanoseconds */
#endif
#if WINDOWS
  WSADATA wsaData;                 /* Winsock data */
  char* GetErrorMsg(int ErrorCode); /* print error string in Windows */
  unsigned long opt = 1;
#endif

  fprintf(stdout, "Connection-oriented client program reading n data sources...\n\n");

  /* Get the number of data sources. */
  if (argc > 1)
  {
    nsources = atoi(argv[1]);
    if ((nsources <= 0) || (nsources > MAXSOURCES))
    {
      fprintf(stderr, "Maximum number of sources %d out of range\n", nsources);
      return(-1);
    }
  }

  /* Make sure enough arguments are provided. */
  if (argc < (2+(nsources*2)))
  {
    fprintf(stderr, "Usage: %s nsources IP1 Port1 IP2 Port2 ...\n", argv[0]);
    return(-2);
  }

#if WINDOWS
  /* Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-3);
  }
#endif

  /* Clear the file descriptor and status arrays. */
  for (i = 0; i < nsources; i++)
  {
    sfd[i] = 0;
    status[i] = 0;
  }

  /* Connect to all data sources, one at a time. */
  for (i = 0; i < nsources; i++)
  {
    /* Get the host names or IP addresses of next data source. */
    len = strlen(argv[2+(i*2)]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2+(i*2)], len);
    server_name[len] = '\0';

    /* Get the port number of next data source. */
    portnum = atoi(argv[3+(i*2)]);
    if (portnum <= 0)
    {
      fprintf(stderr,"Error: invalid port number %s\n", argv[3+(i*2)]);
      continue;
    }

    /* Translate the host name or IP address into server socket address. */
    if (isalpha(server_name[0]))
    {  /* A host name is given. */
      hp = gethostbyname(server_name);
    }
    else
    {  /* Convert the n.n.n.n IP address to a number. */
      addr = inet_addr(server_name);
      hp = gethostbyaddr((char *)&addr, sizeof(addr), AF_INET);
    }
    if (hp == NULL )
    {
      fprintf(stderr,"Error: cannot get address for [%s], errno=%d, %s\n",
        server_name, ERRNO, ERRNOSTR);
#if WINDOWS
      WSACleanup();
#endif
      return(-4);
    }

    /* Copy the resolved information into the sockaddr_in structure. */
    memset(&server, 0, sizeof(server));
    memcpy(&(server.sin_addr), hp->h_addr, hp->h_length);
    server.sin_family = hp->h_addrtype;
    server.sin_port = htons(portnum);

    /* Create a socket for the next data source. */
    sfd[i] = socket(AF_INET, socket_type, 0);
    if (sfd[i] < 0)
    {
      fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO,
        ERRNOSTR);
#if WINDOWS
      WSACleanup();
#endif
      return (-5);
    }

    /* Connect to the data source. */
    errno = 0;
    ret = connect(sfd[i], (struct sockaddr *)&server, srvaddrsz);

    /* Continue to next source if connect has failed. */
    if (ret != 0)
    {
      fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO,
        ERRNOSTR);
      CLOSE1(sfd[i]);
      sfd[i] = 0;
      continue;
    }
    if (sfd[i] > maxsfd)
      maxsfd = sfd[i];

    /* connect() has succeeded.
       Make the socket non-blocking after connect. O_NONBLOCK=0x0800 */
    fprintf(stdout, "To set socket non-blocking ...\n");
#if WINDOWS
    if (ioctlsocket(sfd[i], FIONBIO, &opt) != 0)
#else
    if (fcntl(sfd[i], F_SETFL, fcntl(sfd[i], F_GETFL, 0) | O_NONBLOCK) != 0)
#endif
    {
      fprintf(stderr, "Error: fcntl() failed to set socket nonblocking, "
        "errno=%d, %s\n", ERRNO, ERRNOSTR);
      fprintf(stderr, "Close the current socket, i=%d.\n", i);
      CLOSE1(sfd[i]);
      sfd[i] = 0;
    }

  }  /* for */

  /* Now we are connected to all data sources with all sockets asynchronous.
   * Start to receive data from multiple sockets using non-blocking I/O.
   */

  fprintf(stdout, "\nReceive messages from multiple sources ...\n");

  /* Set sleep time. */
#if !WINDOWS
  sleeptm.tv_sec = 0;
  sleeptm.tv_nsec = (SLEEPMS*1000000);  /* unit is nanoseconds */
#endif

  /* Use select() to poll all data sources and wait for next message to arrive. */
  while (done_cnt < nsources)
  {
    /* Check if any socket has messages ready to be read. */
    struct timeval tv = { 1, 0 };  /* one second to timeout */
    fd_set readfds;  /* This is 128 bytes long. 32 4-byte integers. */
    int    ret2;
    int optval = 0;
    socklen_t vallen;

    /* Check the socket for ready to read. */
    FD_ZERO(&readfds);
    for (i = 0; i < nsources; i++)
      if (status[i] == 0)
        FD_SET(sfd[i], &readfds);

    errno = 0;
    /* First argument is always highest fd plus 1. It specifies a range. */
    ret2 = select(maxsfd + 1, &readfds, NULL, NULL, &tv);
    fprintf(stdout, "select() returned %d, errno=%d, %s\n", ret2, ERRNO,
      ERRNOSTR);
    fflush(stdout);

    /* If select() returns positive integer, check which socket is ready. */
    if (ret2 > 0)
    {
      dataRead = 0;  /* Mark we've not read anything yet. */
      /* Loop through all socket file descriptor. */
      for (i = 0; i < nsources; i++)
      {
        if (status[i] == 1)  /* The file descriptor is done. Skip it. */
          continue;

        if (FD_ISSET(sfd[i], &readfds))
        {
          /* This sfd is ready for read. */
          fprintf(stdout, "Data source %2d is ready for read.\n", (i+1));
          fflush(stdout);

          /* Read all of the data that is available at current input. */
          while(1)
          {
            /* Receive next message. */
            ret = 0;
            errno = 0;
            inbuf[0] = '\0';
            ret = recv(sfd[i], inbuf, BUFLEN, 0);

            /* Break if error occurred during recv(). */
            if (ret < 0)
            {
              fprintf(stderr, "recv() returned %d, errno=%d, %s\n", ret, ERRNO,
                ERRNOSTR);
              fflush(stderr);
              break;
            }

            /* No error during recv(). */
            if (ret > 0)
            {
              dataRead = 1;  /* Remember we've read something. */
              /* Print the message received. */
              inbuf[ret] = '\0';
              fprintf(stdout, "Received the following message:\n%s\n",
                inbuf);
              fflush(stdout);
            }
            else if (ret == 0)
            {
              fprintf(stdout, "Warning: The other end may have closed.\n");
              fflush(stdout);
              /* Mark this data source as 'done'. */
              if (status[i] == 0)
              {
                status[i] = 1;
                done_cnt++;
              }
              break;
            }
          }  /* while (reading current data source) */
        }  /* if (FD_ISSET()) */
      }  /* for */

      /* If no data is read from any source, sleep for 10 ms before next poll.
         This sleep is very important for not wasting CPU time. */
      if (!dataRead)
      {
        fprintf(stdout, "To sleep for %2d ms and wait...\n", SLEEPMS);
        fflush(stdout);
#if WINDOWS
        Sleep(SLEEPMS);  /* Unit is ms. */
#else
        nanosleep(&sleeptm, (struct timespec *)NULL);
#endif
      }
    }
    else if (ret2 < 0)  /* select() returned error */
    {
      fprintf(stderr, "Error on select(): errno=%d, %s\n", ERRNO,
        ERRNOSTR);
      fflush(stderr);
    }

  }  /* while (done_cnt < nsources) */

  /* We're done reading all data sources. Close all sockets and return. */
  for (i = 0; i < nsources; i++)
    CLOSE1(sfd[i]);
#if WINDOWS
  WSACleanup();
#endif
  return(0);
}
