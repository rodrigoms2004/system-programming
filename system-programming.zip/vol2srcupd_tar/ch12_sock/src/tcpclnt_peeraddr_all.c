/*
 * A connection-oriented client program using Stream socket.
 * Connecting to a server program on any host using a hostname or IP address.
 * Support for IPv4 and IPv6 and multiple platforms including
 * Linux, Windows, Solaris, AIX, HPUX and Apple Darwin.
 * Usage: tcpclnt_peeraddr_all [srvport# [server-hostname | server-ipaddress]]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

#undef   MAXMSGS
#define  MAXMSGS             1    /* Maximum number of messages to send */

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                     /* socket file descriptor */
  in_port_t  portnum=DEFSRVPORT;  /* port number */
  char   *portnumstr  = DEFSRVPORTSTR; /* port number in string format */
  int    portnum_in = 0;          /* port number provided by user */
  char   inbuf[BUFLEN];           /* input message buffer */
  char   outbuf[BUFLEN];          /* output message buffer */
  size_t msglen;                  /* length of reply message */
  size_t msgnum=0;                /* count of request message */
  size_t len;
  char   server_name[NAMELEN+1] = "localhost";
  struct addrinfo hints, *res=NULL;  /* address info */
  char *ipaddrstr = IPV6LOCALADDR;   /* server's IP address in string format */
  struct in6_addr  ipaddrbin;        /* server's IP address in binary format */
  struct sockaddr_in6    peeraddr6;  /* IPV6 socket structure */
  struct sockaddr_in    *peeraddr4p; /* IPV4 socket structure */
  socklen_t    peeraddr6sz=sizeof(struct sockaddr_in6);
  char   peeraddrstr[PEERADDRLEN]; /* IP address of peer socket, string form */

#if WINDOWS
  WSADATA wsaData;                   /* Winsock data */
  int winerror;                      /* error in Windows */
  char* GetErrorMsg(int ErrorCode);  /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented client program ...\n");

  /* Get the server's port number from command line. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
      portnumstr = DEFSRVPORTSTR;
    }
    else
    {
      portnum = (in_port_t)portnum_in;
      portnumstr = argv[1];
    }
  }

  /* Get the server's host name or IP address from command line. */
  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2], len);
    server_name[len] = '\0';
  }

#if WINDOWS
  /* Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Translate the server's host name or IP address into socket address.
   * Fill in the hints information.
   */
  memset(&hints, 0x00, sizeof(hints));
    /* This works on AIX but not on Solaris, nor on Windows. */
    /* hints.ai_flags    = AI_NUMERICSERV; */
  hints.ai_family   = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  /* Get the address information of the server using getaddrinfo().  */
  ret = getaddrinfo(server_name, portnumstr, &hints, &res);
  if (ret != 0)
  {
    fprintf(stderr, "Error: getaddrinfo() failed. Host %s not found.\n",
      gai_strerror(ret));
#if WINDOWS
    /* Windows supports EAI_AGAIN, EAI_BADFLAGS, EAI_FAIL, EAI_FAMILY,
       EAI_MEMORY, EAI_NONAME, EAI_SERVICE, EAI_SOCKTYPE, but no EAI_SYSTEM */
    fprintf(stderr, "getaddrinfo() failed with error %d: %s\n",
          WSAGetLastError(), GetErrorMsg(WSAGetLastError()));
    WSACleanup();
#else
    if (ret == EAI_SYSTEM)
      perror("getaddrinfo() failed");
#endif
    return(-2);
  }

  /* Create a socket. */
  sfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return (-3);
  }

  /* Connect to the server. */
  ret = connect(sfd, res->ai_addr, res->ai_addrlen);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Get and print peer's IP address and port number */
  memset((void *)&peeraddr6, 0, (size_t)peeraddr6sz);
  memset(peeraddrstr, 0, PEERADDRLEN);
  errno = 0;
  ret = getpeername(sfd, (struct sockaddr *) &peeraddr6, &peeraddr6sz);
  if (ret == 0)
  {
    /* The return structure size indicates IPv4 or IPv6. */
    if (peeraddr6sz > sizeof(struct sockaddr_in))
    {
      inet_ntop(AF_INET6, &(peeraddr6.sin6_addr), peeraddrstr, PEERADDRLEN);
      fprintf(stdout, "Server's IP address from getpeername(): %s port=%u\n",
        peeraddrstr, ntohs(peeraddr6.sin6_port));
    } else {
      peeraddr4p = (struct sockaddr_in *)&peeraddr6;
      inet_ntop(AF_INET, &(peeraddr4p->sin_addr.s_addr), peeraddrstr, PEERADDRLEN);
      fprintf(stdout, "Server's IP address from getpeername(): %s port=%u\n",
        peeraddrstr, ntohs(peeraddr4p->sin_port));
    }
  }
  else
    fprintf(stderr, "Error: getpeername() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);

  fprintf(stdout, "Send request messages to server(%s) at port %d\n",
   server_name, portnum);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO,
        ERRNOSTR);

#if WINDOWS
    Sleep(1000); /* Unit is ms. For demo only. Remove this in real code. */
#else
    sleep(1);  /* For demo only. Remove this in real code. */
#endif
  }  /* while */

  /* Free the memory allocated by getaddrinfo() */
  freeaddrinfo(res);
  CLOSE(sfd);
  return(0);
}
