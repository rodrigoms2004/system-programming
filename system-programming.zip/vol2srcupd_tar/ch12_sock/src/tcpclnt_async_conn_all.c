/*
 * A connection-oriented client program using Stream socket and
 * making asynchronous connect.
 * Closing and recreating the socket before re-trying to connect after it fails.
 * This is because when the connect() fails, the socket becomes undefined
 * in Solaris, AIX and HPUX.
 * This version works on Linux, Solaris, AIX, HPUX, Apple Darwin and Windows.
 * Note: The errno on different platforms is different when server is not up.
 * Usage: tcpclnt_async_conn_all [server_hostname or IP_address [server_port#]]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017, 2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                      /* file descriptor of the socket */
  struct sockaddr_in    server;    /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    fromaddr;  /* socket structure */
  int    fromaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  int    portnum_in = 0;           /* port number entered by user */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t    msglen;                /* length of reply message */
  size_t    msgnum=0;              /* count of request message */
  size_t    len;
  unsigned int addr;
  char   server_name[NAMELEN+1] = "localhost";
  int    socket_type = SOCK_STREAM;
  struct hostent *hp;
  int    option;
  socklen_t  optlen;
  unsigned int  trycnt = MAXCONNTRYCNT;

#if WINDOWS
  WSADATA wsaData;                 /* Winsock data */
  int winerror;                    /* error in Windows */
  char* GetErrorMsg(int ErrorCode); /* print error string in Windows */
  unsigned long opt = 1;
#endif

  fprintf(stdout, "Connection-oriented client program ...\n\n");

  /* Get the host name or IP address of the server from command line. */
  if (argc > 1)
  {
    len = strlen(argv[1]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[1], len);
    server_name[len] = '\0';
  }

  /* Get the port number of the server from command line. */
  if (argc > 2)
  {
    portnum_in = atoi(argv[2]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = (in_port_t)portnum_in;
  }

#if WINDOWS
  /* Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Translate the host name or IP address into server socket address. */
  if (isalpha(server_name[0]))
  {  /* A host name is given. */
    hp = gethostbyname(server_name);
  }
  else
  {  /* Convert the n.n.n.n IP address to a number. */
    addr = inet_addr(server_name);
    hp = gethostbyaddr((char *)&addr, sizeof(addr), AF_INET);
  }
  if (hp == NULL )
  {
    fprintf(stderr,"Error: cannot get address for [%s], errno=%d, %s\n",
      server_name, ERRNO,  ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Copy the resolved information into the sockaddr_in structure. */
  memset(&server, 0, sizeof(server));
  memcpy(&(server.sin_addr), hp->h_addr, hp->h_length);
  server.sin_family = hp->h_addrtype;
  server.sin_port = htons(portnum);

  /* Connect to the server asynchronously.
   * Close and re-create the socket each time after connect() fails.
   * We must close and re-create socket when connect() fails in Solaris,
   * AIX, and HPUX.
   */
  while (trycnt-- > 0)
  {
    /* Open a socket. */
    sfd = socket(AF_INET, socket_type, 0);
    if (sfd < 0)
    {
      fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
      WSACleanup();
#endif
      return (-3);
    }

    /* Make the socket non-blocking before connect. O_NONBLOCK=0x0800 */
    fprintf(stdout, "To set socket non-blocking ...\n");
#if WINDOWS
    if (ioctlsocket(sfd, FIONBIO, &opt) != 0)
#else
    if (fcntl(sfd, F_SETFL, fcntl(sfd, F_GETFL, 0) | O_NONBLOCK) != 0)
#endif
    {
      fprintf(stderr, "Error: fcntl() failed to set socket nonblocking, "
        "errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return (-4);
    }

    /* Connect to the server asynchronously. */
    errno = 0;
    ret = connect(sfd, (struct sockaddr *)&server, srvaddrsz);
    fprintf(stdout, "connect() returned %d, errno=%d, %s\n", ret, ERRNO,
      ERRNOSTR);
    /* connect() succeeds */
    if (ret == 0)
      break;
#if WINDOWS
    /* Windows does not return socket connect error (i.e. put error from
       connect() in errno). We have to call WSAGetLastError() to get it. */
    winerror = WSAGetLastError();
    fprintf(stdout, "In Windows, WSAGetLastError() returned %d\n", winerror);
#endif

    /* It (connect()) is in progress. */
#if WINDOWS
    if (winerror == WSAEWOULDBLOCK)
#else
    if (errno == EINPROGRESS)
#endif
    {
      struct timeval tv = { 2, 0 };  /* 2 seconds to timeout */
      fd_set writefds;  /* This is 128 bytes long. 32 4-byte integers. */
      int    ret2;
      int optval = 0;
      socklen_t vallen;

      fprintf(stdout, "connect() returned EINPROGRESS (Windows-WSAEWOULDBLOCK)\n");

      /* Check the socket for ready to write. */
      /* Note: We must do both select() and getsockopt(), and in that order. */
      FD_ZERO(&writefds);
      FD_SET(sfd, &writefds);
      errno = 0;
      /* First argument is always highest fd plus 1. It specifies a range. */
      ret2 = select(sfd + 1, NULL, &writefds, NULL, &tv);
      fprintf(stdout, "select() returned %d, errno=%d, %s\n", ret2, ERRNO,
        ERRNOSTR);

      /* This is how we determine if connect() has failed. */
      if (ret2 > 0)
      {
        /* Check for error. Note: Doing this before select() doesn't work. */
        /* Note: We must do this after the select() call above. */
        /* This is necessary because connect() could encounter an error. */
        vallen = sizeof(int);
        getsockopt(sfd, SOL_SOCKET, SO_ERROR, (void*)(&optval), &vallen);
        if (optval)
        {
          fprintf(stderr, "Error in connect()/select() %d - %s\n",
            optval, strerror(optval));
          goto tryConnectAgain;
        }

        if (FD_ISSET(sfd, &writefds))
        {
          /* The sfd is ready for write. */
          fprintf(stdout, "select() returned and sfd is set. So it's ready!\n");
          ret = 0;
          break;
        }
      }
      else if (ret2 < 0)
      {
        fprintf(stderr, "Error on select(): errno=%d, %s\n", ERRNO, ERRNOSTR);
      } 
    }  /* if INPROGRESS */

tryConnectAgain:
    fprintf(stdout, "Closing the socket before trying to connect again.\n");
    CLOSE1(sfd);

    /* Sleep a second before try again. */
#if WINDOWS
    Sleep(1000); /* Unit is ms. */
#else
    sleep(1);
#endif
  }  /* while */

  /* Return from here if connect has failed */
  if (ret != 0)
  {
    CLOSE(sfd);
    return(-5);
  }

  /* connect() has succeeded. */
  /* Make socket blocking again after connect */
  fprintf(stdout, "To clear socket non-blocking ...\n");
#if WINDOWS
  opt = 0;
  if (ioctlsocket(sfd, FIONBIO, &opt) != 0)
#else
  if (fcntl(sfd, F_SETFL, fcntl(sfd, F_GETFL, 0) & ~O_NONBLOCK) != 0)
#endif
  {
    fprintf(stderr, "Error: fcntl() failed to set socket blocking, errno=%d,"
      " %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-6);
  }

  /* Exchange data with the server using blocking I/O. */

  fprintf(stdout, "\nSend request messages to server at port %d\n", portnum);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    /* It could die at this send() in Solaris if socket is not re-created. */
    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
        {
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
          CLOSE(sfd);
          return(-7);
        }
      }
    }
    else
    {
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return(-8);
    }

    /* Pause one second between messages. Remove this in real code. */
#if WINDOWS
    Sleep(1000); /* Unit is ms. For demo only. Remove this in real code. */
#else
    sleep(1);  /* For demo only. Remove this in real code. */
#endif
  }  /* while */

  CLOSE(sfd);
  return(0);
}
