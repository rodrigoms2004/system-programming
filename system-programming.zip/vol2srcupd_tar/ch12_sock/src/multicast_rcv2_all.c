/*
 * Multicast message receiver
 * This program receives a message through multicasting.
 * Multiple programs running on same host are enabled to receive in same
 * multicast group via turning on the SO_REUSEPORT socket option.
 * This works in Linux, IBM AIX, HP HPUX and Apple Darwin.
 * Usage: multicast_rcv2  ip_address_of_local_interface
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2017-8, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  struct sockaddr_in  rcvraddr;  /* address of the receiving socket */
  struct ip_mreq      mcastgrp;  /* address of the multicast group */
  int    sfd;                    /* socket file descriptor */
  char   inbuf[BUFLEN];          /* input buffer */
  int    optval;                 /* value of socket option */
  char   *localintfaddr = LOCALINTFIPADDR;  /* IP addr of local interface */

#if WINDOWS
  int  ret = 0;
  WSADATA wsaData;
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  /* Get local interface IP address from user, if any */
  if (argc > 1)
    localintfaddr = argv[1];

#if WINDOWS
  /* Start up Windows socket. Use at least Winsock version 2.2 */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    WSACleanup();
    return (-1);
  }
#endif

  /* Create a Datagram socket */
  sfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sfd < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Turn on SO_REUSEPORT socket option to allow multiple instances of this
     program to be able to receive copies of the multicast datagrams. */
  optval = 1;
  if (setsockopt(sfd, SOL_SOCKET, SO_REUSEPORT, (char *)&optval, sizeof(optval))
    < 0)
  {
    fprintf(stderr, "Error: setsockopt(SO_REUSEPORT) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }
  fprintf(stdout, "The SO_REUSEPORT socket option is turned on.\n");

  /* Bind the Datagram socket to an address */
  memset((char *) &rcvraddr, 0, sizeof(rcvraddr));
  rcvraddr.sin_family = AF_INET;
  rcvraddr.sin_port = htons(MCASTPORT);
  rcvraddr.sin_addr.s_addr = INADDR_ANY;
  if (bind(sfd, (struct sockaddr*)&rcvraddr, sizeof(rcvraddr)))
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Join the multicast group on the specified local host's interface.
   * A multicast datagram receiver must turn on the IP_ADD_MEMBERSHIP
   * socket option.
   */
  mcastgrp.imr_multiaddr.s_addr = inet_addr(MULTICASTGROUP);
  mcastgrp.imr_interface.s_addr = inet_addr(localintfaddr);
  if (setsockopt(sfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&mcastgrp,
    sizeof(mcastgrp)) < 0)
  {
    fprintf(stderr, "Error: setsockopt(IP_ADD_MEMBERSHIP) failed, "
      "errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-5);
  }

  /* Read the multicast message. Windows requires using recvfrom() here. */
  if (recvfrom(sfd, inbuf, BUFLEN, 0, (struct sockaddr *)NULL,
      (socklen_t *)NULL) < 0)
  {
    fprintf(stderr, "Error: recvfrom() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-6);
  }

  fprintf(stdout, "The following multicast message was successfully received:"
    "\n%s\n", inbuf);

  CLOSE(sfd);
  return(0);
}
