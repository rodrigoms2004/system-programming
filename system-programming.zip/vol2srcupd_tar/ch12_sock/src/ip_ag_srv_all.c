/*
 * A cross-platform IP-agnostic TCP Server program.
 * This is a very flexible IP-agnostic TCP server program.
 * It supports IPv4 and IPv6 at the same time.
 * This program allows users to easily test IPv4 and IPv6 combinations.
 * If the user does not specify a host name argument, this program
 *   determines if IPv6 is supported in the localhost. If yes, it starts an
 *   IPv6 listener server socket and accepts both IPv4/IPv6 client connections.
 *   If IPv6 is not supported, it starts an IPv4 server.
 * If the user specifies a hostname, this program creates a server socket
 *   matching the IP type of that hostname so the user has control over
 *   which IP to use.
 *   Should the host be dual-IP with a single name, whichever IP address type
 *   returned first by getaddrinfo() will be used.
 *   Note that this approach of using hostname to control the IPv4 vs. IPv6
 *   type of socket seems to work well on Solaris and Linux. But it might not
 *   work on some Windows Server 2003 where using an IPv4 hostname may lead to
 *   a Link Local IPv6 address (that begins with fe80) in some environment and
 *   an IPv6 server socket was used. Specifying the IPv4 address in place of
 *   the IPv4 hostname works around the problem.
 * This program also prints the communication partner's IP address.
 * Support for multiple platforms including Linux, Windows, Solaris, AIX, HPUX
 *   and Apple Darwin.
 * Usage: ip_ag_srv_all [port_num [hostname_or_IPaddr]]
 * By default, if user specifies nothing, an IPv6 server socket is used.
 * The user can specify an IP address or hostname as the second command-line
 * argument, after the port number, to select an IP type he/she prefers.
 *
 * Authored by Jin-Jwei Chen.
 * Copyright (c) 2005-2018, 2020-2022 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

void  printSockType(int);

int main(int argc, char **argv)
{
  /* Variable and structure definitions */
  int lsnr=-1, clntsk=-1;             /* socket file descriptors */
  int on=1, datasz=BUFLEN;            /* value of socket option */
  char buf[BUFLEN];                   /* input & output buffer */
  /*struct sockaddr_in6 serveraddr, clientaddr;*/
  struct sockaddr_storage  clntaddr;  /* client's address */
  struct sockaddr_in   srvaddr4;      /* server's IPv4 address */
  struct sockaddr_in6  srvaddr6;      /* server's IPv6 address */
  /* unsigned long addrlen = sizeof(clntaddr); */ /* AIX*/
  socklen_t addrlen = sizeof(clntaddr); /* Solaris, Linux, HPUX, Windows */
  short srvport = DEFSRVPORT;         /* port number server listens on */
  char  *srvhost = NOHOST;            /* name of the server host */
  char  hostaddr[IPADDRSZ];           /* buffer for host's string IP address */
  char  straddr[INET6_ADDRSTRLEN+1];  /* IP address in string format */
  int   v6only = 0;                   /* IPV6_V6ONLY socket option off */
  struct addrinfo hints, *res=NULL, *aip;
  int  ret=0, success=0;

  /* On AIX getaddrinfo() always fails with EAI_NONAME if service="" */
#if AIX
  char *service = NULL;  /* e.g. set to "ftp" works */
#else
  char *service = "";
#endif
  int  niflags = (NI_NUMERICHOST|NI_NUMERICSERV); /* getnameinfo() flags */
  char clntipaddr[NI_MAXHOST];        /* client's string IP address */
#if WINDOWS
  short        addrFam;               /* protocol family (IPv4 or IPv6) */
#else
  sa_family_t  addrFam;               /* protocol family (IPv4 or IPv6) */
#endif
#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  int winerror;                       /* error in Windows */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  /* Get server's port number and hostname or IP address provided by user */
  if (argc > 1)
    srvport = atoi(argv[1]);
  if (argc > 2)
    srvhost = argv[2];

  fprintf(stdout, "srvhost=%s  port_num=%d\n", srvhost, srvport);

#if WINDOWS
  /* Use at least Winsock version 2.2 */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Server's service loop */
  do
  {
    if ( !strcmp(srvhost, NOHOST) )
    {
      /* No host name or IP address is given. Use Ipv6 over Ipv4 if it works. */
      addrFam = AF_INET6;
      if ((lsnr = socket(addrFam, SOCK_STREAM, 0)) < 0)
      {
        fprintf(stdout, "IPv6 does not seem to be supported. Try IPv4.\n");
        addrFam = AF_INET;
        if ((lsnr = socket(addrFam, SOCK_STREAM, 0)) < 0)
        {
          fprintf(stdout, "IPv4 does not seem to be supported, either.\n");
          fprintf(stderr, "socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
          ret = (-2);
          break;
        }
      }

      /* A server socket was successfully created. */
      printSockType(addrFam);

    } else {

      /* A server host name or IP address is given by the user. Do lookup and
        use that IP type. */

      /* Set up the hints for lookup */
      memset(&hints, 0, sizeof(hints));
      hints.ai_flags = AI_PASSIVE;
      hints.ai_family = AF_UNSPEC;
      hints.ai_socktype = SOCK_STREAM;

      /* Call getaddrinfo() for the server hostname or IP address.
       * Note that the res returned by getaddrinfo() contains a linked list
       * of the server's addresses found. So one could potentially try the
       * next one in the list if the current one fails.
       */
      ret = getaddrinfo(srvhost, service, &hints, &res);
      if (ret != 0)
      {
        fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
          gai_strerror(ret));
#if !WINDOWS
        if (ret == EAI_SYSTEM)
          fprintf(stderr,"System error: errno=%d, %s\n", errno, strerror(errno));
#endif
        ret = (-3);
        break;
      }

      /* Loop through all addresses returned until one succeeds. */
      success = 0;
      for (aip = res; aip; aip = aip->ai_next)
      {
        /* Print the server's IP address */
        switch (aip->ai_family)
        {
          case AF_INET6:
            addrFam = AF_INET6;
            /* Without NI_NUMERIC*, it returns hostname & text service name */
            ret = getnameinfo(aip->ai_addr, sizeof(struct sockaddr_in6),
              hostaddr, IPADDRSZ, NULL, 0,  niflags);
            if (ret == 0)
              fprintf(stdout, "Server IPv6 address is %s.\n", hostaddr);
            else
              fprintf(stderr, "Error: getnameinfo() failed, error %d, %s\n",
                ret, gai_strerror(ret));
          break;
          case AF_INET:
            addrFam = AF_INET;
            ret = getnameinfo(aip->ai_addr, sizeof(struct sockaddr_in),
              hostaddr, IPADDRSZ, NULL, 0,  niflags);
            if (ret == 0)
              fprintf(stdout, "Server IPv4 address is %s.\n", hostaddr);
            else
              fprintf(stderr, "Error: getnameinfo() failed, error %d, %s\n",
                ret, gai_strerror(ret));
          break;
          default:
            fprintf(stdout, "Server address family unexpected = %d\n",
              aip->ai_family);
          break;
        }  /* switch */

        /* Create the server's listener socket. */
        if ((lsnr = socket(addrFam, SOCK_STREAM, 0)) < 0)
        {
          fprintf(stderr, "socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
          continue;
        } else {
          /* Set the flag and exit the for loop. */
          success = 1;
          printSockType(addrFam);
          break;
        }
      }  /* for */

      /* Exit if no success in creating the server socket. */
      if (!success)
      {
        fprintf(stderr, "Failed to create the server socket.\n");
        ret = (-4);
        break;
      }
    }  /* if (!LOCALHOST) */

    /* We have a listener socket to work with. */

    if (setsockopt(lsnr, SOL_SOCKET, SO_REUSEADDR, (char *)&on,sizeof(on)) < 0)
    {
      fprintf(stderr, "setsockopt(SO_REUSEADDR) failed, errno=%d, %s\n", ERRNO,
        ERRNOSTR);
      ret = (-5);
      break;
    }

    /* If IPv6, turn off IPV6_V6ONLY socket option. Default is on in Windows. */
    if (addrFam == AF_INET6)
    {
      if (setsockopt(lsnr, IPPROTO_IPV6, IPV6_V6ONLY, (char*)&v6only,
        sizeof(v6only)) != 0)
      {
        fprintf(stderr, "Error: setsockopt(IPV6_V6ONLY) failed, errno=%d, %s\n",
          ERRNO, ERRNOSTR);
        ret = (-6);
        break;
      }
    }

    /* Bind the server socket. */
    memset(&srvaddr4, 0, sizeof(srvaddr4));
    memset(&srvaddr6, 0, sizeof(srvaddr6));
    if (addrFam == AF_INET6)
    {
      srvaddr6.sin6_family = AF_INET6;
      srvaddr6.sin6_port   = htons(srvport);
      srvaddr6.sin6_addr   = in6addr_any;
    } else {
      srvaddr4.sin_family = AF_INET;
      srvaddr4.sin_port   = htons(srvport);
      srvaddr4.sin_addr.s_addr = INADDR_ANY;
    }

    if (addrFam == AF_INET6)
      ret = bind(lsnr, (struct sockaddr *)&srvaddr6, sizeof(srvaddr6));
    else
      ret = bind(lsnr, (struct sockaddr *)&srvaddr4, sizeof(srvaddr4));

    if (ret < 0)
    {
      fprintf(stderr, "bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (-7);
      break;
    }

    /* Listen for client connection requests. Set queue length. */
    if (listen(lsnr, BACKLOG) < 0)
    {
      fprintf(stderr, "listen() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (-8);
      break;
    }

    fprintf(stdout, "Ready for client to connect.\n");

    /* Accept the next client connection.
     * We could have let accept() return client's address by doing
     * accept(lsnr, (struct sockaddr *)&clntaddr, &addrlen).
     * To demonstrate how to get that separately, we use getpeername below.
     */
    if ((clntsk = accept(lsnr, NULL, NULL)) < 0)
    {
      fprintf(stderr, "accept() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (-9);
      break;
    }
    else
    {
       /* Display the client address.  Note that if the client is an IPv4
        * client, the address will be shown as an IPv4 Mapped IPv6 address.
        */
       getpeername(clntsk, (struct sockaddr *)&clntaddr, &addrlen);
       ret = getnameinfo((struct sockaddr *)&clntaddr, addrlen,
             clntipaddr, NI_MAXHOST, NULL, 0,  niflags);
       if (ret == 0)
         fprintf(stdout, "Client address is %s.\n", clntipaddr);
    }

    /* Receive the data the client sends */
    ret = recv(clntsk, buf, sizeof(buf), 0);
    if (ret < 0)
    {
      fprintf(stderr, "recv() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (-10);
      break;
    }

    fprintf(stdout, "%d bytes of data were received.\n", ret);
    if (ret == 0)
    {
       fprintf(stdout, "The client has closed the connection.\n");
       break;
    }
    buf[ret] = '\0';

    /* Send the client data back to the client */
    ret = send(clntsk, buf, ret, 0);
    if (ret < 0)
    {
      fprintf(stderr, "send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (-11);
      break;
    }
    fprintf(stdout, "Server echoed the message back to the client.\n");
    ret = 0;

#if WINDOWS
    /* On Windows, server closing its socket may fail client's recv() */
    Sleep(1);
#endif
    break;
  } while (0);

  fprintf(stdout, "Program terminated.\n");

  /* Free the memory allocated by getaddrinfo() */
  if (res)
    freeaddrinfo(res);

  /* Close the listener and client sockets */
  if (clntsk != -1)
    CLOSE1(clntsk);
  if (lsnr != -1)
    CLOSE1(lsnr);
#if WINDOWS
  WSACleanup();
#endif

  return(ret);
}

/* Print the type of a socket */
void  printSockType(int addrFam)
{
  switch (addrFam)
  {
    case AF_INET6: fprintf(stdout, "Server uses an IPv6 socket.\n"); break;
    case AF_INET:  fprintf(stdout, "Server uses an IPv4 socket.\n"); break;
    default:       fprintf(stdout, "Server uses an unknown socket.\n");
  }
}
