/*
 * A connectionless server program using Datagram socket.
 * Usage: udpsrv_all [port#]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2020, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret, portnum_in=0;
  int    sfd;                      /* file descriptor of the socket */
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t    msglen;                /* length of reply message */
#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connectionless server program ...\n");

  /* Get the port number from user, if any. */
  if (argc > 1)
    portnum_in = atoi(argv[1]);
  if (portnum_in <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum_in, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }
  else
    portnum = portnum_in;

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Create the Datagram server socket. */
  if ((sfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin_family = AF_INET;                   /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }

  /* Set the reply message */
  sprintf(outbuf, "%s", "This is a reply from the server program.");
  msglen = strlen(outbuf);

  fprintf(stdout, "Listening at port number %u ...\n", portnum);

  /* Receive and service requests from clients. */
  while (1)
  {
    /* Receive a request from a client. */
    errno = 0;
    inbuf[0] = '\0';
    ret = recvfrom(sfd, inbuf, BUFLEN, 0, (struct sockaddr *)&clntaddr,
            &clntaddrsz);
    if (ret > 0)
    {
      /* Process the request. We simply print the request message here. */
      inbuf[ret] = '\0';
      fprintf(stdout, "\nReceived the following request from client:\n%s\n",
        inbuf);

      /* Send a reply. */
      errno = 0;
      ret = sendto(sfd, outbuf, msglen, 0, (struct sockaddr *)&clntaddr,
        clntaddrsz);
      if (ret == -1)
        fprintf(stderr, "Error: sendto() failed, errno=%d, %s\n", ERRNO,
          ERRNOSTR);
      else
        fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
    }
    else if (ret < 0)
      fprintf(stderr, "Error: recvfrom() failed, errno=%d, %s\n", ERRNO,
        ERRNOSTR);
    else
      fprintf(stdout, "The client may have disconnected.\n");
  }  /* while */
}

