/*
 * A connection-oriented server program using Stream socket.
 * Multi-threaded server using pthread.
 * You must link this program with pthread library (-lpthread) on all platforms.
 * Usage: tcpsrvt [port#]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2017, 2019-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <signal.h>        /* sigaction() */
#include <unistd.h>        /* close(), fork() */
#include <pthread.h>

#define  BUFLEN      1024    /* size of message buffer */
#define  DEFSRVPORT  2345    /* default server port number */
#define  BACKLOG       50    /* length of listener queue */
#define  STACKSIZE  16384    /* worker thread's stack size */

int main(int argc, char *argv[])
{
  int    ret, portnum_in=0, i;
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  int service_client(int sfd);

  fprintf(stdout, "Connection-oriented server program ...\n");

  /* Get the port number from user, if any. */
  if (argc > 1)
    portnum_in = atoi(argv[1]);
  if (portnum_in <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum_in, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }
  else
    portnum = portnum_in;

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", errno,
      strerror(errno));
    return(-2);
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin_family = AF_INET;                   /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", errno,
      strerror(errno));
    return(-3);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", errno,
      strerror(errno));
    close(sfd);
    return(-4);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", errno,
        strerror(errno));
      close(sfd);
      return(-5);
    }

    fprintf(stdout, "Client Connected.\n");

    /* Service the client's requests. */
    ret = service_client(newsock);
    /* Note: We cannot close the socket here when using thread. */
    if (ret != 0 )
    {
      fprintf(stderr, "Error: service_client() failed, ret=%d\n", ret);
      close(newsock);
    }

  }  /* while - outer */
}

/*
 * This function is called to service the needs of a client by the server
 * after it has accepted a network connection request from a client.
 * This function dynamically allocates the memory for argument passing in
 * the heap. The child thread must free that memory after use.
 */
int service_client(int newsock)
{
  int    ret;

  pthread_t     thrd;
  unsigned int  *args;
  pthread_attr_t  attr;  /* thread attributes */
  int worker_thread(void *);

  /* Create a child thread to service the client. */

  /* Dynamically allocate buffer for argument passing. */
  args = (unsigned int *)malloc(sizeof(unsigned int));
  if (args == NULL)
  {
    fprintf(stderr, "Error: malloc() failed\n");
    close(newsock);
    return(-1);
  }

  /* Set the argument to pass on. */
  args[0] = (unsigned int)newsock;

  /* Initialize the pthread attributes. */
  ret = pthread_attr_init(&attr);
  if (ret != 0)
  {
    fprintf(stderr, "Error: failed to init thread attribute, ret=%d\n", ret);
    close(newsock);
    free(args);
    return(-2);
  }

  /* Set up to create detached threads. */
  ret = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  if (ret != 0)
  {
    fprintf(stderr, "Error: failed to set detach state, ret=%d\n", ret);
    close(newsock);
    free(args);
    ret = pthread_attr_destroy(&attr);
    return(-3);
  }

  /* Set thread's stack size. Error 22 is returned if value is wrong. */
  ret = pthread_attr_setstacksize(&attr, STACKSIZE);
  if (ret != 0)
  {
    fprintf(stderr, "Error: failed to set stack size, ret=%d\n", ret);
    close(newsock);
    free(args);
    ret = pthread_attr_destroy(&attr);
    return(-4);
  }

  /* Create a new thread to run the worker_thread() function. */
  ret = pthread_create(&thrd, (pthread_attr_t *)&attr,
          (void *(*)(void *))worker_thread, (void *)args);
  if (ret != 0)
  {
    fprintf(stderr, "Error: failed to create the worker thread\n");
    close(newsock);
    free(args);
    ret = pthread_attr_destroy(&attr);
    return(-5);
  }
  fprintf(stdout, "Thread with id=%ul is created to serve the client.\n", thrd);

  /* Destroy the pthread attributes. */
  ret = pthread_attr_destroy(&attr);
  if (ret != 0)
  {
    fprintf(stderr, "Error: failed to destroy thread attribute, ret=%d\n", ret);
  }

  return(0);
}

/*
 * The worker thread.
 * This worker thread gets an open file descriptor of a socket that is already
 * connected to a client and uses it to communicate with and service that
 * client.
 * This worker thread terminates when the client closes the connection.
 */
int worker_thread(void *args)
{
  unsigned int  *argp;
  int  newsock;
  int  ret;
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */

  /* Extract the argument. */
  argp = (unsigned int *)args;
  if (argp != NULL)
  {
    newsock = (int)argp[0];
    free(argp);    /* free the memory used to pass arguments */
  }
  else
    pthread_exit((void *)(-1));

  /* Receive and service requests from the client. */
  while (1)
  {
    /* Receive a request from a client. */
    errno = 0;
    inbuf[0] = '\0';
    ret = recv(newsock, inbuf, BUFLEN, 0);
    if (ret > 0)
    {
      /* Process the request. We simply print the request message here. */
      inbuf[ret] = '\0';
      fprintf(stdout, "\nReceived the following request from client:\n%s\n",
        inbuf);

      /* Set the reply message. */
      sprintf(outbuf, "%s%ul%s", "This is a reply from thread ", pthread_self(),
        " of the server program.");
      msglen = strlen(outbuf);

      /* Send a reply. */
      errno = 0;
      ret = send(newsock, outbuf, msglen, 0);
      if (ret == -1)
        fprintf(stderr, "Error: send() failed, errno=%d, %s\n", errno,
          strerror(errno));
      else
        fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
    }
    else if (ret < 0)
    {
      fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", errno,
        strerror(errno));
      break;
    }
    else
    {
      /* It comes here when the client goes away. */
      fprintf(stdout, "Warning: Zero bytes were received. Client may have disconnected.\n");
      break;
    }
  }  /* while */

  close(newsock);
  pthread_exit((void *)0);
}
