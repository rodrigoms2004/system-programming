/*
 * A connection-oriented server program using Stream socket.
 * Support for IPv4 and IPv6. Default to IPV6. Compile with -DIPV4 to get IPV4.
 * Support for multiple platforms including Linux, Windows, Solaris, AIX, HPUX
 * and Apple Darwin.
 * Usage: tcpsrv_peeraddr_all [port#]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;                      /* return code */
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
#if IPV4
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
#else
  struct sockaddr_in6   srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in6);
  struct sockaddr_in6   clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in6);
  int    v6only = 0;               /* IPV6_V6ONLY socket option off */
#endif
  in_port_t    portnum=DEFSRVPORT; /* port number */
  int    portnum_in = 0;           /* port number entered by user */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */
  unsigned int  msgcnt;            /* message count */
  struct sockaddr_in6   peeraddr6; /* IP address of peer socket */
  socklen_t    peeraddr6sz=sizeof(struct sockaddr_in6);
  char   peeraddrstr[PEERADDRLEN]; /* IP address of peer socket, string form */

#if WINDOWS
  WSADATA wsaData;                 /* Winsock data */
  char* GetErrorMsg(int ErrorCode); /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented server program ...\n");

  /* Get the port number from user, if any. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = (in_port_t)portnum_in;
  }

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Create the Stream server socket. */
  if ((sfd = socket(ADDR_FAMILY, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
#if IPV4
  srvaddr.sin_family = ADDR_FAMILY;               /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */
#else
  srvaddr.sin6_family = ADDR_FAMILY;              /* Internet socket */
  srvaddr.sin6_addr = in6addr_any;                /* server's IP address */
  srvaddr.sin6_port = htons(portnum);             /* server's port number */
#endif

  /* If IPv6, turn off IPV6_V6ONLY socket option. Default is on in Windows. */
#if !IPV4
  if (setsockopt(sfd, IPPROTO_IPV6, IPV6_V6ONLY, (char*)&v6only,
    sizeof(v6only)) != 0)
  {
    fprintf(stderr, "Error: setsockopt(IPV6_V6ONLY) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }
#endif

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-5);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return(-6);
    }

    fprintf(stdout, "Client Connected.\n");

    /* Print the peer's IP address & port# returned from accept() */
    memset(peeraddrstr, 0, PEERADDRLEN);
    inet_ntop(AF_INET6, &(clntaddr.sin6_addr), peeraddrstr, PEERADDRLEN);
    fprintf(stdout, "Client's IP address from accept(): %s port=%u\n",
      peeraddrstr, ntohs(clntaddr.sin6_port));

    /* Get and print peer's IP address & port# returned from getpeername() */
    memset(&peeraddr6, 0, peeraddr6sz);
    memset(peeraddrstr, 0, PEERADDRLEN);
    errno = 0;
    ret = getpeername(newsock, (struct sockaddr *)&peeraddr6, &peeraddr6sz);
    if (ret == 0)
    {
      inet_ntop(AF_INET6, &(peeraddr6.sin6_addr), peeraddrstr, PEERADDRLEN);
      fprintf(stdout, "Client's IP address from getpeername(): %s port=%u\n",
        peeraddrstr, ntohs(peeraddr6.sin6_port));
    }
    else
      fprintf(stderr, "Error: getpeername() failed, errno=%d, %s\n", ERRNO,
        ERRNOSTR);

    msgcnt = 1;
    /* Receive and service requests from the current client. */
    while (1)
    {
      /* Receive a request from a client. */
      errno = 0;
      inbuf[0] = '\0';
      ret = recv(newsock, inbuf, BUFLEN, 0);
      if (ret > 0)
      {
        /* Process the request. We simply print the request message here. */
        inbuf[ret] = '\0';
        fprintf(stdout, "\nReceived the following request from client:\n%s\n",
          inbuf);

        /* Construct a reply */
        sprintf(outbuf, "This is reply #%3u from the server program.", msgcnt++);
        msglen = strlen(outbuf);

        /* Send a reply. */
        errno = 0;
        ret = send(newsock, outbuf, msglen, 0);
        if (ret == -1)
          fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
        else
          fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
      }
      else if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
          ERRNOSTR);
        break;
      }
      else
      {
        /* The client may have disconnected. */
        fprintf(stdout, "The client may have disconnected.\n");
        break;
      }
    }  /* while - inner */
    CLOSE1(newsock);
  }  /* while - outer */

  CLOSE(sfd);
  return(0);
}
