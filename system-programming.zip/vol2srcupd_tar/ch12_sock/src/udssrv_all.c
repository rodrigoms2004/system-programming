/*
 * A connection-oriented server program using Unix domain stream socket.
 * Support of multiple platforms including Linux, Solaris, AIX, HPUX, Windows
 * and Apple Darwin.
 * Usage: udssrv_all 
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;                      /* return code */
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_un    srvaddr;   /* server socket structure */
  int    srvaddrsz = sizeof(struct sockaddr_un);
  struct sockaddr_un    clntaddr;  /* client socket structure */
  socklen_t    clntaddrsz = sizeof(struct sockaddr_un);
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */
  unsigned int  msgcnt;            /* message count */

#if WINDOWS
  WSADATA wsaData;                 /* Winsock data */
  char* GetErrorMsg(int ErrorCode); /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented server program using Unix Domain "
    "socket...\n");

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(-2);
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sun_family = AF_UNIX;   
  strcpy(srvaddr.sun_path, SERVER_PATH); 

  /* Bind the server socket to its address. */
  unlink(SERVER_PATH);
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-3);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-4);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening for client connect request ...\n");
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return(-5);
    }

    fprintf(stdout, "Client Connected. Client file path=%s\n", 
      clntaddr.sun_path);

    msgcnt = 1;
    /* Receive and service requests from the current client. */
    while (1)
    {
      /* Receive a request from a client. */
      errno = 0;
      inbuf[0] = '\0';
      ret = recv(newsock, inbuf, BUFLEN, 0);
      if (ret > 0)
      {
        /* Process the request. We simply print the request message here. */
        inbuf[ret] = '\0';
        fprintf(stdout, "\nReceived the following request from client:\n%s\n",
          inbuf);

        /* Construct a reply */
        sprintf(outbuf, "This is reply #%3u from the server program.", msgcnt++);
        msglen = strlen(outbuf);

        /* Send a reply. */
        errno = 0;
        ret = send(newsock, outbuf, msglen, 0);
        if (ret == -1)
          fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
        else
          fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
      }
      else if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
          ERRNOSTR);
        break;
      }
      else
      {
        /* The client may have disconnected. */
        fprintf(stdout, "The client may have disconnected.\n");
        break;
      }
    }  /* while - inner */

    CLOSE1(newsock);
  }  /* while - outer */

  CLOSE(sfd);
  return(0);
}
