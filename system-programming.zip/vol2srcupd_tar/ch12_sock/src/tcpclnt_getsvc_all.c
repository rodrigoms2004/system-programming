/*
 * A connection-oriented client program using Stream socket.
 * Connecting to a server program on any host using a hostname or IP address.
 * Support for IPv4 and IPv6 and multiple platforms including 
 * Linux, Windows, Solaris, AIX, HPUX and Apple Darwin.
 * Usage: tcpclnt_getsvc_all [srvport# [server-hostname | server-ipaddress]]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"

int main(int argc, char *argv[])
{
  int    ret;
  int    sfd;                     /* socket file descriptor */
  char   portnumstr[12];          /* port number in string format */
  char   *svcname = SVCNAME;      /* pointer to service name */
  struct servent *srvService;     /* server's service */

  char   inbuf[BUFLEN];           /* input message buffer */
  char   outbuf[BUFLEN];          /* output message buffer */
  size_t msglen;                  /* length of reply message */
  size_t msgnum=0;                /* count of request message */
  size_t len;
  char   server_name[NAMELEN+1] = SERVER_NAME;
  struct addrinfo hints, *res=NULL;  /* address info */

#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented client program ...\n");

  /* Get the server's service name from command line. */
  if (argc > 1)
    svcname = argv[1];

  /* Get the server's host name or IP address from command line. */
  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2], len);
    server_name[len] = '\0';
  }

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (-1);
  }
#endif

  /* Look up server's port number from /etc/services file. */
  srvService = getservbyname(svcname, PROTOCOLNAME);
  if (srvService == NULL)
  {
#if WINDOWS
    ret = WSAGetLastError();
    fprintf(stderr, "Error: getservbyname() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
#else
    fprintf(stderr, "Error: getservbyname() failed.\n");
#endif
    return(-2);
  }

  if (argc <= 1)
    strcpy(portnumstr, DEFSRVPORTSTR);
  else
    sprintf(portnumstr, "%d", ntohs(srvService->s_port));

  /* Translate the server's host name or IP address into socket address.
   * Fill in the hints information.
   */
  memset(&hints, 0x00, sizeof(hints));
    /* This works on AIX but not on Solaris, nor on Windows. */
    /* hints.ai_flags    = AI_NUMERICSERV; */
  hints.ai_family   = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_protocol = IPPROTO_TCP;

  /* Get the address information of the server using getaddrinfo().
   * This function returns errors directly or 0 for success. On success,
   * argument res contains a linked list of addrinfo structures.
   */
  ret = getaddrinfo(server_name, portnumstr, &hints, &res);
  if (ret != 0)
  {
    fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
      gai_strerror(ret));
#if !WINDOWS
    if (ret == EAI_SYSTEM)
      fprintf(stderr,"System error: errno=%d, %s\n", errno, strerror(errno));
#else
    WSACleanup();
#endif
    return(-3);
  }

  /* Create a socket. */
  sfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return (-4);
  }

  /* Connect to the server. */
  ret = connect(sfd, res->ai_addr, res->ai_addrlen);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(-5);
  }

  fprintf(stdout, "Send request messages to server(%s) at port %s\n",
   server_name, portnumstr);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO,
            ERRNOSTR);
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);

    /* Sleep a second. For demo only. Remove this in real code. */
#if WINDOWS
    Sleep(1000); /* Unit is ms. For demo only. Remove this in real code. */
#else
    sleep(1);  /* For demo only. Remove this in real code. */
#endif
  }  /* while */

  /* Free the memory allocated by getaddrinfo() */
  freeaddrinfo(res);
  CLOSE(sfd);
  return(0);
}
