/*
 * A connection-oriented client program using Stream socket.
 * Connecting to server on the same (local) host or a different remote host.
 * Usage: tcpclnt1 [srvport# [server-ipaddress]]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <arpa/inet.h>     /* inet_pton(), inet_ntoa() */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <unistd.h>        /* close(), sleep() */

#define  BUFLEN      1024    /* size of input message buffer */
#define  DEFSRVPORT  2345    /* default server port number */
#define  MAXMSGS        3    /* Maximum number of messages to send */
#define  IPV4LOCALADDR "127.0.0.1"  /* IPv4 address for local host */

int main(int argc, char *argv[])
{
  int    ret, portnum_in=0;
  int    sfd;                      /* file descriptor of the socket */
  struct sockaddr_in    server;    /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    fromaddr;  /* socket structure */
  socklen_t    fromaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t    msglen;                /* length of reply message */
  size_t    msgnum=0;              /* count of request message */
  char *ipaddrstr = IPV4LOCALADDR; /* server's IP address in string format */
  in_addr_t ipaddrbin;             /* server's IP address in binary format */

  fprintf(stdout, "Connection-oriented client program ...\n");

  /* Get the port number from user, if any. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = (in_port_t)portnum_in;
  }

  /* Get the server's IP address from user, if any. */
  if (argc > 2)
    ipaddrstr = argv[2];

  /* Convert the server's IP address from string format to binary */
  ret = inet_pton(AF_INET, ipaddrstr, &ipaddrbin);
  if (ret == 0)
  {
    fprintf(stderr, "%s is not a valid IPv4 address.\n", ipaddrstr);
    return(-1);
  }

  /* Create the client socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", errno,
      strerror(errno));
    return(-2);
  }

  /* Fill in the server's address. */
  memset((void *)&server, 0, (size_t)srvaddrsz); /* clear the address buffer */
  server.sin_family = AF_INET;                   /* Internet socket */
  if (strcmp(ipaddrstr, IPV4LOCALADDR))
    server.sin_addr.s_addr = ipaddrbin;
  else
    server.sin_addr.s_addr = htonl(INADDR_ANY);  /* server's IP address */
  server.sin_port = htons(portnum);              /* server's port number */

  /* Connect to the server. */
  ret = connect(sfd, (struct sockaddr *)&server, srvaddrsz);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", errno,
      strerror(errno));
    close(sfd);
    return(-3);
  }

  fprintf(stdout, "Send request messages to server(%s) at port %d\n",
   ipaddrstr, portnum);

  /* Send request messages to the server and process the reply messages. */
  while (msgnum < MAXMSGS)
  {
    /* Send a request message to the server. */
    sprintf(outbuf, "%s%4lu%s", "This is request message ", ++msgnum,
      " from the client program.");
    msglen = strlen(outbuf);
    errno = 0;

    ret = send(sfd, outbuf, msglen, 0);
    if (ret >= 0)
    {
      /* Print a warning if not entire message was sent. */
      if (ret == msglen)
        fprintf(stdout, "\n%lu bytes of message were successfully sent.\n",
          msglen);
      else if (ret < msglen)
        fprintf(stderr, "Warning: only %u of %lu bytes were sent.\n",
          ret, msglen);

      if (ret > 0)
      {
        /* Receive a reply from the server. */
        errno = 0;
        inbuf[0] = '\0';
        ret = recv(sfd, inbuf, BUFLEN, 0);

        if (ret > 0)
        {
          /* Process the reply. */
          inbuf[ret] = '\0';
          fprintf(stdout, "Received the following reply from server:\n%s\n",
            inbuf);
        }
        else if (ret == 0)
          fprintf(stdout, "Warning: Zero bytes were received.\n");
        else
          fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", errno,
            strerror(errno));
      }
    }
    else
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", errno,
        strerror(errno));

    sleep(1);  /* For demo only. Remove this in real code. */
  }  /* while */

  close(sfd);
}
