/*
 * A connection-oriented server program using Stream socket.
 * Multi-threaded server using processes.
 * Usage: tcpsrvp [port#]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2017, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset() */
#include <stdlib.h>        /* atoi() */
#include <signal.h>        /* sigaction() */
#include <unistd.h>        /* close(), fork() */

#define  BUFLEN      1024    /* size of message buffer */
#define  DEFSRVPORT  2345    /* default server port number */
#define  BACKLOG       50    /* length of listener queue */

int main(int argc, char *argv[])
{
  int    ret, portnum_in=0, i;
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in    srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in);
  struct sockaddr_in    clntaddr;  /* socket structure */
  socklen_t    clntaddrsz=sizeof(struct sockaddr_in);
  in_port_t    portnum=DEFSRVPORT; /* port number */
  int service_client(int sfd);
  struct sigaction  oldact, newact;

  fprintf(stdout, "Connection-oriented server program ...\n");

  /* Ignore the SIGCHLD signal so child processes won't become defunct. */
  sigfillset(&newact.sa_mask);
  newact.sa_flags = 0;
  newact.sa_handler = SIG_IGN;
  ret = sigaction(SIGCHLD, &newact, &oldact);
  if (ret != 0)
  {
    fprintf(stderr, "sigaction failed, errno=%d, %s\n", errno, strerror(errno));
    return(-1);
  }

  /* Get the port number from user, if any. */
  if (argc > 1)
    portnum_in = atoi(argv[1]);
  if (portnum_in <= 0)
  {
    fprintf(stderr, "Port number %d invalid, set to default value %u\n",
      portnum_in, DEFSRVPORT);
    portnum = DEFSRVPORT;
  }
  else
    portnum = portnum_in;

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", errno,
      strerror(errno));
    return(-2);
  }

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin_family = AF_INET;                   /* Internet socket */
  srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);    /* server's IP address */
  srvaddr.sin_port = htons(portnum);              /* server's port number */

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", errno,
      strerror(errno));
    return(-3);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", errno,
      strerror(errno));
    close(sfd);
    return(-4);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", errno,
        strerror(errno));
      close(sfd);
      return(-5);
    }

    fprintf(stdout, "Client Connected.\n");

    /* Service the client's requests. */
    ret = service_client(newsock);
    close(newsock);

  }  /* while - outer */
}

/*
 * This function is called to service the needs of a client by the server
 * after it has accepted a network connection request from a client.
 */
int service_client(int newsock)
{
  int    ret;
  pid_t  pid;
  char   inbuf[BUFLEN];            /* input message buffer */
  char   outbuf[BUFLEN];           /* output message buffer */
  size_t msglen;                   /* length of reply message */

  /* Create a child process to service the client. */
  pid = fork();

  if (pid == -1)
  {
    fprintf(stderr, "fork() failed, errno=%d, %s\n", errno, strerror(errno));
    return(-7);
  }
  else if (pid == 0)
  {
    /* This is the child process. */
    /* Receive and service requests from the client. */
    while (1)
    {
      /* Receive a request from a client. */
      errno = 0;
      inbuf[0] = '\0';
      ret = recv(newsock, inbuf, BUFLEN, 0);
      if (ret > 0)
      {
        /* Process the request. We simply print the request message here. */
        inbuf[ret] = '\0';
        fprintf(stdout, "\nReceived the following request from client:\n%s\n",
          inbuf);

        /* Set the reply message */
        sprintf(outbuf, "%s", "This is a reply from the server program.");
        msglen = strlen(outbuf);

        /* Send a reply. */
        errno = 0;
        ret = send(newsock, outbuf, msglen, 0);
        if (ret == -1)
          fprintf(stderr, "Error: send() failed, errno=%d, %s\n", errno,
            strerror(errno));
        else
          fprintf(stdout, "%u of %lu bytes of the reply was sent.\n", ret, msglen);
      }
      else if (ret < 0)
      {
        fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", errno,
          strerror(errno));
        break;
      }
      else
      {
        /* It may come here when the client goes away. */
        fprintf(stdout, "The client may have disconnected.\n");
        break;
      }
    }  /* while */

    close(newsock);
    exit(0);
  }
  else
  {
    /* This is the parent process. */
    /* The parent has nothing to do here. */
    return(0);
  }
}
