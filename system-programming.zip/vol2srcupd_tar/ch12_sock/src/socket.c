/*
 * socket()
 * Different combinations of socket types and protocols that are supported.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2016, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <unistd.h>

int main(int argc, char *argv[])
{
  int    sockfd;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_STREAM, 0) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_STREAM, 0) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_DGRAM, 0) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_DGRAM, 0) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_STREAM, IPPROTO_TCP) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_STREAM, IPPROTO_TCP) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_UNIX, SOCK_STREAM, 0) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_UNIX, SOCK_STREAM, 0) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_UNIX, SOCK_DGRAM, 0) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_UNIX, SOCK_DGRAM, 0) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_UNIX, SOCK_SEQPACKET, 0);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_UNIX, SOCK_SEQPACKET, 0) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_UNIX, SOCK_SEQPACKET, 0) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_RAW, IPPROTO_RAW) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_RAW, IPPROTO_RAW) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_RAW, IPPROTO_ICMP) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_RAW, IPPROTO_ICMP) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_EGP);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_RAW, IPPROTO_EGP) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_RAW, IPPROTO_EGP) is supported\n");
    close(sockfd);
  }

  sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_RSVP);
  if (sockfd == -1)
    fprintf(stderr, "socket(AF_INET, SOCK_RAW, IPPROTO_RSVP) failed, errno=%d\n", errno);
  else
  {
    fprintf(stdout, "socket(AF_INET, SOCK_RAW, IPPROTO_RSVP) is supported\n");
    close(sockfd);
  }

  return(0);
}
