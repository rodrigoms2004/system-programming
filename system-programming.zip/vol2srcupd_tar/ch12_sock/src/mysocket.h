/*
 * Include file for cross-platform socket applications.
 * Supported operating systems: Linux, Unix (AIX, Solaris, HP-UX), Windows.
 * Copyright (c) 2002, 2014, 2017, 2018, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

/*
 * Standard include files for socket applications
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>        /* memset(), strerror() */
#include <stdlib.h>        /* atoi() */
#include <ctype.h>         /* isalpha() */

#ifdef WINDOWS

#define WIN32_LEAN_AND_MEAN
#include <Winsock2.h>
#include <ws2tcpip.h>
#include <mstcpip.h>
#include <Windows.h>       /* Sleep() - link Kernel32.lib */

/* Needed for the Windows 2000 IPv6 Tech Preview. */
#if (_WIN32_WINNT == 0x0500)
#include <tpipv6.h>
#endif

#define STRICMP _stricmp
typedef unsigned short in_port_t;
typedef unsigned int in_addr_t;

#else  /* ! WINDOWS */

/* Unix and Linux */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <arpa/inet.h>     /* inet_pton(), inet_ntoa() */
#include <netdb.h>         /* struct hostent, gethostbyaddr() */
#include <time.h>          /* nanosleep() */
/* The next four are for async I/O. */
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/select.h>
/* Below is for Unix Domain socket */
#include <sys/un.h>

#endif

/*
 * Some constants: port number, buffer length, etc.
 */
#define  BUFLEN           1024    /* size of I/O buffer */
#define  BUFLEN1           128    /* size of small I/O buffer */
#define  DEFSRVPORT       2345    /* default server port number */
#define  DEFSRVPORTSTR  "2345"    /* default server port number string */
#define  NAMELEN            63    /* max. length of names */
#define  MAXMSGS             2    /* maximum number of messages to exchange */
#define  BACKLOG            50    /* length of listener queue */
#define  IPADDRSZ          128    /* size of buffer for IP address */
#define  MAXSOURCES          5    /* Maximum number of message sources */
#define  SLEEPS              3    /* number of seconds to sleep */
#define  SLEEPMS            10    /* number of milliseconds to sleep & wait */
#define  PEERADDRLEN        64    /* length of buffer for peer address */
#define  SRVIPLEN           64    /* max. length of IP address */
#define  MAXCONNTRYCNT       5    /* Maximum connect try count */
#define  FALSE               0
#define  NETDB_MAX_HOST_NAME_LENGTH  256    /* max. length of a host name */
#define  SERVER_NAME         "localhost"    /* default server's host name */
#define  NOHOST             ""
#define  IPV6LOCALADDR   "::1"    /* IPv6 address for local host */
/* These are for Unix domain socket. */
#define  SERVER_PATH   ".udssrv_name"   /* file pathname of the server */
#define  CLIENT_PATH   ".udsclnt_name"  /* file pathname of the client */
/* These are for getservbyname() call. */
#define  SVCNAME         "dbm"    /* default service name */
#define  PROTOCOLNAME    "tcp"    /* default protocol name */
#define  IPV4LOCALADDR "127.0.0.1"      /* IPv4 address for local host */
/* These below are for multicasting. */
#define  MULTICASTGROUP  "224.0.0.251"  /* address of the multicast group */
#define  MULTICASTGROUP2 "224.1.1.1"    /* address of the multicast group */
#define  LOCALINTFIPADDR "127.0.0.1"    /* address of local interface */
#define  MCASTPORT              3456    /* multicast group port number */

/*
 * Macros for printing and handling socket errors
 */

#if WINDOWS
#define ERRNO WSAGetLastError()
#define ERRNOSTR GetErrorMsg(WSAGetLastError())
#define CLOSE(sfd)  shutdown(sfd, SD_BOTH); closesocket(sfd); WSACleanup();
#define CLOSE1(sfd) shutdown(sfd, SD_BOTH); closesocket(sfd);
#else
#define ERRNO errno
#define ERRNOSTR strerror(errno)
#define CLOSE(sfd) close(sfd)
#define CLOSE1(sfd) close(sfd)
#endif

/* IP address family */
#if IPV4
#define  ADDR_FAMILY AF_INET        /* IPv4 */
#else
#define  ADDR_FAMILY AF_INET6       /* IPv6 */
#endif

/*
 * Function to get error message in Windows
 */

#if WINDOWS
#define ERRBUFLEN1 512
char* GetErrorMsg(int ErrorCode)
{
  static char ErrorMsg[ERRBUFLEN1];

  /* For multi-threaded applications, use FORMAT_MESSAGE_ALLOCATE_BUFFER
   * or malloc-ed buffer here instead of a static buffer.
   */
  FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS |
                FORMAT_MESSAGE_MAX_WIDTH_MASK,
                NULL, ErrorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                (LPSTR) ErrorMsg, ERRBUFLEN1, NULL);
  return (ErrorMsg);
}
#endif

