/*
 * My cross-platform standard include file.
 * Copyright (c) 2002, 2014-2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>        /* memset(), strerror() */
#include <stdlib.h>        /* atoi() */

#ifdef WINDOWS

#define WIN32_LEAN_AND_MEAN
#include <Winsock2.h>
#include <ws2tcpip.h>
#include <mstcpip.h>
#include <Windows.h>       /* Sleep() - link Kernel32.lib */

/* Needed for the Windows 2000 IPv6 Tech Preview. */
#if (_WIN32_WINNT == 0x0500)
#include <tpipv6.h>
#endif

#define STRICMP _stricmp
typedef unsigned short in_port_t;
typedef unsigned int in_addr_t;

#else  /* ! WINDOWS */

/* Unix and Linux */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <arpa/inet.h>     /* inet_pton(), inet_ntoa() */
#include <netdb.h>         /* struct hostent, gethostbyaddr() */
#include <time.h>          /* nanosleep() */
/* The next few are for async I/O and file I/O. */
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/stat.h>
/* Below is for Unix Domain socket */
#include <sys/un.h>

#endif

