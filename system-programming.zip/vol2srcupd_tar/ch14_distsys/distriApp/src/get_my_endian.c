/*
 * Get the endian format of this local computer.
 * Authored by Jin-Jwei Chen
 * Copyright (c) 2010-2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include "mydistsys.h"

/* Find the endian type of this local CPU */
int endian()
{
  unsigned int          x = 0x01020304;
  unsigned char         *px = (unsigned char *)&x;

  if (px[0] == 0x01)
    return(BIG_ENDIAN);
  else if (px[0] == 0x04)
    return(LITTLE_ENDIAN);
  else
    return(UNKNOWN_ENDIAN);
}

int main(int argc, char *argv[])
{
  int   myendian;

  myendian = endian();
  if (myendian == LITTLE_ENDIAN)
    printf("This is a little endian processor.\n");
  else if (myendian == BIG_ENDIAN)
    printf("This is a big endian processor.\n");
  else
    printf("This is not a little or big endian processor.\n");
}
