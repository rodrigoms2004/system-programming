/*
 * All error codes defined by the application.
 * Supported operating systems: Linux, Unix (AIX, Solaris, HP-UX), Windows.
 * Copyright (c) 1995, 2014, 2019 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <errno.h>      /* system-defined errors */

/*
 * Error codes defined by applications
 */

/* Success */
#define SUCCESS 0

/* Base value of all error codes defined. */
#define BASE_ERROR_NUM 5000

/* All error codes from component 1. */
#define PROD_ERR_WINSOCK_INIT      (BASE_ERROR_NUM+1)
#define PROD_ERR_GETADDRINFO       (BASE_ERROR_NUM+2)
#define PROD_ERR_SOCKET_CREATE     (BASE_ERROR_NUM+3)
#define PROD_ERR_BIND              (BASE_ERROR_NUM+4)
#define PROD_ERR_LISTEN            (BASE_ERROR_NUM+5)
#define PROD_ERR_ACCEPT            (BASE_ERROR_NUM+6)
#define PROD_ERR_CONNECT           (BASE_ERROR_NUM+7)
#define PROD_ERR_SOCKET_SEND       (BASE_ERROR_NUM+8)
#define PROD_ERR_SOCKET_RECV       (BASE_ERROR_NUM+9)
#define PROD_ERR_SETSOCKETOPT      (BASE_ERROR_NUM+10)
#define PROD_ERR_GETSOCKETOPT      (BASE_ERROR_NUM+11)
#define PROD_ERR_WRONGMAGIC        (BASE_ERROR_NUM+12)
#define PROD_ERR_READ              (BASE_ERROR_NUM+13)
#define PROD_ERR_WRITE             (BASE_ERROR_NUM+14)
#define PROD_ERR_OPEN              (BASE_ERROR_NUM+15)

/* The base value and all error codes from component 2. */
#define BASE_ERROR_NUM2 (BASE_ERROR_NUM+1000)
#define PROD_ERR_BAD_OPCODE        (BASE_ERROR_NUM2+1)
#define PROD_ERR_NO_MEMORY         (BASE_ERROR_NUM2+2)
#define PROD_ERR_BAD_SYNTAX        (BASE_ERROR_NUM2+3)
#define PROD_ERR_NAME_TOOLONG      (BASE_ERROR_NUM2+4)

