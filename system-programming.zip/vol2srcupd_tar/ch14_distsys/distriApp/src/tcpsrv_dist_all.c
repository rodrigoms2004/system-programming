/*
 * A connection-oriented server program using Stream socket.
 * Demonstrating design of distributed applications.
 * Support for multiple platforms including Linux, Windows, Solaris, AIX, HPUX.
 * Usage: tcpsrv_dist_all [port#] 
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2002, 2014, 2017-2021 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"
#include "mydistsys.h"
#include "myerrors.h"

int receive_init_pkt(int sfd);
int service_client(int newsock);

int main(int argc, char *argv[])
{
  int    ret;                      /* return code */
  int    sfd;                      /* file descriptor of the listener socket */
  int    newsock;                  /* file descriptor of client data socket */
  struct sockaddr_in6   srvaddr;   /* socket structure */
  int    srvaddrsz=sizeof(struct sockaddr_in6);
  struct sockaddr_in6   clntaddr;  /* socket structure */
  socklen_t clntaddrsz = sizeof(struct sockaddr_in6);
  in_port_t portnum = DEFSRVPORT;  /* port number */
  int    portnum_in;               /* port number entered by user */
  int    sw;                       /* value of option */
  int    v6only = 0;               /* IPV6_V6ONLY socket option off */
#if !WINDOWS
  struct timespec  sleeptm;        /* sleep time */
#endif
#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented server program, version %u ...\n",
    CURRENT_VER);

  /* Get the server's port number from user, if any. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
    }
    else
      portnum = portnum_in;
  }

#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (PROD_ERR_WINSOCK_INIT);
  }
#endif

  /* Create the Stream server socket. */
  if ((sfd = socket(AF_INET6, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    return(PROD_ERR_SOCKET_CREATE);
  }

  /* Always turn on SO_REUSEADDR socket option on the server. */
  sw = 1;
  errno = 0;
  if (setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, (char *)&sw, sizeof(sw)) < 0)
  {
    fprintf(stderr, "setsockopt(SO_REUSEADDR) failed, errno=%d, %s\n", ERRNO,
      ERRNOSTR);
  }
  else
    fprintf(stdout, "SO_REUSEADDR socket option is turned on.\n");

  /* Fill in the server socket address. */
  memset((void *)&srvaddr, 0, (size_t)srvaddrsz); /* clear the address buffer */
  srvaddr.sin6_family = AF_INET6;                 /* Internet socket */
  srvaddr.sin6_addr= in6addr_any;                 /* server's IP address */
  srvaddr.sin6_port = htons(portnum);             /* server's port number */

  /* Turn off IPV6_V6ONLY socket option. Default is on in Windows. */
  if (setsockopt(sfd, IPPROTO_IPV6, IPV6_V6ONLY, (char*)&v6only,
    sizeof(v6only)) != 0)
  {
    fprintf(stderr, "Error: setsockopt(IPV6_V6ONLY) failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(PROD_ERR_SETSOCKETOPT);
  }

  /* Bind the server socket to its address. */
  if ((ret = bind(sfd, (struct sockaddr *)&srvaddr, srvaddrsz)) != 0)
  {
    fprintf(stderr, "Error: bind() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(PROD_ERR_BIND);
  }

  /* Set maximum connection request queue length that we can fall behind. */
  if (listen(sfd, BACKLOG) == -1) {
    fprintf(stderr, "Error: listen() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    CLOSE(sfd);
    return(PROD_ERR_LISTEN);
  }

  /* Wait for incoming connection requests from clients and service them. */
  while (1) {

    fprintf(stdout, "\nListening at port number %u ...\n", portnum);
    newsock = accept(sfd, (struct sockaddr *)&clntaddr, &clntaddrsz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      CLOSE(sfd);
      return(PROD_ERR_ACCEPT);
    }

    fprintf(stdout, "Client Connected.\n");

    ret = service_client(newsock);
    CLOSE1(newsock);
  }  /* while - outer */

  CLOSE(sfd);
  return(SUCCESS);
}

/* Receive initial packet from a newly connectede client.
 * Perform some security checks or authentication.
 */
int receive_init_pkt(int sfd)
{
  init_pkt_t  initmsg;
  int         ret;

  memset((void *)&initmsg, 0, sizeof(init_pkt_t));
  errno = 0;
  ret = recv(sfd, (void *)&initmsg, sizeof(init_pkt_t), 0);
  if (ret < 0)
  {
    fprintf(stderr, "Error: receive_init_pkt(), recv() failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
    return(PROD_ERR_SOCKET_RECV);
  }
  else if (ret != sizeof(init_pkt_t))
  {
    fprintf(stderr, "Error: receive_init_pkt(), recv() failed. Only %d out of"
      " %lu bytes of data received.\n", ret, sizeof(init_pkt_t));
    return(PROD_ERR_SOCKET_RECV);
  }

  /* Make sure the magic number always matches. */
  if (ntohl(initmsg.magic) != PROTO_MAGIC)
  {
    fprintf(stderr, "Error: receive_init_pkt(), wrong magic number.\n");
    return(PROD_ERR_WRONGMAGIC);
  }
  
  /* Perform protocol version-specific operations here if it applies. */
  if (ntohl(initmsg.version >= CURRENT_VER))
  {
    /* Perform some authentication here ... */

    return(SUCCESS);
  }
  return(0);
}

/*
 * This function is called by the server to service the needs of a client
 * after it has accepted a network connection request from a client.
 */
int service_client(int newsock)
{
  int    ret;
  char   *inbuf = NULL;                /* pointer to input data buffer */
  char   *outbuf = NULL;               /* pointer to output message buffer */
  int    *indata_ptr = NULL;           /* pointer to input data from client */
  int    indata = 0;                   /* input data from client */
  size_t               msglen;         /* length of client request message */
  unsigned long long   buflen = 0L;    /* length of input data buffer */
  unsigned long long   result = 0L;    /* output result of multiplication */
  unsigned long long   *result_ptr;    /* pointer to result */
  req_pkt_t request;                   /* client's request */
  req_pkt_t *reqmsg=NULL;              /* pointer to client's request msg */
  req_pkt_t *rplymsg = NULL;           /* pointer to reply to client */
  int                 bytes;           /* number of bytes read */
  unsigned long long  total_bytes;     /* total number of bytes read */
  int                 opcode;          /* operation requested by client */
  int                 status;          /* status of operation */

  /* Receive initial packet. Close the connection if it fails.
   * Make sure we always terminate the connection right away in case of magic
   * number mismatch or others to prevent denial-of-service (DOS) attacks.
   */
  ret = receive_init_pkt(newsock);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "Error: service_client(), receive_init_pkt() failed, "
      "ret=%d\n", ret);
    CLOSE1(newsock);
    return(ret);
  }

  /* Service the connected client until it is done.
   * Receive a request and service the request in each interation.
   */
  while (1)
  {
    /* Receive the request header from the connected client. */
    msglen = sizeof(request);
    reqmsg = &request;
    memset(reqmsg, 0, msglen);
    errno = 0;
    ret = recv(newsock, reqmsg, msglen, 0);
    if (ret < 0)
    {
      fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (PROD_ERR_SOCKET_RECV);
      goto return1;
    }
    else if (ret == 0)
    {
      fprintf(stderr, "The client has closed.\n");
      ret = (PROD_ERR_SOCKET_RECV);
      goto return1;
    }
    else if (ret != msglen)
    {
      fprintf(stderr, "Error: recv() failed. Only %d out of %lu bytes were "
        "received.\n", ret, msglen);
      ret = (PROD_ERR_SOCKET_RECV);
      goto return1;
    }

    fprintf(stdout, "Client version=%d\n", ntohl(reqmsg->version));

    /* Perform some sanity check */
    if (ntohl(reqmsg->magic) != REQ_MAGIC)
    {
      fprintf(stderr, "Error: service_client(), wrong magic number.\n");
      ret = (PROD_ERR_WRONGMAGIC);
      goto return1;
    }

    /* Receive the request data if any */
    buflen = ntohll(reqmsg->datasz);
    if (buflen > 0)
    {
      /* Allocate buffer for the input data */
      inbuf = (char *)malloc(buflen);
      if (inbuf == NULL)
      {
        fprintf(stderr, "malloc() failed.\n");
        ret = (PROD_ERR_NO_MEMORY);
        goto return1;
      }

      /* Read all input data */
      errno = 0;
      total_bytes = 0L;
      do {
        bytes = read(newsock, inbuf+total_bytes, (buflen-total_bytes));
        if (bytes < 0)
        {
          fprintf(stderr, "Error: read() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
          ret = (PROD_ERR_SOCKET_RECV);
          goto return1;
        }
        else if (bytes == 0)
        {
          fprintf(stderr, "The client has closed.\n");
          ret = (PROD_ERR_SOCKET_RECV);
          goto return1;
        }
        total_bytes = total_bytes + (unsigned long long)bytes;
      } while (total_bytes < buflen);
    }

    /* Extract the input data and perform the requested operation
       which are version specific. So versioning is done here. */
    opcode = ntohl(reqmsg->operation);
    if (ntohl(reqmsg->version >= CURRENT_VER))
    {
      switch(opcode)
      {
        case REQ_OPCODE1:
          indata_ptr = (int *)(inbuf);
          indata =  ntohl(*indata_ptr);
          fprintf(stdout, "Client input data is %d\n", indata);
          result = ((unsigned long long)indata * 100);
          status = SUCCESS;
          fprintf(stdout, "Multiplication result is %llu\n", result);
        break;
        default:
          status = PROD_ERR_BAD_OPCODE;
          result = 0L;
          fprintf(stdout, "Operation code %d is not supported.\n", opcode);
        break;
      }
    }

    /* Send a reply */
    msglen = (sizeof(req_pkt_t) + sizeof(unsigned long long));
    if (outbuf == NULL)
    {
      outbuf = (char *)malloc(msglen);
      if (outbuf == NULL)
      {
        fprintf(stderr, "malloc() failed.\n");
        ret = (PROD_ERR_NO_MEMORY);
        goto return1;
      }
    }
    memset(outbuf, 0, msglen);

    /* Fill in the reply message */
    rplymsg = (req_pkt_t *)outbuf;
    rplymsg->version = htonl(CURRENT_VER);
    rplymsg->magic = htonl(REPLY_MAGIC);
    rplymsg->operation = reqmsg->operation;
    rplymsg->status = htonl(status);
    rplymsg->datasz = htonll(sizeof(unsigned long long));
    result_ptr = (unsigned long long *)(outbuf + sizeof(req_pkt_t));
    *result_ptr = htonll(result);

    /* Send the reply message */
    errno = 0;
    ret = send(newsock, outbuf, msglen, 0);
    if (ret < 0)
    {
      fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
      ret = (PROD_ERR_SOCKET_SEND);
      goto return1;
    }
    else if (ret != msglen)
    {
      fprintf(stderr, "Error: send() failed. Only %d out of %lu bytes were sent.\n"
        , ret, msglen);
      ret = (PROD_ERR_SOCKET_SEND);
      goto return1;
    }

    fprintf(stdout, "Result %llu was successfully sent back to the client.\n",
      result);
  }

return1:
  if (inbuf != NULL)
    free(inbuf);
  if (outbuf != NULL)
    free(outbuf);
  CLOSE1(newsock);
  return(ret);
}
