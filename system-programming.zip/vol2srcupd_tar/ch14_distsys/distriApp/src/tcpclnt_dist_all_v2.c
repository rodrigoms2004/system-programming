/*
 * A connection-oriented client program using Stream socket.
 * Connecting to a server program on any host using a hostname or IP address.
 * Demonstrating design of distributed applications.
 * Support for IPv4 and IPv6 and multiple platforms including 
 * Linux, Windows, Solaris, AIX and HPUX.
 * Usage: tcpclnt_dist_all_v2 [srvport# [server-hostname | server-ipaddress]]
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 1993-2021, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mysocket.h"
#include "mydistsys.h"
#include "myerrors.h"

int send_init_pkt(int sfd);

int main(int argc, char *argv[])
{
  int    ret = 0;
  int    sfd;                     /* socket file descriptor */
  in_port_t  portnum=DEFSRVPORT;  /* port number */
  int    portnum_in = 0;          /* port numbr user provides */
  char   *portnumstr  = DEFSRVPORTSTR; /* port number in string format */
  char   *inbuf = NULL;           /* pointer toinput message buffer */
  char   *outbuf = NULL;          /* pointer to output message buffer */
  size_t msglen;                  /* length of reply message */
  size_t len;
  char   server_name[NAMELEN+1] = SERVER_NAME;
  struct addrinfo hints;          /* address info hints*/
  struct addrinfo *res=NULL;      /* pointer to address info */
  req_pkt_t    *reqmsg = NULL;    /* pointer to client request message */
  int          anumber = 15;      /* the number to be multiplied at server */
  int          *dataptr = NULL;   /* pointer to input data */
  unsigned long long *result_ptr = NULL;   /* pointer to multiplication result */
  req_pkt_t    *reply = NULL;     /* pointer to server reply message */

#if WINDOWS
  WSADATA wsaData;                    /* Winsock data */
  char* GetErrorMsg(int ErrorCode);   /* print error string in Windows */
#endif

  fprintf(stdout, "Connection-oriented client program, version %u ...\n",
    CURRENT_VER);

  /* Get the server's port number from command line. */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Port number %d invalid, set to default value %u\n",
        portnum_in, DEFSRVPORT);
      portnum = DEFSRVPORT;
      portnumstr = DEFSRVPORTSTR;
    }
    else
    {
      portnum = (in_port_t)portnum_in;
      portnumstr = argv[1];
    }
  }

  /* Get the server's host name or IP address from command line. */
  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > NAMELEN)
      len = NAMELEN;
    strncpy(server_name, argv[2], len);
    server_name[len] = '\0';
  }

  /* Get the number to be multiplied from the user*/
  if (argc > 3)
    anumber = atoi(argv[3]);
  
 
#if WINDOWS
  /* Initiate use of the Winsock DLL. Ask for Winsock version 2.2 at least. */
  if ((ret = WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0)
  {
    fprintf(stderr, "Error: WSAStartup() failed with error %d: %s\n",
      ret, GetErrorMsg(ret));
    return (PROD_ERR_WINSOCK_INIT);
  }
#endif

  /* Translate the server's host name or IP address into socket address.
   * Fill in the hints information.
   */
  memset(&hints, 0x00, sizeof(hints));
    /* This works on AIX but not on Solaris, nor on Windows. */
    /* hints.ai_flags    = AI_NUMERICSERV; */
  hints.ai_family   = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_protocol = IPPROTO_TCP;

  /* Get the address information of the server using getaddrinfo().
   * This function returns errors directly or 0 for success. On success,
   * argument res contains a linked list of addrinfo structures.
   */
  ret = getaddrinfo(server_name, portnumstr, &hints, &res);
  if (ret != 0)
  {
    fprintf(stderr, "Error: getaddrinfo() failed, error %d, %s\n", ret,
      gai_strerror(ret));
#if !WINDOWS
    if (ret == EAI_SYSTEM)
      fprintf(stderr,"System error: errno=%d, %s\n", errno, strerror(errno));
#else
    WSACleanup();
#endif
    return(PROD_ERR_GETADDRINFO);
  }

  /* Create a socket. */
  sfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (sfd < 0)
  {
    fprintf(stderr,"Error: socket() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
#if WINDOWS
    WSACleanup();
#endif
    ret = PROD_ERR_SOCKET_CREATE;
    goto return1;
  }

  /* Connect to the server. */
  ret = connect(sfd, res->ai_addr, res->ai_addrlen);
  if (ret == -1)
  {
    fprintf(stderr, "Error: connect() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    ret = PROD_ERR_CONNECT;
    goto return1;
  }

  /* Send initial packet */
  ret = send_init_pkt(sfd);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "Error: send_init_pkt() failed, ret=%d\n", ret);
    goto return1;
  }

  fprintf(stdout, "Send request messages to server(%s) at port %d\n",
    server_name, portnum);

  /* 
   * Send a request message to the server
   */
  /* Allocate output buffer */
  msglen = (sizeof(req_pkt_t) + sizeof(int));
  outbuf = (char *)malloc(msglen);
  if (outbuf == NULL)
  {
    fprintf(stderr, "malloc() failed.\n");
    ret = PROD_ERR_NO_MEMORY;
    goto return1;
  }
    
  /* Fill in request */
  memset(outbuf, 0, msglen);
  reqmsg = (req_pkt_t *)outbuf;
  reqmsg->version = htonl(CURRENT_VER);
  reqmsg->magic = htonl(REQ_MAGIC);
  reqmsg->operation = htonl(REQ_OPCODE1);
  reqmsg->datasz = htonll(sizeof(int));
  dataptr = (int *)(outbuf + sizeof(req_pkt_t));
  *dataptr = htonl(anumber);

  /* Send the request */
  errno = 0;
  ret = send(sfd, outbuf, msglen, 0);
  if (ret < 0)
  {
    fprintf(stderr, "Error: send() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    ret = PROD_ERR_SOCKET_SEND;
    goto return1;
  }
  else if (ret != msglen)
  {
    fprintf(stderr, "Error: send() failed. Only %d out of %lu bytes were sent.\n"
      , ret, msglen);
    ret = PROD_ERR_SOCKET_SEND;
    goto return1;
  }

  /* Receive a reply from the server. */
  /* Allocate input buffer */
  msglen = (sizeof(req_pkt_t) + sizeof(unsigned long long));
  inbuf = (char *)malloc(msglen);
  if (inbuf == NULL)
  {
    fprintf(stderr, "malloc() failed.\n");
    ret = PROD_ERR_NO_MEMORY;
    goto return1;
  }
  memset(inbuf, 0, msglen);
  
  /* Receive the reply from the server */
  errno = 0;
  ret = recv(sfd, inbuf, msglen, 0);
  if (ret < 0)
  {
    fprintf(stderr, "Error: recv() failed, errno=%d, %s\n", ERRNO, ERRNOSTR);
    ret = PROD_ERR_SOCKET_RECV;
    goto return1;
  }
  else if (ret != msglen)
  {
    fprintf(stderr, "Error: recv() failed. Only %d out of %lu bytes were "
      "received.\n", ret, msglen);
    ret = PROD_ERR_SOCKET_RECV;
    goto return1;
  }
  reply = (req_pkt_t *)inbuf;
  fprintf(stdout, "The client received %d bytes of reply from a server"
    " of version %u.\n", ret, ntohl(reply->version));

  if (ntohl(reply->status == SUCCESS))
  {
    result_ptr = (unsigned long long *)(inbuf + sizeof(req_pkt_t));
    fprintf(stdout, "The multiplied result of %d is %llu.\n", anumber,
      ntohll(*result_ptr));
  }
  else
  {
    fprintf(stderr, "Requested operation %u failed, status=%d\n",
      ntohl(reply->operation), ntohl(reply->status));
  }

return1:
  /* Free the memory allocated by getaddrinfo() and others */
  if (res != NULL) freeaddrinfo(res);
  if (inbuf != NULL) free(inbuf);
  if (outbuf != NULL) free(outbuf);
  CLOSE(sfd);
  return(ret);
}

/* Send initial packet */
int send_init_pkt(int sfd)
{
  init_pkt_t  initmsg;
  int         ret;

  memset((void *)&initmsg, 0, sizeof(init_pkt_t));
  initmsg.version = htonl(CURRENT_VER);
  initmsg.magic = htonl(PROTO_MAGIC);
  initmsg.flags = htonl(0);
  
  errno = 0;
  ret = send(sfd, (void *)&initmsg, sizeof(init_pkt_t), 0);
  if (ret < 0)
  {
    fprintf(stderr, "Error: send_init_pkt(), send() failed, errno=%d, %s\n",
      ERRNO, ERRNOSTR);
    return(PROD_ERR_SOCKET_SEND);
  }
  else if (ret != sizeof(init_pkt_t))
  {
    fprintf(stderr, "Error: send_init_pkt(), send() failed. Only %d out of"
      " %lu bytes of data sent.\n", ret, sizeof(init_pkt_t));
    return(PROD_ERR_SOCKET_SEND);
  }

  return(SUCCESS);
}
