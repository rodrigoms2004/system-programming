/*
 * Some library functions for distributed applications.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2010-2019, Mr. Jin-Jwei Chen. All rights reserved.
 */

#include "mydistsys.h"

/* Find the endian type of this local CPU */
int endian()
{
  unsigned int          x = 0x01020304;
  unsigned char         *px = (unsigned char *)&x;

  if (px[0] == 0x01)
    return(BIG_ENDIAN);
  else if (px[0] == 0x04)
    return(LITTLE_ENDIAN);
  else
    return(UNKNOWN_ENDIAN);
}

/* Convert an integer of "unsigned long long" type from local host byte order
 * to network byte order.
 * Industry implementations use big endian as the network byte order.
 */
unsigned long long myhtonll(unsigned long long num64bit)
{
  int  i;
  unsigned long long  result;
  unsigned char       n = sizeof(unsigned long long);
  unsigned char       *pin = (unsigned char *)&num64bit;
  unsigned char       *pout = (unsigned char *)&result;

  if (endian() == LITTLE_ENDIAN)
  {
    for (i = 0; i < n; i++)
      pout[n-1-i] = pin[i]; 
    return(result);
  }
  else
    return(num64bit);
}

/* Convert an integer of "unsigned long long" type from network byte order
 * to local host byte order.
 * Industry implementations use big endian as the network byte order.
 */
unsigned long long myntohll(unsigned long long num64bit)
{
  int  i;
  unsigned long long  result;
  unsigned char       n = sizeof(unsigned long long);
  unsigned char       *pin = (unsigned char *)&num64bit;
  unsigned char       *pout = (unsigned char *)&result;

  if (endian() == LITTLE_ENDIAN)
  {
    for (i = 0; i < n; i++)
      pout[n-1-i] = pin[i]; 
    return(result);
  }
  else
    return(num64bit);
}

/*
 * Byte swap a short integer.
 */
unsigned short myByteSwap2(unsigned short num16bit)
{
  int  i;
  unsigned short      result;
  unsigned char       n = sizeof(unsigned short);
  unsigned char       *pin = (unsigned char *)&num16bit;
  unsigned char       *pout = (unsigned char *)&result;

  for (i = 0; i < n; i++)
    pout[n-1-i] = pin[i];
  return(result);
}

/*
 * Byte swap an integer.
 */
unsigned int myByteSwap4(unsigned int num32bit)
{
  int  i;
  unsigned int        result;
  unsigned char       n = sizeof(unsigned int);
  unsigned char       *pin = (unsigned char *)&num32bit;
  unsigned char       *pout = (unsigned char *)&result;

  for (i = 0; i < n; i++)
    pout[n-1-i] = pin[i];
  return(result);
}

/*
 * Byte swap a "long long" integer.
 */
unsigned long long myByteSwap8(unsigned long long num64bit)
{
  int  i;
  unsigned long long  result;
  unsigned char       n = sizeof(unsigned long long);
  unsigned char       *pin = (unsigned char *)&num64bit;
  unsigned char       *pout = (unsigned char *)&result;

  for (i = 0; i < n; i++)
    pout[n-1-i] = pin[i];
  return(result);
}

