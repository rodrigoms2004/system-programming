/*
 * Writing or reading portable data records.
 * Writing portable binary output file that can be correctly read on any
 * machines with different endian or reading it.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2008-2019, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#ifdef WINDOWS
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include <stdio.h>
typedef int  ssize_t;
typedef unsigned int  mode_t;
#endif

#include "mystdhdr.h"
#include "myerrors.h"
#include "mydistsys.h"

#define  READF      1          /* read file */
#define  WRITEF     2          /* write file */
#define  READ       "read"
#define  Write      "write"
#define  FNAME_LEN  32         /* Max. length of file name */
#define  NRECORDS   2          /* number of records */
#define  DEF_FILE_NAME  "portable_recs"  /* default file name */

/* Write actual data records */
int write_data_rec(int fd)
{
  data_rec_t  datarec;         /* data record */
  ssize_t     recsz;           /* record size in byes */
  ssize_t     bytes;           /* number of bytes written */

  /* Write first data record */
  strcpy(datarec.name, "Jennifer Johnson");
  datarec.birthyear = 1980;
  datarec.salary = 224000;
  datarec.bonus = 1234500;
  recsz = sizeof(datarec);
  bytes = write(fd, (void *)&datarec, recsz);
  if (bytes == -1)
  {
    fprintf(stderr, "Error: write_data_rec() failed to write data record "
      "to file, errno=%d\n", errno);
    close(fd);
    return(PROD_ERR_WRITE);
  }

  if (bytes != recsz)
  {
    fprintf(stderr, "Error: write_data_rec() failed to write data record "
      "to file, only %ld of %ld bytes written.\n", bytes, recsz);
    close(fd);
    return(PROD_ERR_WRITE);
  }

  /* Write second data record */
  strcpy(datarec.name, "Allan Smith");
  datarec.birthyear = 1970;
  datarec.salary = 448000;
  datarec.bonus = 2469000;
  recsz = sizeof(datarec);
  bytes = write(fd, (void *)&datarec, recsz);
  if (bytes == -1)
  {
    fprintf(stderr, "Error: write_data_rec() failed to write data record "
      "to file, errno=%d\n", errno);
    close(fd);
    return(PROD_ERR_WRITE);
  }

  if (bytes != recsz)
  {
    fprintf(stderr, "Error: write_data_rec() failed to write data record "
      "to file, only %ld of %ld bytes written.\n", bytes, recsz);
    close(fd);
    return(PROD_ERR_WRITE);
  }
  return(SUCCESS);
}

/* Write data records to a file */
int write_rec_file(char *filename)
{
  int      ret;               /* return code */
  int      fd;                /* file descriptor */
  ssize_t  recsz;             /* record size in byes */
  ssize_t  bytes;             /* number of bytes written */
  int      myendian;          /* this CPU's endian type */
  mode_t   mode = 0644;       /* file permissions */
  portable_data_hdr_t  hdr;   /* header of data file */

  if (filename == (char *)NULL)
    return(EINVAL);

  /* Open the output file */
  fd = open(filename, O_CREAT|O_WRONLY|O_TRUNC, mode);
  if (fd == (-1))
  {
    fprintf(stderr, "Error: write_rec_file() failed to open file %s, "
      "errno=%d\n", filename, errno);
    return(PROD_ERR_OPEN);
  }

  /* Write the file header record */
  hdr.endian = endian();
  hdr.version = 1;
  hdr.magic = DATA_MAGIC;
  hdr.nrecs = NRECORDS;
  recsz = sizeof(hdr);
  bytes = write(fd, (void *)&hdr, recsz);
  if (bytes == -1)
  {
    fprintf(stderr, "Error: write_rec_file() failed to write file header "
      "to file %s, errno=%d\n", filename, errno);
    close(fd);
    return(PROD_ERR_WRITE);
  }

  if (bytes != recsz)
  {
    fprintf(stderr, "Error: write_rec_file() failed to write file header "
      "to file %s, only %ld of %ld bytes written.\n", filename, bytes, recsz);
    close(fd);
    return(PROD_ERR_WRITE);
  }

  /* Write actual data records */
  ret = write_data_rec(fd);
  if (ret == SUCCESS)
    fprintf(stdout, "The data file was successfully created.\n");
  else
    fprintf(stderr, "Creating the data file was unsuccessful.\n");

  close(fd);
  return(ret);
}

/* Print the contents of the file header */
void print_hdr(portable_data_hdr_t *hdr)
{
  if (hdr == (portable_data_hdr_t *)NULL)
    return;
  fprintf(stdout,"\nContents of the file header:\n");
  fprintf(stdout, "  hdr->endian = %d\n", hdr->endian);
  if (endian() == hdr->endian)
  {
    fprintf(stdout, "  hdr->version = %d\n", hdr->version);
    fprintf(stdout, "  hdr->magic = %d\n", hdr->magic);
    fprintf(stdout, "  hdr->nrecs = %llu\n", hdr->nrecs);
  }
  else
  {
    fprintf(stdout, "  hdr->version = %d\n", myByteSwap4(hdr->version));
    fprintf(stdout, "  hdr->magic = %d\n", myByteSwap4(hdr->magic));
    fprintf(stdout, "  hdr->nrecs = %llu\n", myByteSwap8(hdr->nrecs));
  }
  return;
}

/* Print the contents of a data record */
void print_data_rec(data_rec_t *datarec, portable_data_hdr_t *hdr)
{
  if (datarec == (data_rec_t *)NULL || hdr == (portable_data_hdr_t *)NULL)
    return;

  fprintf(stdout, "\n  name = %s\n", datarec->name);

  /* For the binary integer data items, if the endian type is the same,
   * print what is read.  Otherwise, byte swap the value before printing it.
   */
  if (endian() == hdr->endian)
  {
    fprintf(stdout, "  birthyear = %u\n", datarec->birthyear);
    fprintf(stdout, "  salary = %u\n", datarec->salary);
    fprintf(stdout, "  bonus = %u\n", datarec->bonus);
  }
  else
  {
    fprintf(stdout, "  birthyear = %u\n", myByteSwap4(datarec->birthyear));
    fprintf(stdout, "  salary = %u\n", myByteSwap4(datarec->salary));
    fprintf(stdout, "  bonus = %u\n", myByteSwap4(datarec->bonus));
  }
  return;
}

/* Read records from a binary data file */
int read_rec_file(char *filename)
{
  int      ret;               /* return code */
  int      fd;                /* file descriptor */
  ssize_t  recsz;             /* record size in byes */
  ssize_t  bytes;             /* number of bytes read */
  int      myendian;          /* this CPU's endian type */
  portable_data_hdr_t  hdr;   /* header of data file */
  int      i;                 /* loop index */
  data_rec_t  datarec;        /* data record */
  unsigned int hdrmagic;      /* magic number in the file header */

  if (filename == (char *)NULL)
    return(EINVAL);

  /* Open the data file */
  fd = open(filename, O_RDONLY);
  if (fd == (-1))
  {
    fprintf(stderr, "Error: read_rec_file() failed to open file %s, "
      "errno=%d\n", filename, errno);
    return(PROD_ERR_OPEN);
  }

  /* Read the file header record */
  recsz = sizeof(hdr);
  bytes = read(fd, (void *)&hdr, recsz);
  if (bytes == -1)
  {
    fprintf(stderr, "Error: read_rec_file() failed to read file header "
      "from file %s, errno=%d\n", filename, errno);
    close(fd);
    return(PROD_ERR_READ);
  }

  if (bytes != recsz)
  {
    fprintf(stderr, "Error: read_rec_file() failed to read file header "
      "from file %s, only %ld of %ld bytes read.\n", filename, bytes, recsz);
    close(fd);
    return(PROD_ERR_READ);
  }

  /* Get the magic number from the file header and do a sanity check */
  if (endian() == hdr.endian)
    hdrmagic = hdr.magic;
  else
    hdrmagic = myByteSwap4(hdr.magic);
  if (hdrmagic != DATA_MAGIC)
  {
    fprintf(stderr, "Error: read_rec_file() found magic number mismatch.\n");
    close(fd);
    return(PROD_ERR_WRONGMAGIC);
  }

  print_hdr(&hdr);

  /* Read and print actual data records */
  fprintf(stdout, "\nContents of the data records follow:\n");
  for (i = 0; i < NRECORDS; i++)
  {
    recsz = sizeof(datarec);
    bytes = read(fd, (void *)&datarec, recsz);
    if (bytes == -1)
    {
      fprintf(stderr, "Error: read_rec_file() failed to read data record "
        "from file %s, errno=%d\n", filename, errno);
      close(fd);
      return(PROD_ERR_READ);
    }
    if (bytes != recsz)
    {
      fprintf(stderr, "Error: read_rec_file() failed to read data record "
        "from file %s, only %ld of %ld bytes read.\n", filename, bytes, recsz);
      close(fd);
      return(PROD_ERR_READ);
    }

    print_data_rec(&datarec, &hdr);
  }

  close(fd);
  return(SUCCESS);
}

int main(int argc, char *argv[])
{
  int     action = READF;
  char    action_str[8] = READ;
  char    filename[FNAME_LEN+1] = DEF_FILE_NAME;
  int     len = 0;

  if (argc > 1)
  {
    if (argv[1][0] == 'r' || argv[1][0] == 'R')
    {
      action = READF;
      strcpy(action_str, "read");
    }
    else if (argv[1][0] == 'w' || argv[1][0] == 'W')
    {
      action = WRITEF;
      strcpy(action_str, "write");
    }
    else
    {
      fprintf(stderr, "Usage: %s [r|w|R|W] filename\n", argv[0]);
      return(PROD_ERR_BAD_SYNTAX);
    }
  }

  if (argc > 2)
  {
    len = strlen(argv[2]);
    if (len > FNAME_LEN)
    {
      fprintf(stderr, "Error, file name %s is too long.\n", argv[2]);
      return(PROD_ERR_NAME_TOOLONG);
    }
    else
    {
      strncpy(filename, argv[2], len);
      filename[len] = '\0';
    }
  }
  
  fprintf(stdout, "To %s portable binary file %s ...\n", action_str, filename);

  if (action == READF)
    return(read_rec_file(filename));
  else if (action == WRITEF)
    return(write_rec_file(filename));

  return(SUCCESS);
}

