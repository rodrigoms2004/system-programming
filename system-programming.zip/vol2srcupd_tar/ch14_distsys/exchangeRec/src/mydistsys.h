/*
 * Include file for distributed system applications
 * Supported operating systems: Linux, Unix (AIX, Solaris, HP-UX),
 * Apple Darwin and Windows.
 * Copyright (c) 1996, 2002, 2014, 2019-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

/*
 * Defines for Endianness.
 */
#undef  LITTLE_ENDIAN
#undef  BIG_ENDIAN
#define LITTLE_ENDIAN     1
#define BIG_ENDIAN        2
#define UNKNOWN_ENDIAN    3

/*
 * Endian utility functions.
 */
int endian();
unsigned long long myhtonll(unsigned long long num64bit);
unsigned long long myntohll(unsigned long long num64bit);
unsigned short myByteSwap2(unsigned short num16bit);
unsigned int myByteSwap4(unsigned int num32bit);
unsigned long long myByteSwap8(unsigned long long num64bit);

/* Alternative names for the bytes swap functions */
#define swap2bytes myByteSwap2
#define swap4bytes myByteSwap4
#define swap8bytes myByteSwap8

/*
 * Use our own version on platforms not supporting htonll()/ntohll().
 * Remove the O.S. from this list once it has native support.
 */
#if (WINDOWS || LINUX || HPUX)
#define htonll  myhtonll
#define ntohll  myntohll
#endif

/*
 * Application protocol version numbers
 */
#define PROTO_VERSION1  1
#define CURRENT_PROTO_VER PROTO_VERSION1  /* always keep this line last */

/*
 * Client version numbers
 */
#define CLNT_VERSION1  1
#define CURRENT_CLNT_VER  CLNT_VERSION1  /* always keep this line last */

/*
 * Server version numbers
 */
#define SRV_VERSION1  1
#define CURRENT_SRV_VER  SRV_VERSION1  /* always keep this line last */

/* Magic number */
#define PROTO_MAGIC  3923850741
#define REQ_MAGIC    3749500826
#define REPLY_MAGIC  2814594375
#define DATA_MAGIC   1943724308

/* Client request operations */
#define REQ_OPCODE1  1     /* do multiplication */

/*
 * Initial connection packet.
 */
#define AUTH_ID_LEN    32
#define INIT_PKT_LEN  256
typedef struct {
    unsigned int      version;    /* app. protocol version number */
    unsigned int      magic;      /* app. protocol magic number */
    unsigned int      flags;
    char              auth[AUTH_ID_LEN];    /* auth data */
    char              reserved[INIT_PKT_LEN-AUTH_ID_LEN];
} init_pkt_t;

/*
 * Request/Reply header packet.
 */
typedef struct {
    unsigned int        version;    /* App. data version number */
    unsigned int        magic;      /* app. data packet magic number */
    int                 operation;  /* operation to be performed */
    int                 status;     /* status of the operation */
    unsigned long long  datasz;     /* size of data */
    char                reserved[64];
} req_pkt_t;

/*
 * Portable data file header.
 */
typedef struct {
    char                endian;      /* endian format of the data */
    char                padding[3];  /* pad it for alignment */
    unsigned int        version;     /* version number */
    unsigned int        magic;       /* magic number of data record header */
    unsigned int        padding2;    /* pad it to 8-byte boundary */
    unsigned long long  nrecs;       /* number of records */
    char                reserved[24];
} portable_data_hdr_t;

/*
 * Data record.
 */
#define  NAME_LEN  32
typedef struct {
    char                name[NAME_LEN];
    unsigned int        birthyear;
    unsigned int        salary;
    unsigned int        bonus;
} data_rec_t;
