/*
 * Demonstrating secrecy and nonrepudiation in network communications.
 * This is a TCP server program which gets a request message from a client
 * and sends back a reply. Both request messages and replies are all encrypted.
 * DSA digital signature is also used to ensure message integrity and
 * sender nonrepudiation.
 * Copyright (c) 2015, 2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset(), strlen(), memcmp() */
#include <stdlib.h>        /* atoi() */
#include <openssl/evp.h>
#include <openssl/dsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include "myopenssl.h"
#include "netlib.h"

int main(int argc, char *argv[])
{
  int    sfd;                       /* file descriptor of the listener socket */
  struct sockaddr_in    srvaddr;    /* IPv4 socket address structure */
  struct sockaddr_in6   srvaddr6;   /* IPv6 socket address structure */
  in_port_t  portnum = SRVPORT;     /* port number this server listens on */
  int        portnum_in = 0;        /* port number specified by user */
  struct sockaddr_in6   clntaddr6;  /* client socket address */
  socklen_t             clntaddr6sz = sizeof(clntaddr6);
  int       newsock;                /* file descriptor of client data socket */
  int       ipv6 = 0;
  int       ret;
  char      reqmsg[MAXREQSZ];   /* request message buffer */
  char      reply[MAXRPLYSZ];   /* buffer for server reply message */
  size_t    reqmsgsz;           /* size of client request message */
  size_t    replysz;            /* size of server reply message */
  size_t    insize;             /* size of encrypted request message */
  size_t    outsz;              /* size of encrypted reply message */
  int       done;               /* done with current client */
  int       msgcnt;             /* count of messages from a client */
  unsigned char  inbuf[MAXREQSZ+DSASIGLEN+LENGTHSZ];    /* input buffer */
  unsigned char  outbuf[MAXRPLYSZ];  /* output buffer */

  /* variables for encryption/decryption */
  struct cipher  cipher;             /* cipher to be used */
  unsigned char  newiv[EVP_MAX_IV_LENGTH];  /* new IV */

  /* variables for message digest */
  const EVP_MD   *hashfunc;                /* hash function */
  unsigned char  digest[EVP_MAX_MD_SIZE];  /* digest of the request message */
  unsigned int   dgstlen = 0;              /* length of hash */

  /* variables for DSA */
  FILE           *fp = NULL;             /* file pointer */
  DSA            *dsa = NULL;            /* pointer to DSA structure */
  DSA            *dsaret = NULL;         /* DSA pointer returned */
  unsigned long  error = 0L;             /* Openssl error code */
  unsigned int   siglen = 0;             /* length of signature */
  unsigned int   *siglenp = NULL;        /* pointer to signature length field */

  /* Get the server port number from user, if any */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Error: port number %s invalid\n", argv[1]);
      fprintf(stderr, "Usage: %s [server_port] [1 (use IPv6)]\n", argv[0]);
      return(-1);
    }
    else
      portnum = portnum_in;
  }

  /* Get the IPv6 switch from user, if any */
  if (argc > 2)
  {
    if (argv[2][0] == '1')
      ipv6 = 1;
    else if (argv[2][0] != '0')
    {
      fprintf(stderr, "Usage: %s [server_port] [1 (use IPv6)]\n", argv[0]);
      return(-2);
    }
  }

  fprintf(stdout, "TCP server listening at portnum=%u ipv6=%u\n", portnum, ipv6);

  /* Get the structure describing the message digest algorithm by name */
  hashfunc = EVP_get_digestbyname(DSAHASH_NAME);
  if(hashfunc == NULL)
  {
    fprintf(stderr, "Error: unknown hash function %s\n", DSAHASH_NAME);
    return(-3);
  }

  /* Create the server listener socket */
  if (ipv6)
    ret = new_bound_srv_endpt(&sfd, (struct sockaddr *)&srvaddr6, AF_INET6,
      portnum);
  else
    ret = new_bound_srv_endpt(&sfd, (struct sockaddr *)&srvaddr, AF_INET,
      portnum);

  if (ret != 0)
  {
    fprintf(stderr, "Error: new_bound_srv_endpt() failed, ret=%d\n", ret);
    return(-4);
  }

  /* Listen for incoming requests and send replies */
  do
  {
    /* Listen for next client's connect request */
    newsock = accept(sfd, (struct sockaddr *)&clntaddr6, &clntaddr6sz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d\n", errno);
      continue;
    }

    fprintf(stdout, "\nServer got a client connection\n");

    /* Initialize the cipher */
    strcpy(cipher.name, DEFAULT_CIPHER);
    strcpy((char *)cipher.key, DEFAULT_KEY);
    strcpy((char *)cipher.iv, DEFAULT_IV);

    /* Service this current client until done */
    done = 0;
    msgcnt = 1;
    do
    { 
      /* Read the request message */
      insize = recv(newsock, inbuf, MAXREQSZ, 0);
      if (insize <= 0)
      {
        fprintf(stderr, "Error: recv() failed, insize=%lu\n", insize);
        break;
      }

      /* Decrypt the requested message */
      reqmsgsz = 0;
      ret = mydecrypt2(inbuf+DSASIGLEN+LENGTHSZ, insize-DSASIGLEN-LENGTHSZ,
          reqmsg, &reqmsgsz, &cipher);
      if (ret != 0)
      {
        fprintf(stderr, "Error: mydecrypt2() failed, ret=%d\n", ret);
        break;
      }

      reqmsg[reqmsgsz]='\0';
      fprintf(stdout, "Server received: %s\n", reqmsg);

      /* Compute message digest from the decrypted message */
      dgstlen = 0;
      ret = message_digest2(hashfunc, reqmsg, reqmsgsz, digest, &dgstlen);
      if (ret != SUCCESS)
      {
        fprintf(stderr, "Error: message_digest2() failed, ret=%d\n", ret);
        break;
      }

      /* Read the sender's DSA public key from the file */
      fp = fopen(DSAPUBKEYFILE, "r");
      if (fp == NULL)
      {
        fprintf(stderr, "Error: fopen()() failed, errno=%d\n", errno);
        break;
      }

      dsaret=PEM_read_DSA_PUBKEY(fp, &dsa, (pem_password_cb *)NULL, (void *)NULL);
      if (dsaret == NULL)
      {
        error = ERR_get_error();
        fprintf(stderr, "Error: PEM_read_DSA_PUBKEY() failed, error=%lu\n", error);
        fclose(fp);
        break;
      }
      fclose(fp);

      /* Get the length of the actual signature. Do byte order conversion. */
      siglenp = (unsigned int *)inbuf;
      siglen = ntohl(*siglenp);

      /* Verify the DSA signature using the DSA public key read from file */
      ret = verify_DSA_signature(digest, dgstlen, inbuf+LENGTHSZ, siglen, dsa);
      if (ret != SUCCESS)
      {
        fprintf(stderr, "Error: verify_DSA_signature() failed, ret=%d\n", ret);
        break;
      }
      /* Note: You cannot free the dsa here! */

      fprintf(stdout, "DSA digital signature of the sender was successfully verified.\n\n");

      /* Set reply message */
      if ( !strcmp(reqmsg, BYE_MSG) )
      {
        done = 1;
        strcpy(reply, reqmsg);
      }
      else
        sprintf(reply, SRVREPLY2, msgcnt++);

      replysz = strlen(reply);

      /* Encrypt the reply message */
      outsz = 0;
      ret = myencrypt2(reply, replysz, outbuf, &outsz, &cipher);
      if (ret != 0)
      {
        fprintf(stderr, "Error: myencrypt2() failed, ret=%d\n", ret);
        break;
      }

      /* Send back an encrypted reply */
      ret = send(newsock, outbuf, outsz, 0);
      if (ret < 0)
        fprintf(stderr, "Error: send() failed to send a reply, errno=%d\n",
          errno);

      /* Change the IV for encryption/decryption */
      ret = increment_iv(cipher.iv, newiv);
      if (ret == 0)
        strcpy((char *)cipher.iv, (char *)newiv);
      else
      {
        fprintf(stderr, "Error: increment_iv() failed, ret=%d\n", ret);
        break;
      }

    } while (!done);

    /* We can close the socket now. */
    close(newsock);
    /* Note: We cannot free dsa here either. */

  } while (1);
}
