/*
 * This program encrypts the contents of a file and writes the encrypted
 * output to another file. It then reads the output file of the encryption,
 * decrypts it and writes the decrypted plain text to a third file.
 * If the third file is identical to the first, then the encryption and
 * decryption have succeeded.
 * The algorithm used here is des-ede3-cbc.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2019-2022 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>     /* open() */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>        /* read(), write() */
#include <string.h>        /* memset(), strlen() */
#include <strings.h>       /* bzero() */
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/blowfish.h>

/* Note: KEYLEN and IVLEN vary from one algorithm to another */
#define IVLEN    8       /* length of IV (number of bytes) */
#define KEYLEN  16       /* key length (number of bytes) */

/* sizes of chunks this program works on */
#define INSIZE 1024
#define OUTSIZE (INSIZE+IVLEN)

/* These are shared by the encryption and decryption. */
unsigned char iv[IVLEN+1] = "00000001";
unsigned char key[KEYLEN+1] = "Axy3pzLk%8q#0)yH";

#define MYALGRM  "des-ede3-cbc"

/* clean up before return in case of error */
#define ERROR_RTN(n) \
  if (ctx != NULL) EVP_CIPHER_CTX_free(ctx); \
  if (infd) close(infd); \
  if (outfd) close(outfd); \
  return(n);

/*
 * Encrypt the contents of the input file specified by 'infname' and
 * write the encrypted output (i.e. the cipher text) to the output file
 * specified by the 'outfname' parameter.
 */
int myencryptf(char *infname, char *outfname)
{
  EVP_CIPHER_CTX *ctx = NULL;        /* cipher context */
  ssize_t  inlen, outbytes;          /* bytes read or written */
  int      outlen;                   /* length of output cipher text */
  int      infd=0, outfd=0;          /* file descriptors */
  int      ret;
  unsigned char  inbuf[INSIZE];
  unsigned char  outbuf[OUTSIZE];
  const EVP_CIPHER *cipher = NULL;

  if (infname == NULL || outfname == NULL || infname == outfname)
    return(EINVAL);

  /* Open the input file */
  infd = open(infname, O_RDONLY);
  if (infd == -1)
  {
    fprintf(stderr, "Error: myencryptf() failed to open input file %s, errno=%d\n",
      infname, errno);
    return(-1);
  }

  /* Open the output file */
  outfd = open(outfname, O_WRONLY|O_CREAT|O_TRUNC, 0640);
  if (outfd == -1)
  {
    fprintf(stderr, "Error: myencryptf() failed to open output file %s, errno=%d\n"
      , outfname, errno);
    close(infd);
    return(-2);
  }

  /* Create a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: myencryptf(), EVP_CIPHER_CTX_new() failed\n");
      ERROR_RTN(-3);
  }

  /* Get the algorithm */
  cipher = EVP_get_cipherbyname(MYALGRM);
  if (cipher == NULL)
  {
    fprintf(stderr, "Error: myencryptf(), EVP_get_cipherbyname() failed\n");
      ERROR_RTN(-4);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_EncryptInit_ex(ctx, cipher, NULL, key, iv);
  if (!ret)
  {
    fprintf(stderr, "Error: myencryptf(), EVP_EncryptInit_ex() failed\n");
      ERROR_RTN(-5);
  }

  /* Read contents of the entire file and encrypt it chunk by chunk */
  do
  {
    bzero (inbuf, INSIZE);
    /* Read next chunk from the input file */
    inlen = read(infd, inbuf, INSIZE);
    if (inlen <= 0)
    {
      if (inlen < 0)
      {
        fprintf(stderr, "Error: myencryptf() failed to read input file %s, "
          "errno=%d\n", infname, errno);
        ERROR_RTN(-6);
      }
      else
        break;
    }

    /* Encrypt this current chunk */
    bzero (outbuf, OUTSIZE);
    outlen = 0;
    if (EVP_EncryptUpdate(ctx, outbuf, &outlen, inbuf, inlen) != 1)
    {
      fprintf(stderr, "Error: myencryptf(), EVP_EncryptUpdate() failed\n");
        ERROR_RTN(-7);
    }

    /* Write encrypted chunk to the output file */
    if (outlen > 0)
    {
      outbytes = write(outfd, outbuf, outlen);
      if (outbytes < outlen)
      {
        if (outbytes < 0)
          fprintf(stderr, "Error: myencryptf() failed to write output file %s, "
            "errno=%d\n", outfname, errno);
        else
          fprintf(stderr, "Error: myencryptf() failed to write output file %s, "
            "only %ld out of %d were written\n", outfname, outbytes, outlen);
        ERROR_RTN(-8);
      }
    }

  } while (1);

  /* Wrap up the encryption by handling the last remaining part */
  bzero (outbuf, OUTSIZE);
  outlen = 0;
  if (EVP_EncryptFinal_ex(ctx, outbuf, &outlen) != 1)
  {
    fprintf(stderr, "Error: myencryptf(), EVP_EncryptFinal_ex() failed\n");
    ERROR_RTN(-9);
  }

  /* Write the last encrypted chunk to the output file */
  if (outlen > 0)
  {
    outbytes = write(outfd, outbuf, outlen);
    if (outbytes < outlen)
    {
      if (outbytes < 0)
        fprintf(stderr, "Error: myencryptf() failed to write output file %s, "
          "errno=%d\n", outfname, errno);
      else
        fprintf(stderr, "Error: myencryptf() failed to write output file %s, "
          "only %ld out of %d were written\n", outfname, outbytes, outlen);
      ERROR_RTN(-10);
    }
  }

  EVP_CIPHER_CTX_free(ctx);

  return(0);
}

/*
 * Decrypt the contents of the input file specified by 'infname' and
 * write the decrypted output (i.e. the plain text) to the output file
 * specified by 'outfname' parameter.
 */
int decrypt(char *infname, char *outfname)
{
  EVP_CIPHER_CTX *ctx = NULL;        /* cipher context */
  ssize_t  inlen, outbytes;          /* bytes read or written */
  int      outlen;                   /* length of output cipher text */
  int      infd=0, outfd=0;          /* file descriptors */
  int      ret;
  unsigned char  inbuf[INSIZE];
  unsigned char  outbuf[OUTSIZE];
  EVP_CIPHER *cipher = NULL;

  if (infname == NULL || outfname == NULL || infname == outfname)
    return(EINVAL);

  /* Open the input file */
  infd = open(infname, O_RDONLY);
  if (infd == -1)
  {
    fprintf(stderr, "Error: decrypt() failed to open input file %s, errno=%d\n",
      infname, errno);
    return(-1);
  }

  /* Open the output file */
  outfd = open(outfname, O_WRONLY|O_CREAT|O_TRUNC, 0640);
  if (outfd == -1)
  {
    fprintf(stderr, "Error: decrypt() failed to open output file %s, errno=%d\n"
      , outfname, errno);
    close(infd);
    return(-2);
  }

  /* Create a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: decrypt(), EVP_CIPHER_CTX_new() failed\n");
      ERROR_RTN(-3);
  }

  /* Fetch the algorithm */
  cipher = EVP_CIPHER_fetch(NULL, MYALGRM, NULL);
  if (cipher == NULL)
  {
    fprintf(stderr, "Error: decrypt(), EVP_CIPHER_fetch() failed\n");
      ERROR_RTN(-4);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_DecryptInit_ex(ctx, cipher, NULL, key, iv);
  if (!ret)
  {
    fprintf(stderr, "Error: decrypt(), EVP_DecryptInit_ex() failed\n");
      ERROR_RTN(-5);
  }

  /* Read contents of the entire file and decrypt it chunk by chunk */
  do
  {
    bzero (inbuf, INSIZE);
    /* Read next chunk from the input file */
    inlen = read(infd, inbuf, INSIZE);
    if (inlen <= 0)
    {
      if (inlen < 0)
      {
        fprintf(stderr, "Error: decrypt() failed to read input file %s, "
          "errno=%d\n", infname, errno);
        ERROR_RTN(-6);
      }
      else
        break;
    }

    /* Decrypt this current chunk */
    bzero (outbuf, OUTSIZE);
    outlen = 0;
    if (EVP_DecryptUpdate(ctx, outbuf, &outlen, inbuf, inlen) != 1)
    {
      fprintf(stderr, "Error: decrypt(), EVP_DecryptUpdate() failed\n");
        ERROR_RTN(-7);
    }

    /* Write decrypted chunk to the output file */
    if (outlen > 0)
    {
      outbytes = write(outfd, outbuf, outlen);
      if (outbytes < outlen)
      {
        if (outbytes < 0)
          fprintf(stderr, "Error: decrypt() failed to write output file %s, "
            "errno=%d\n", outfname, errno);
        else
          fprintf(stderr, "Error: decrypt() failed to write output file %s, "
            "only %ld out of %d were written\n", outfname, outbytes, outlen);
        ERROR_RTN(-8);
      }
    }

  } while (1);

  /* Wrap up the decryption by handling the last remaining part */
  bzero (outbuf, OUTSIZE);
  outlen = 0;
  if (EVP_DecryptFinal_ex(ctx, outbuf, &outlen) != 1)
  {
    fprintf(stderr, "Error: decrypt(), EVP_DecryptFinal_ex() failed\n");
    ERROR_RTN(-8);
  }

  /* Write the last decrypted chunk to the output file */
  if (outlen > 0)
  {
    outbytes = write(outfd, outbuf, outlen);
    if (outbytes < outlen)
    {
      if (outbytes < 0)
        fprintf(stderr, "Error: decrypt() failed to write output file %s, "
          "errno=%d\n", outfname, errno);
      else
        fprintf(stderr, "Error: decrypt() failed to write output file %s, "
          "only %ld out of %d were written\n", outfname, outbytes, outlen);
      ERROR_RTN(-9);
    }
  }

  EVP_CIPHER_CTX_free(ctx);

  return(0);
}


/* A simple encryption and decryption program */
int main(int argc, char *argv[])
{
  int      outlen = 0;           /* length of output cipher text */
  int      ret;

  char    *infname = "encindata";
  char    *outfname1 = "encoutdata1";
  char    *outfname2 = "encoutdata2";

  /* Get the names of input and output files from user, if any */
  if (argc > 1 && argc < 4)
  {
    fprintf(stderr, "Usage: %s [infile outfile1 outfile2]\n", argv[0]);
    return(-1);
  }
  if (argc > 1) infname = argv[1];
  if (argc > 2) outfname1 = argv[2];
  if (argc > 3) outfname2 = argv[3];

  /* Encrypt the message */
  ret = myencryptf(infname, outfname1);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), myencryptf() failed, ret=%d\n", ret);
    return(ret);
  }

  /* Decrypt the message */
  ret = decrypt(outfname1, outfname2);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), decrypt() failed, ret=%d\n", ret);
    return(ret);
  }

  return(0);
}
