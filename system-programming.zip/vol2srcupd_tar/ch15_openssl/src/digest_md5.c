/*
 * This program computes the digest of a message using MD5 algorithm.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <openssl/md5.h>

/*
 * Compute the digest of the input message stored in 'buf' using MD5.
 */
int get_digest_md5(char *buf, unsigned int len, unsigned char *digest)
{
  MD5_CTX    ctx;
  int           ret;

  if (buf == NULL || digest == NULL)
    return(EINVAL);

  ret = MD5_Init(&ctx);
  if (ret == 0)
  {
    fprintf(stderr, "Error: MD5_Init() failed, ret=%d\n", ret);
    return(ret);
  }

  ret = MD5_Update(&ctx, (u_int8_t *)buf, len);
  if (ret == 0)
  {
    fprintf(stderr, "Error: MD5_Update() failed, ret=%d\n", ret);
    return(ret);
  }

  ret = MD5_Final(digest, &ctx);
  if (ret == 0)
  {
    fprintf(stderr, "Error: MD5_Final() failed, ret=%d\n", ret);
    return(ret);
  }

  return(0);
}

/* Print the digest stored in buf. Note that data is unsigned. */
void print_digest(unsigned char *buf, unsigned int buflen)
{
  int   i;

  if (buf == NULL) return;
  fprintf(stdout, "digest=0x");
  for (i = 0; i < buflen; i++)
    fprintf(stdout, "%02x", buf[i]);
  printf("\n");
}

#define  BUFSZ  256  /* for our test, maximum message is 255 characters */
/*
 * Compute the digest of an input message using MD5.
 */
int main(int argc, char *argv[])
{
  unsigned char  digest[MD5_DIGEST_LENGTH];
  int       ret;
  char      msg[BUFSZ];

  /* Get the message from the user */
  fprintf(stdout, "Enter a message: ");
  ret = fscanf(stdin, "%s", msg);
  if (ret == EOF || ret <= 0)
  {
    fprintf(stderr, "fscanf() failed to read input message, ret=%d\n", ret);
    return(ret);
  }

  if (strlen(msg) >= BUFSZ)
    msg[BUFSZ-1] = '\0';

  /* Compute the digest of the message */
  ret = get_digest_md5(msg, strlen(msg), digest);
  if (ret != 0)
    fprintf(stderr, "Error: get_digest_md5() failed, ret=%d\n", ret);
  else
    print_digest(digest, MD5_DIGEST_LENGTH);

  return(ret);
}
