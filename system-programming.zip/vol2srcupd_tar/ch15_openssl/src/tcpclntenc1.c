/*
 * Demonstrating secrecy in network communications (myencrypt1 and mydecrypt1).
 * This is a simple TCP client program which exchanges messages with
 * a TCP server with the messages encrypted.
 * Copyright (c) 2015, 2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset(), strlen() */
#include <stdlib.h>        /* atoi(), malloc() */
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/blowfish.h>
#include "myopenssl.h"
#include "netlib.h"

#define FREEALL    \
    close(sfd);    \
    free(reqmsg);

int main(int argc, char *argv[])
{
  int            ret;                   /* return value */
  int            sfd=0;                 /* socket file descriptor */
  unsigned char  outbuf[MAXREQSZ];      /* output buffer */
  unsigned char  inbuf[MAXRPLYSZ];      /* input buffer */
  char           replymsg[MAXRPLYSZ];   /* reply message from server */
  size_t         reqbufsz = MAXREQSZ;   /* size of client request buffer */
  char           *reqmsg=NULL;          /* pointer to request message buffer */
  size_t         reqmsgsz;              /* size of client request message */
  size_t         replysz;               /* size of server reply message */
  size_t         outsz;                 /* size of encrypted request message */
  size_t         insize;                /* size of encrypted reply message */

  in_port_t      srvport = SRVPORT;     /* port number the server listens on */
  int            srvport_in = 0;        /* port number specified by user */
  char           *srvhost = "localhost"; /* name of server host */
  int            done = 0;              /* to end client */

  struct cipher  cipher;                /* cipher algorithm */

  /* Get the server port number from user, if any */
  if (argc > 1)
  {
    if (argv[1][0] == '?')
    {
      fprintf(stderr, "Usage: %s [server_port_number][server_host][cipher]\n",
        argv[0]);
      return(0);
    }
    
    srvport_in = atoi(argv[1]);
    if (srvport_in <= 0)
    {
      fprintf(stderr, "Error: port number %s invalid\n", argv[1]);
      fprintf(stderr, "Usage: %s [server_port_number][server_host][cipher]\n",
        argv[0]);
      return(-1);
    }
    else
      srvport = srvport_in;
  }

  /* Get the name of the server host from user, if specified */
  if (argc > 2)
    srvhost = argv[2];

  /* Get the algorithm name from command line, if there is one */
  if (argc > 3)
    strcpy(cipher.name, argv[3]);
  else
    strcpy(cipher.name, DEFAULT_CIPHER);

  strcpy((char *)cipher.key, DEFAULT_KEY);
  strcpy((char *)cipher.iv, DEFAULT_IV);

  /* Allocate input buffer */
  reqmsg = malloc(MAXREQSZ);
  if (reqmsg == NULL)
  {
    fprintf(stderr, "Error: malloc() failed\n");
    return(-3);
  }

  /* Connect to the server */
  ret = connect_to_server(&sfd, srvhost, srvport);
  if (ret != 0)
  {
    fprintf(stderr, "Error: connect_to_server() failed, ret=%d\n", ret);
    if (sfd) close(sfd);
    free(reqmsg);
    return(-4);
  }

  /* Send a few messages to the server */
  do
  {
    fprintf(stdout, "Enter a message to send ('bye' to end): ");
    reqmsgsz = getline(&reqmsg, &reqbufsz, stdin);
    if (reqmsgsz == -1)
    {
      fprintf(stderr, "Error: getline() failed, ret=%lu\n", reqmsgsz);
      FREEALL
      return(-5);
    }

    /* Remove the newline character at end of input */
    reqmsg[--reqmsgsz] = '\0';

    /* Encrypt the message to be sent */
    ret = myencrypt1(reqmsg, reqmsgsz, outbuf, &outsz, &cipher);
    if (ret != 0)
    {
      fprintf(stderr, "Error: myencrypt1() failed, ret=%d\n", ret);
      FREEALL
      return(-6);
    }

    fprintf(stdout, "Send request:\n");
    print_cipher_text(outbuf, outsz);

    /* Send the encrypted message */
    ret = send_msg(sfd, (unsigned char *)outbuf, outsz, 0);
    if (ret != 0)
    {
      fprintf(stderr, "Error: send_msg() failed, ret=%d\n", ret);
      FREEALL
      return(-7);
    }

    /* Wait for server reply */
    memset((void *)inbuf, 0, MAXRPLYSZ);
    insize = 0;
    insize = recv(sfd, inbuf, MAXRPLYSZ, 0);
    if (insize <= 0)
    {
      fprintf(stderr, "Error: recv() failed to receive a reply from "
        "server, insize=%lu\n", insize);
      FREEALL
      return(-8);
    }

    /* Decrypt the server reply message */
    memset((void *)replymsg, 0, MAXRPLYSZ);
    replysz = 0;
    ret = mydecrypt1(inbuf, insize, replymsg, &replysz, &cipher);
    if (ret != 0)
    {
      fprintf(stderr, "Error: mydecrypt1() failed, ret=%d\n", ret);
      FREEALL
      return(-9);
    }

    replymsg[replysz]='\0';
    fprintf(stdout, "Got this reply: %s\n", replymsg);

    if (!strcmp(replymsg, reqmsg))
      done = 1;

  } while (!done);

  close(sfd);
  free(reqmsg);
  return(0);
}
