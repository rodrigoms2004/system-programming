/*
 * Defines and declarations for networking library
 * Copyright (c) 2015, 2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>        /* memset() */
#include <stdlib.h>        /* malloc(), atoi() */
#include <ctype.h>         /* isdigit() */
#include <sys/types.h>
#include <sys/socket.h>    /* socket() */
#include <unistd.h>        /* gethostname() */
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <netdb.h>         /* HOST_NAME_MAX */
#include <arpa/inet.h>     /* inet_ntop(), inet_pton() */
#include <pthread.h>

#define  MINIPADDRSZ     64    /* minimum buffer size for IP address */
#ifndef HOST_NAME_MAX
#define  HOST_NAME_MAX  255    /* maximum length of a host name */
#endif

#define  LSNRBACKLOG    1500   /* length of listener request queue */

/*
 * ================== Get host name/IP-address functions ====================
 */

/*
 * Get the hostname of this host as a pointer to string.
 * The caller must provide the buffer to hold the returned hostname.
 * The buffer must be at least HOST_NAME_MAX bytes.
 * The function returns 0 on success or a non-zero value otherwise.
 */
int get_hostname(char *buf, size_t buflen);

/*
 * Get the hostname of this host as string -- no parameter version.
 * A pointer to the hostname string is returned on success.
 * The caller must free the memory pointed at by the returned pointer.
 * A NULL pointer is returned in case of failure.
 */
char *get_hostname2();

/*
 * Get the IP address of this host as a string.
 * The IP address is returned in the ipaddr buffer which must be provided
 * by the caller. The ipaddrlen parameters specifies the size of the
 * ipaddr buffer, which must be at least MINIPADDRSZ bytes.
 * Return value: 0 if success, non-zero if failure
 * get_ipaddr() invokes get_hostname() and get_ipaddr_host().
 */
int get_ipaddr(char *ipaddr, size_t ipaddrlen);

/*
 * Get the IP address of this host as a string -- no parameter version.
 * A pointer to the IP address string is returned on success.
 * The caller is responsible for freeing that memory.
 * The caller must free the memory pointed at by the returned pointer.
 * A NULL pointer is returned in case of failure.
 * get_ipaddr() invokes get_hostname2() and get_ipaddr_host().
 */
char *get_ipaddr2();

/*
 * Get the IP address of the specified host as a string.
 * The IP address is returned in the ipaddr buffer which must be provided
 * by the caller. The hostname is specified by the hostname input parameter.
 * The ipaddrlen parameter specifies the length of the ipaddr buffer
 * which must be at least MINIPADDRSZ bytes long.
 * If hostname is NULL, it is assumed to be the current host.
 * The function returns 0 if success, non-zero if failure
 */
int get_ipaddr_host(char *hostname, char *ipaddr, size_t ipaddrlen);

/*
 * ================== Network connection functions ===========================
 */

/* Connect to a connection-oriented server */
int connect_to_server(int *sfdp, char *host, int portnum);

/* Create a bound network communication endpoint */
int new_bound_endpt(int *sfdp, struct sockaddr *srvaddrp,
  sa_family_t protocol, int portnum);

/* Create a bound server network communication endpoint */
int new_bound_srv_endpt(int *sfdp, struct sockaddr *srvaddrp,
  sa_family_t protocol, int portnum);

/* Create a bound client network communication endpoint */
int new_bound_clnt_endpt(int *sfdp, struct sockaddr *srvaddrp,
  sa_family_t  protocol);

/*
 * ======================= Network I/O functions =============================
 */

/* Send a message via a socket */
int send_msg(int sfd, unsigned char *bufp, size_t msgsz, int flags);

/* Receive a message via a socket */
int receive_msg(int sfd, unsigned char *bufp, size_t msgsz, int flags);

/* Print the contents of a binary buffer */
void print_binary_buf(unsigned char *buf, unsigned int buflen);
