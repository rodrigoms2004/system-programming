/*
 * This program computes the HMAC value of a big message stored in a file.
 * The entire contents of a file are regarded as a message.
 * This program computes a HMAC value from the entire contents of a file.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>     /* open() */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>        /* read(), write() */
#include <string.h>        /* memset(), strlen() */
#include <strings.h>       /* bzero() */
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/err.h>
#include "myopenssl.h"
#include "netlib.h"

/*
 * Compute the HMAC value of the contents of a file using the cryptographic
 * hash function specified by the 'hashfunc_name' parameter.
 * The input file is specified by the 'infname' parameter.
 * The key used in computing the HMAC is given by the 'key' parameter.
 * The resulting HMAC value is returned in the 'hash' parameter.
 * This output buffer must be at least EVP_MAX_MD_SIZE bytes long.
 * The length of the hash value is returned in the 'hashlen' parameter.
 */
int get_HMAC(char *infname, char *hashfunc_name, unsigned char *key,
    unsigned char *hash, unsigned int *hashlen)
{
  int            infd=0;         /* input file descriptors */
  ssize_t        inlen;          /* bytes read */
  int            ret;
  unsigned char  inbuf[INSIZE];  /* input buffer */
  HMAC_CTX       *hmac_ctx;      /* HMAC context */
  const EVP_MD   *hashfunc;      /* hash function to use */

  if (infname == NULL || hashfunc_name == NULL || key == NULL
      || hash == NULL || hashlen == NULL)
    return(EINVAL);

  /* Get the hash function by name */
  hashfunc = EVP_get_digestbyname(hashfunc_name);
  if(hashfunc == NULL)
  {
    fprintf(stderr, "Error: get_HMAC(), unknown hash function %s\n",
      hashfunc_name);
    return(-1);
  }

  /* Creates a HMAC context */
  hmac_ctx = HMAC_CTX_new();
  if (hmac_ctx == NULL)
  {
    fprintf(stderr, "Error: get_HMAC(), HMAC_CTX_new() failed\n");
    return(-2);
  }

  /* Set up the HMAC context with the hash function and key */
  ret = HMAC_Init_ex(hmac_ctx, key, strlen((char *)key), hashfunc, (ENGINE *)NULL);  
  if (ret != 1)
  {
    fprintf(stderr, "Error: get_HMAC(), HMAC_Init_ex() failed\n");
    HMAC_CTX_free(hmac_ctx);
    return(-3);
  }

  /* Open the input file */
  infd = open(infname, O_RDONLY);
  if (infd == -1)
  {
    fprintf(stderr, "Error: get_HMAC() failed to open input file %s, errno=%d\n",
      infname, errno);
    HMAC_CTX_free(hmac_ctx);
    return(-4);
  }

  /* Read contents of the entire file and calculate its HMAC */
  do
  {
    bzero (inbuf, INSIZE);
    /* Read next chunk from the input file */
    inlen = read(infd, inbuf, INSIZE);
    if (inlen <= 0)
    {
      if (inlen < 0)
      {
        fprintf(stderr, "Error: get_HMAC() failed to read input file %s, "
          "errno=%d\n", infname, errno);
        HMAC_CTX_free(hmac_ctx);
        return(-5);
      }
      else
        break;
    }

    /* Compute message authentication code of current input chunk */
    if (HMAC_Update(hmac_ctx, inbuf, inlen) != 1)
    {
      fprintf(stderr, "Error: get_HMAC(), HMAC_Update() failed\n");
      HMAC_CTX_free(hmac_ctx);
      return(-6);
    }

  } while (1);

  /* Wrap up the calculation by handling the last remaining part */
  memset(hash, 0, EVP_MAX_MD_SIZE);
  if (HMAC_Final(hmac_ctx, hash, hashlen) != 1)
  {
    fprintf(stderr, "Error: get_HMAC(), HMAC_Final() failed\n");
    HMAC_CTX_free(hmac_ctx);
    return(-7);
  }

  HMAC_CTX_free(hmac_ctx);
  return(0);
}

/* Compute the HMAC of the contents of a file */
int main(int argc, char *argv[])
{
  char           *infname = "hmacdatain";      /* file containing the message */
  char           *hashfunc_name=HASHFUNC_NAME; /* name of hash function */
  unsigned char  hash[EVP_MAX_MD_SIZE];        /* HMAC hash value */
  unsigned int   hashlen=0;                    /* length of hash value */
  unsigned char  *key = (unsigned char *)HMACKEY;    /* key for HMAC */
  int            ret;

  /* Get the names of input file and hash function from user, if any */
  if (argc > 1)
    hashfunc_name = argv[1];

  if (argc > 2)
    infname = argv[2];

  /* Calculate the HMAC value of the contents of the input file */
  memset(hash, 0, EVP_MAX_MD_SIZE);
  ret = get_HMAC(infname, hashfunc_name, key, hash, &hashlen);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), get_HMAC() failed, ret=%d\n", ret);
    return(ret);
  }

  fprintf(stdout, "HMAC value of the file %s is:\n", infname);
  print_binary_buf(hash, EVP_MAX_MD_SIZE);

  return(0);
}
