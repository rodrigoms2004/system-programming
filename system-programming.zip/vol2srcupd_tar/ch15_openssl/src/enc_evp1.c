/*
 * This program encrypts a message given by the user using a cipher algorithm
 * chosen by the user and then decrypts the encrypted message.
 * This single program can encrypt and decrypt using different cipher algorithms.
 * The cipher algorithm used is specified by the user on the command line
 * by providing a name like bf-cbc, aes-256-cbc or des-ede3-ofb.
 * Run the 'openssl ?' command to get the list of cipher algorithms available.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2019-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>     /* open() */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>        /* read(), write() */
#include <string.h>        /* memset(), strlen() */
#include <strings.h>       /* bzero() */
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/blowfish.h>
#include "myopenssl.h"

/* sizes of chunks this program works on */
#define MAXMSGSZ  1024
#define MAXOUTSZ  (MAXMSGSZ+IVLEN)

/* A simple encryption and decryption program */
int main(int argc, char *argv[])
{
  size_t      inlen;                /* length of input plain text */
  size_t      outlen = 0;           /* length of output cipher text */
  size_t      textlen;              /* length of decrypted text */
  int         ret;
  struct cipher     cipher;         /* cipher to be used */

  char  *inmsg;                     /* pointer to original input message */
  unsigned char  outbuf[MAXOUTSZ];  /* buffer for encrypted message */
  char  plaintext[MAXMSGSZ+1];      /* buffer for decrypted message */

  /* User must enter the name of an algorithm and a message to be encrypted */
  if (argc < 3)
  {
    fprintf(stdout, "Usage: %s algorithm message \n", argv[0]);
    return(-1);
  }

  /* Check to make sure the input message is not too large */
  inmsg = argv[2];
  inlen = strlen(inmsg);
  if (inlen > MAXMSGSZ)
  {
    fprintf(stderr, "Error: input message is too long, max size=%u\n",
      MAXMSGSZ);
    return(-2);
  }
  fprintf(stdout, "Plain text=%s\n", inmsg);

  /* Fill in the name, key and IV for the cipher to be used */
  strcpy(cipher.name, argv[1]);
  strcpy((char *)cipher.key, DEFAULT_KEY);
  strcpy((char *)cipher.iv, DEFAULT_IV);

  /* Encrypt the message */
  bzero(outbuf, MAXOUTSZ);
  ret = myencrypt1(inmsg, inlen, outbuf, &outlen, &cipher);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), myencrypt1() failed, ret=%d\n", ret);
    return(ret);
  }
  print_cipher_text(outbuf, outlen);
  
  /* Decrypt the message */
  ret = mydecrypt1(outbuf, outlen, plaintext, &textlen, &cipher);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), mydecrypt1() failed, ret=%d\n", ret);
    return(ret);
  }
  plaintext[textlen] = '\0';
  fprintf(stdout, "Decrypted message=%s\n", plaintext);

  /* Compare the decrypted output with the original input message */
  if (!strcmp(inmsg, plaintext))
    fprintf(stdout, "The encryption and decryption have succeeded.\n");
  else
    fprintf(stdout, "The encryption and decryption have failed.\n");

  return(0);
}

