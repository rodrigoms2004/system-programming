/*
 * This program encrypts a message given by the user using a cipher algorithm
 * chosen by the user and then decrypts the envrypted message.
 * This single program can encrypt and decrypt using different cipher algorithms.
 * The cipher algorithm used is specified by the user on the command line
 * by providing a name like bf-cbc, aes-256-cbc or des-ede3-ofb.
 * Run the 'openssl ?' command to get the list of cipher algorithms available.
 * This example uses the same set of APIs for both encryption and decryption:
 *   EVP_CipherInit_ex(), EVP_CipherUpdate() and EVP_CipherFinal_ex().
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2016-2017, 2019-2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>     /* open() */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>        /* read(), write() */
#include <string.h>        /* memset(), strlen() */
#include <strings.h>       /* bzero() */
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/blowfish.h>
#include "myopenssl.h"

#define  OPENSSL_SUCCESS    1    /* Openssl functions return 1 as success */

/* sizes of chunks this program works on */
#define MAXMSGSZ  1024
#define MAXOUTSZ  (MAXMSGSZ+IVLEN)

/* A simple encryption and decryption program */
int main(int argc, char *argv[])
{
  size_t      inlen;                /* length of input plain text */
  size_t      outlen = 0;           /* length of output cipher text */
  size_t      textlen;              /* length of decrypted text */
  int         ret;

  struct cipher  cipher;            /* cipher algorithm */
  char           *cipher_name;      /* string name of the cipher algorithm */

  char  *inmsg;                     /* pointer to original input message */
  unsigned char  outbuf[MAXOUTSZ];       /* buffer for encrypted message */
  char           plaintext[MAXMSGSZ+1];  /* buffer for decrypted message */

  /* User must enter the name of an algorithm and a message to be encrypted */
  if (argc < 3)
  {
    fprintf(stdout, "Usage: %s algorithm message \n", argv[0]);
    return(-1);
  }

  /* Check to make sure the input message is not too large */
  cipher_name = argv[1];
  inmsg = argv[2];
  inlen = strlen(inmsg);
  if (inlen > MAXMSGSZ)
  {
    fprintf(stderr, "Error: input message is too long, max size=%u\n",
      MAXMSGSZ);
    return(-2);
  }
  fprintf(stdout, "Plain text=%s\n", inmsg);

  strcpy(cipher.name, cipher_name);
  strcpy((char *)cipher.key, DEFAULT_KEY2);
  strcpy((char *)cipher.iv, DEFAULT_IV2);

  /* Encrypt the message */
  bzero(outbuf, MAXOUTSZ);
  ret = myencrypt2(inmsg, inlen, outbuf, &outlen, &cipher);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), encrypt() failed, ret=%d\n", ret);
    return(ret);
  }
  print_cipher_text(outbuf, outlen);
  
  /* Decrypt the message */
  ret = mydecrypt2(outbuf, outlen, plaintext, &textlen, &cipher);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), mydecrypt2() failed, ret=%d\n", ret);
    return(ret);
  }
  plaintext[textlen] = '\0';
  fprintf(stdout, "Decrypted message=%s\n", plaintext);

  /* Compare the decrypted output with the original input message */
  if (!strcmp(inmsg, plaintext))
    fprintf(stdout, "The encryption and decryption have succeeded.\n");
  else
    fprintf(stdout, "The encryption and decryption have failed.\n");

  return(0);
}
