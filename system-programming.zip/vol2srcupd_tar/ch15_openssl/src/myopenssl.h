/*
 * #defines for Openssl programs.
 */

#define  SUCCESS            0    /* Linux/Unix functions return 0 as success */
#define  OPENSSL_SUCCESS    1    /* Openssl functions return 1 as success */
#define  OPENSSL_FAILURE    0    /* Openssl functions return 0 as failure */
#define  ERRBUFLEN        256    /* length of error string buffer */

/* Constants used in client-server communications */
#define SRVPORT   7878     /* server's port number */
#define MAXREQSZ  1024     /* maximum size of client request messages */
#define MAXRPLYSZ 256      /* maximum size of server reply messages */
#define SRVREPLY  "This is a reply message from the server."
#define SRVREPLY2 "This is reply message #%2d from the server."
#define BYE_MSG   "bye"    /* input message to end session */

/* Length of error string buffer */
#define ERR_STRING_LEN  256  /* length of buffer to hold error string */

/* Structure representing a cipher in EVP */
#define MAX_CIPHER_NAME_LEN 32
struct cipher
{
  char  name[MAX_CIPHER_NAME_LEN+4];
  unsigned char  key[EVP_MAX_KEY_LENGTH+4];
  unsigned char  iv[EVP_MAX_IV_LENGTH+4];
};
typedef struct cipher cipher;

/*
 * Default values for key and IV used in encryption/decryption.
 * Note that KEYLEN and IVLEN vary from one algorithm to another.
 * These values are shared by the encryption and decryption.
 * Algorithm "bf-cbc" works in OpenSSL 1.1.1, but not OpenSSL 3.0. (2021-12-9)
 */
#define DEFAULT_CIPHER  "aes-256-cbc"
#define DEFAULT_CIPHER2 "DES-EDE3-CBC"
#define IVLEN           16     /* length of IV (number of bytes) */
#define KEYLEN          32     /* key length (number of bytes) */
#define DEFAULT_IV      "2596703183564237"
#define DEFAULT_KEY     "Axy3pzsk%3q#0)yH+sTcG6Wo27yjFFiw"

/* IV and Key used by myencrypt2() and mydecrypt2() */
#define DEFAULT_IV2     "7593215400406031"
#define DEFAULT_KEY2    "Gxy3pzek%3q#0)tH+sTcG6Wc27gjFF(*"

/* Constants used by myencrypt2() and mydecrypt2() */
#define MAXMSGSZ  1024
#define MAXOUTSZ  (MAXMSGSZ+IVLEN)

/*
 * Defines for HMAC.
 */
#define HASHFUNC_NAME   "sha512"
#define HMACKEY         "15y3pz70%8q#0)yH+sTcG6Wo27yjFF(!"

/* File I/O */
#define INSIZE          1024  /* read this many bytes each time */

/*
 * Defines for digital signatures
 */
#define  LENGTHSZ  (sizeof(unsigned int))  /* size of signature/msg length */
#define  MAXDGSTSZ 512                     /* size of buffer for digest */

/* #defines for DSA signature with SHA256 256-bit digest */
#define  DSASEEDLEN    20       /* length of seed */
#define  DSASEED       "G3fLw789Os3f8JV24dZ9"  /* seed for DSA */
#define  DSABITSLEN    1024     /* bits - length of the prime number p */
#define  DSASIGLEN     80       /* buffer length of DSA signature */
#define  DSAHASH_NAME  "sha256" /* use 256 bits hash */
#define  DSAHASHKEY    "B6h8eA39%8p#4)iM+sTcG64o1eXj(!s4"  /* hash key */
#define  DSAPUBKEYFILE "DSAPubKeyFile"  /* file holding DSA public key */

/* #defines for RSA signature */
#define  RSASEEDLEN    32       /* length of seed */
#define  RSASEED       "ksNi0lE$U&35Hm9ad12)KedQ3=Pnc5+="  /* seed */
#define  RSABITSLEN    2048     /* bits - length of ????? */
#define  RSASIGLEN     264      /* buffer length of RSA signature */
#define  RSAHASH_NAME  "sha512" /* use 512 bits hash */
#define  RSADGSTTYPE   NID_sha512       /* type of digest algorithm */
#define  RSAPUBKEYFILE "RSAPubKeyFile"  /* file holding RSA public key */
 
/*
 * Different types of message digest algorithms.
 * NID_sha1 NID_sha224 NID_sha256 NID_sha384 NID_sha512 NID_md5 ...
 */

/*   */
#define  SIG_ALGRTH_LEN     256  /* length of signature algorithm */
#define  PUBKEY_ALGRTH_LEN  512  /* length of key algorithm */

/*
 * Errors in calling some OPENSSL functions.
 */
#define OPENSSL_ERR_SSLNEW_FAIL     (-1001)
#define OPENSSL_ERR_SSLSETFD_FAIL   (-1002)
#define OPENSSL_ERR_BAD_CERTFILE    (-1003)
#define OPENSSL_ERR_BAD_KEYFILE     (-1004)
#define OPENSSL_ERR_KEY_MISMATCH    (-1005)
#define OPENSSL_ERR_NO_CLIENT_CERT  (-1006)
#define OPENSSL_ERR_CLIENT_CERT_VERIFY_FAIL  (-1007)

/*
 * TLS/SSL certificates for server, client and CAs.
 * For self-signed server certificate, SRV_CERT_FILE and CA_FILE must be
 * the same.
 */
/* Self-signed server certificate */
#define  CA_DIR  "./"
#define  SS_SRV_CERT_FILE "mysrv2_cert.pem"
#define  SS_SRV_KEY_FILE  "mysrv2_privkey.pem"
#define  SS_CA_FILE       "mysrv2_cert.pem"

/* Server certificate signed by a chain of CAs */
#define  SRV_CERT_FILE    "myserver_cert.pem"
#define  SRV_KEY_FILE     "myserver_privkey.pem"
#define  CLNT_CERT_FILE   "myclient_cert.pem"
#define  CLNT_KEY_FILE    "myclient_privkey.pem"
#define  CA_FILE          "myCAchain_cert.pem"
/* A second certificate chain */
#define  CLNT2_CERT_FILE  "xyzclnt_cert.pem"
#define  CLNT2_KEY_FILE   "xyzclnt_privkey.pem"
#define  CA2_FILE         "mychain2CAs_cert.pem"
#define  CAALL_FILE       "myAllCAs_cert.pem"

/* Cipher list to be used in SSL/TLS */
#define CIPHER_LIST "AES256-SHA256 "

/*
 * Function prototypes
 */
void display_certificate_names(SSL* ssl);
int display_certificate_info(X509 *cert);
void print_ssl_io_error(int error);
void display_cipher_suites(SSL *ssl);
void display_ssl_certificate_info(SSL* ssl);
/* Print the encrypted message -- the cipher text */
void print_cipher_text(unsigned char *buf, unsigned int buflen);

/* Encryption and decryption APIs */
int myencrypt1(char *inbuf, size_t inlen, unsigned char *outbuf, size_t *outlen, cipher *cipher);
int mydecrypt1(unsigned char *inbuf, size_t inlen, char *outbuf, size_t *outlen, struct cipher *cipher);

int myencrypt2(char *inbuf, size_t inlen, unsigned char *outbuf, size_t *outlen, struct cipher *cipherin);
int mydecrypt2(unsigned char *inbuf, size_t inlen, char *outbuf, size_t *outlen, struct cipher *cipherin);

/* Digital signature APIs */
int init_DSA(int bits, unsigned char *seed, unsigned int seedlen, DSA **dsa);
int get_DSA_signature(unsigned char *digest, unsigned int dgstlen,
   unsigned char *signature, unsigned int *siglen, DSA *dsa);
int verify_DSA_signature(unsigned char *digest, unsigned int dgstlen,
    unsigned char *signature, unsigned int siglen, DSA *dsa);

int init_RSA(int bits, unsigned char *seed, unsigned int seedlen, RSA **rsa);
int get_RSA_signature(int dgsttype, unsigned char *digest, unsigned int dgstlen,
   unsigned char *signature, unsigned int *siglen, RSA *rsa);
int verify_RSA_signature(int dgsttype, unsigned char *digest, unsigned int dgstlen,
    unsigned char *signature, unsigned int siglen, RSA *rsa);

/* Compute the digest of a message using the hash algorithm specified */
int message_digest(char *hashname, char *message, unsigned int msglen,
    unsigned char *digest, unsigned int *dgstlen);
int message_digest2(const EVP_MD *hashfunc, char *message,
    unsigned int msglen, unsigned char *digest, unsigned int *dgstlen);

/* Increment the IV value by one */
int increment_iv(unsigned char *inbuf, unsigned char *outbuf);

int load_certificate(SSL_CTX *ctx, char *certfile, char *keyfile);

