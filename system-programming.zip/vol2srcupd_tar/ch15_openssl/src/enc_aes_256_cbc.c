/*
 * A simple encryption and decryption program -- basic sequence of steps.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2020-2022 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>       /* memset(), strlen() */
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/blowfish.h>

#define  OPENSSL_SUCCESS    1    /* Openssl functions return 1 as success */

/* Note: KEYLEN and IVLEN vary from one algorithm to another */
#define IVLEN   16       /* length of IV (number of bytes) */
#define KEYLEN  16       /* key length (number of bytes) */

/* sizes of chunks this program works on */
#define INSIZE 1024
#define OUTSIZE (INSIZE+IVLEN)

/* These are shared by the encryption and decryption. */
unsigned char iv[IVLEN+1] = "0000000000000001";
unsigned char key[KEYLEN+1] = "Axy3pzLk%8q#0)yH";

/* Print the ciphertext stored in 'buf'. Note that data is unsigned. */
void print_ciphertext(unsigned char *buf, unsigned int buflen)
{
  int   i;

  if (buf == NULL) return;
  fprintf(stdout, "ciphertext=0x");
  for (i = 0; i < buflen; i++)
    fprintf(stdout, "%02x", buf[i]);
  printf("\n");
}

/* Encrypt the message in 'inbuf' and put the results in 'outbuf'.
 * The length of output cipher text is returned in 'outlen'.
 * Make sure the 'outbuf' is large enough to hold the results.
 */
int encrypt(unsigned char *inbuf, int inlen, unsigned char *outbuf, int *outlen)
{
  EVP_CIPHER_CTX *ctx = NULL;        /* cipher context */
  int      outlen1, outlen2;         /* length of output cipher text */
  int      totallen = 0;             /* total length of output cipher text */
  int      ret;

  if (inbuf == NULL || outbuf == NULL || outlen == NULL)
    return(EINVAL);
  *outlen = 0;

  /* Create a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: encrypt(), EVP_CIPHER_CTX_new() failed\n");
    return(-1);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
  if (!ret)
  {
    fprintf(stderr, "Error: encrypt(), EVP_EncryptInit_ex() failed\n");
    EVP_CIPHER_CTX_free(ctx);
    return(-2);
  }

  /* Encrypt the input message */
  /* If the inlen is wrong, it may result in no error but outlen1 is 0. */
  outlen1 = 0;
  if (EVP_EncryptUpdate(ctx, outbuf, &outlen1, inbuf, inlen) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: encrypt(), EVP_EncryptUpdate() failed\n");
    EVP_CIPHER_CTX_free(ctx);
    return(-3);
  }
  totallen = totallen + outlen1;
  *outlen = totallen;

  /* Wrap up the encryption by handling the last remaining part */
  outlen2 = 0;
  if (EVP_EncryptFinal_ex(ctx, outbuf+totallen, &outlen2) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: encrypt(), EVP_EncryptFinal_ex() failed\n");
    EVP_CIPHER_CTX_free(ctx);
    return(-4);
  }
  totallen = totallen + outlen2;
  *outlen = totallen;

  EVP_CIPHER_CTX_free(ctx);

  return(0);
}

/* Decrypt the message in 'inbuf' and put the results in 'outbuf'.
 * The length of output is returned in 'outlen'.
 * Make sure the 'outbuf' is large enough to hold the results.
 */
int decrypt(unsigned char *inbuf, int inlen, unsigned char *outbuf, int *outlen)
{
  EVP_CIPHER_CTX *ctx = NULL;        /* cipher context */
  int      outlen1, outlen2;         /* length of output plain text */
  int      totallen = 0;             /* total length of output plain text */
  int      ret;

  if (inbuf == NULL || outbuf == NULL || outlen == NULL)
    return(EINVAL);
  *outlen = 0;

  /* Create a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: decrypt(), EVP_CIPHER_CTX_new() failed\n");
    return(-1);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
  if (!ret)
  {
    fprintf(stderr, "Error: decrypt(), EVP_DecryptInit_ex() failed\n");
    EVP_CIPHER_CTX_free(ctx);
    return(-2);
  }

  /* Decrypt the input message */
  outlen1 = 0;
  if (EVP_DecryptUpdate(ctx, outbuf, &outlen1, inbuf, inlen) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: decrypt(), EVP_DecryptUpdate() failed\n");
    EVP_CIPHER_CTX_free(ctx);
    return(-3);
  }
  totallen = totallen + outlen1;
  *outlen = totallen;

  /* Wrap up the decryption by handling the last remaining part */
  outlen2 = 0;
  if (EVP_DecryptFinal_ex(ctx, outbuf+totallen, &outlen2) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: decrypt(), EVP_DecryptFinal_ex() failed\n");
    EVP_CIPHER_CTX_free(ctx);
    return(-4);
  }
  totallen = totallen + outlen2;
  *outlen = totallen;

  EVP_CIPHER_CTX_free(ctx);

  return(0);
}

/* A simple encryption and decryption program */
int main(int argc, char *argv[])
{
  int      outlen = 0;           /* length of output cipher text */
  int      ret;

  /* Buffer of the original plain text to be encrypted */
  unsigned char  inbuf[INSIZE]="This is the original message.";
  /* Buffer of the output of encryption */
  unsigned char  outbuf[OUTSIZE];
  /* Buffer of the output of decryption */
  unsigned char  outbuf2[OUTSIZE];
  int      outlen2 = 0;           /* length of output cipher text */

  fprintf(stdout, "plaintext=%s\n", inbuf);

  /* Encrypt the message */
  ret = encrypt(inbuf, strlen((char *)inbuf), outbuf, &outlen);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), encrypt() failed, ret=%d\n", ret);
    return(ret);
  }
  print_ciphertext(outbuf, outlen);

  /* Decrypt the message */
  ret = decrypt(outbuf, outlen, outbuf2, &outlen2);
  if (ret != 0)
  {
    fprintf(stderr, "Error: main(), decrypt() failed, ret=%d\n", ret);
    return(ret);
  }
  outbuf2[outlen2] = '\0';
  fprintf(stdout, "decrypted output=%s\n", outbuf2);

  return(0);
}

