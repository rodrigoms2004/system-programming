/*
 * Demonstrating secrecy, message integrity and origin authentication
 * in network communications.
 * This is a TCP client program which exchanges messages with
 * a TCP server using encryption/decryption for secrecy and HMAC for
 * message integrity and message authentication.
 * Copyright (c) 2015, 2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset(), strlen() */
#include <stdlib.h>        /* atoi(), malloc() */
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/err.h>
#include "myopenssl.h"
#include "netlib.h"

#define FREEALL    \
    close(sfd);    \
    free(reqmsg);

int main(int argc, char *argv[])
{
  int      ret;                   /* return value */
  int      sfd=0;                 /* socket file descriptor */
  char     replymsg[MAXRPLYSZ];   /* reply message from server */
  size_t   reqbufsz = MAXREQSZ;   /* size of client request buffer */
  char     *reqmsg=NULL;          /* pointer to request message buffer */
  size_t   reqmsgsz;              /* size of client request message */
  size_t   replysz;               /* size of server reply message */
  size_t   outsz;                 /* size of encrypted request message */
  size_t   insize;                /* size of encrypted reply message */
  unsigned char  outbuf[MAXREQSZ+EVP_MAX_MD_SIZE];    /* output buffer */
  unsigned char  inbuf[MAXRPLYSZ];                    /* input buffer */

  in_port_t  srvport = SRVPORT;      /* port number the server listens on */
  int        srvport_in = 0;         /* port number specified by user */
  char       *srvhost = "localhost"; /* name of server host */
  int        done = 0;               /* to end client */

  struct cipher  cipher;                 /* cipher to be used */
  unsigned char  newiv[EVP_MAX_IV_LENGTH];  /* new IV */

  const EVP_MD   *hashfunc;              /* hash function */
  unsigned int   hashlen = 0;            /* length of hash */
  unsigned char  *hashptr;               /* pointer to output hash */

  /* Get the server port number from user, if any */
  if (argc > 1)
  {
    srvport_in = atoi(argv[1]);
    if (srvport_in <= 0)
    {
      fprintf(stderr, "Error: port number %s invalid\n", argv[1]);
      return(-1);
    }
    else
      srvport = srvport_in;
  }

  /* Get the name of the server host from user, if specified */
  if (argc > 2)
    srvhost = argv[2];

  /* Set the cipher */
  strcpy(cipher.name, DEFAULT_CIPHER);
  strcpy((char *)cipher.key, DEFAULT_KEY);
  strcpy((char *)cipher.iv, DEFAULT_IV);

  /* Get the structure describing the message hash algorithm by name */
  hashfunc = EVP_get_digestbyname(HASHFUNC_NAME);
  if(hashfunc == NULL)
  {
    fprintf(stderr, "Error: unknown hash function %s\n", HASHFUNC_NAME);
    return(-2);
  }

  /* Connect to the server */
  ret = connect_to_server(&sfd, srvhost, srvport);
  if (ret != 0)
  {
    fprintf(stderr, "Error: connect_to_server() failed, ret=%d\n", ret);
    if (sfd) close(sfd);
    return(-3);
  }

  /* Allocate input buffer */
  reqmsg = malloc(MAXREQSZ);
  if (reqmsg == NULL)
  {
    fprintf(stderr, "Error: malloc() failed\n");
    close(sfd);
    return(-4);
  }

  /* Send a few messages to the server */
  do
  {
    fprintf(stdout, "Enter a message to send ('bye' to end): ");
    reqmsgsz = getline(&reqmsg, &reqbufsz, stdin);
    if (reqmsgsz == -1)
    {
      fprintf(stderr, "Error: getline() failed, ret=%lu\n", reqmsgsz);
      FREEALL
      return(-5);
    }

    /* Remove the newline character at end of input */
    reqmsg[--reqmsgsz] = '\0';

    /* Calculate the HMAC hash of the message */
    hashlen = 0;
    hashptr = HMAC(hashfunc, HMACKEY, strlen(HMACKEY),
        (unsigned char *)reqmsg, reqmsgsz, outbuf, &hashlen);
    if (hashptr == NULL)
    {
      fprintf(stderr, "Error: HMAC() failed\n");
      FREEALL
      return(-6);
    }

    /* Encrypt the message to be sent and place it after the hash in buffer */
    ret = myencrypt2(reqmsg, reqmsgsz, outbuf+EVP_MAX_MD_SIZE, &outsz, &cipher);
    if (ret != 0)
    {
      fprintf(stderr, "Error: myencrypt2() failed, ret=%d\n", ret);
      FREEALL
      return(-7);
    }

    fprintf(stdout, "Send request:\n");
    print_cipher_text(outbuf, outsz+EVP_MAX_MD_SIZE);

    /* Send the encrypted message, together with HMAC */
    ret = send_msg(sfd, (unsigned char *)outbuf, outsz+EVP_MAX_MD_SIZE, 0);
    if (ret != 0)
    {
      fprintf(stderr, "Error: send_msg() failed, ret=%d\n", ret);
      FREEALL
      return(-8);
    }

    /* Wait for server reply */
    memset((void *)inbuf, 0, MAXRPLYSZ);
    insize = 0;
    insize = recv(sfd, inbuf, MAXRPLYSZ, 0);
    if (insize <= 0)
    {
      fprintf(stderr, "Error: recv() failed to receive a reply from "
        "server, insize=%lu\n", insize);
      FREEALL
      return(-9);
    }

    /* Decrypt the server reply message */
    memset((void *)replymsg, 0, MAXRPLYSZ);
    replysz = 0;
    ret = mydecrypt2(inbuf, insize, replymsg, &replysz, &cipher);
    if (ret != 0)
    {
      fprintf(stderr, "Error: mydecrypt2() failed, ret=%d\n", ret);
      FREEALL
      return(-10);
    }

    replymsg[replysz]='\0';
    fprintf(stdout, "Got this reply: %s\n", replymsg);

    if (!strcmp(replymsg, reqmsg))
      done = 1;

    /* Change the IV */
    ret = increment_iv(cipher.iv, newiv);
    if (ret == 0)
      strcpy((char *)cipher.iv, (char *)newiv);
    else
    {
      fprintf(stderr, "Error: increment_iv() failed, ret=%d\n", ret);
      FREEALL
      return(-11);
    }

  } while (!done);

  close(sfd);
  free(reqmsg);
  return(0);
}
