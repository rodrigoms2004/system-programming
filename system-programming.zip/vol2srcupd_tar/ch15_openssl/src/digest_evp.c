/*
 * This program computes the digest of a message using a cryptographic hash
 * algorithm specified by the user. A generic digest function is provided.
 * Use EVP_xxxx() functions, not the cipher-specific functions.
 * Most EVP_xxxx() functions are available in Openssl v1.0.2 but EVP_MD_CTX_new
 * and EVP_MD_CTX_free are available only in Openssl 1.1 and later releases.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include "myopenssl.h"

/* Print the digest stored in buf. Note that data is unsigned. */
void print_digest(unsigned char *buf, unsigned int buflen)
{
  int   i;

  if (buf == NULL) return;
  printf("digest=0x");
  for (i = 0; i < buflen; i++)
    printf("%02x", buf[i]);
  printf("\n");
}

#define DEFAULTMSG  "123xyz456"  /* default message */

/*
 * Compute the digest of a message using a cryptographic hash function
 * specified by the user.
 */
int main(int argc, char *argv[])
{
  char  *msg;        /* message to compute digest from */
  unsigned char  digest[EVP_MAX_MD_SIZE];  /* digest of the message */
  unsigned int   dgstlen;     /* length of the digest */
  int            ret;

  /* Require user to enter at least the name of a message digest algorithm */
  if (argc < 2)
  {
    fprintf(stderr, "Usage: %s hashfunc [message] \n", argv[0]);
    return(-1);
  }

  /* Get the input message entered by user or set it to default */
  if (argc >= 3)
    msg = argv[2];
  else
    msg = DEFAULTMSG;

  /* Calculate the digest of the message */
  ret = message_digest(argv[1], msg, strlen(msg), digest, &dgstlen);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "message_digest() failed, ret=%d\n", ret);
    return(ret);
  }

  print_digest(digest, dgstlen);

  return(0);
}
