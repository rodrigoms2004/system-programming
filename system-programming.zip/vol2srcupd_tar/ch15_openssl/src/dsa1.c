/*
 * Doing digital signature using Digital Signature Algorithm (DSA) in Openssl.
 * Use the same DSA structure for DSA_sign() and DSA_verify().
 * DSA_verify() succeeds.
 * Copyright (c) 2015, 2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>        /* memset(), strlen() */
#include <openssl/dsa.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include "myopenssl.h"
#include "netlib.h"

int main(int argc, char *argv[])
{
  unsigned char  digest[64]="1234567890axij25F7S4302dhLMyTRs2";
  unsigned int   dgstlen;
  unsigned char  *signature = NULL;     /* digital signature */
  unsigned int   siglen = 0;            /* length of digital signature */
  int            ret;

  DSA  *dsa = NULL;
  int  bits = DSABITSLEN;  /* length of the prime number p to be generated */
  unsigned char  seed[DSASEEDLEN+1] = DSASEED;  /* seed */

  /* Initialize DSA */
  ret = init_DSA(bits, seed, DSASEEDLEN, &dsa);
  if (ret != SUCCESS || dsa == NULL)
  {
    fprintf(stderr, "DSA_init() failed, ret=%d.\n", ret);
    return(ret);
  }

  /* Allocate space for receiving the digital signature */
  signature = malloc(DSA_size(dsa));
  if (signature == NULL)
  {
    fprintf(stderr, "malloc() failed\n");
    DSA_free(dsa);
    return(ENOMEM);
  }
  memset(signature, 0, DSA_size(dsa));
  siglen = 0;

  /* Compute the digital signature using DSA */
  dgstlen = strlen((char *)digest);
  ret = get_DSA_signature(digest, dgstlen, signature, &siglen, dsa);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "get_DSA_signature() failed, ret=%d\n", ret);
    DSA_free(dsa);
    free(signature);
    return(ret);
  }
  fprintf(stdout, "Signing the message digest using DSA was successful "
    "(siglen=%u).\n", siglen);
  print_binary_buf(signature, siglen);

  /* Verify the DSA signature */
  ret = verify_DSA_signature(digest, dgstlen, signature, siglen, dsa);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "verify_DSA_signature() failed, ret=%d\n", ret);
    DSA_free(dsa);
    free(signature);
    return(ret);
  }
  fprintf(stdout, "The DSA digital signature was successfully verified.\n");
  
  DSA_free(dsa);
  free(signature);
  return(0);
}
