/*
 * A TLS/SSL client.
 * This program communicates with a TLS/SSL server using TLS/SSL protocol.
 * The client verifies a server certificate signed by a chain of CAs.
 * The client supplies a client certificate signed by a chain of CAs to
 * participate in client authentication.
 * This client uses a certificate signed by a second, different chain of CAs.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2021 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset(), strlen(), memcmp() */
#include <stdlib.h>        /* atoi() */
#include <unistd.h>
#include <resolv.h>
#include <netdb.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509.h>
#include "myopenssl.h"
 
/* Free all resources */
#define  FREEALL  \
    SSL_free(ssl); \
    SSL_CTX_free(ctx); \
    close(sfd);

/* A TLS/SSL client program */
int main(int argc, char *argv[])
{
  unsigned char *srvhost = "localhost"; /* name of server host */
  in_port_t     srvport = SRVPORT;      /* port number server listens on */
  int           srvport_in = 0;         /* port number specified by user */

  int       ret;          /* return value */
  int       sfd=0;        /* socket file descriptor */
  int       error;        /* return value of SSL_get_error() */
  long      sslret;       /* return value of some SSL calls */

  SSL_CTX   *ctx = NULL;  /* SSL/TLS context/framework */
  SSL       *ssl = NULL;  /* SSL/TLS connection */

  unsigned char  replymsg[MAXRPLYSZ];   /* reply message from server */
  size_t         reqbufsz = MAXREQSZ;   /* size of client request buffer */
  char           *reqmsg=NULL;          /* pointer to request message buffer */
  size_t         reqmsgsz;              /* size of client request message */
  int            bytes;                 /* number of bytes received */
  int            done=0;                /* done communicating with server */

  unsigned char  errstrbuf[ERR_STRING_LEN];  /* error string */
 
  /* Print Usage if requested by user */
  if (argc > 1 && argv[1][0] == '?' )
  {
    fprintf(stdout, "Usage: %s [srvportnum] [srvhostname]\n", argv[0]);
    return(0);
  }

  /* Get the port number of the target server host specified by user */
  if (argc > 1)
  {
    srvport_in = atoi(argv[1]);
    if (srvport_in <= 0)
    {
      fprintf(stderr, "Error: port number %s invalid\n", argv[1]);
      return(-1);
    }
    else
      srvport = srvport_in;
  }

  /* Get the name of the target server host specified by user */
  if (argc > 2)
    srvhost = argv[2];

  /* Connect to the server */
  ret = connect_to_server(&sfd, srvhost, srvport);
  if (ret != 0)
  {
    fprintf(stderr, "Error: connect_to_server() failed, ret=%d\n", ret);
    if (sfd) close(sfd);
    return(-2);
  }

  /* Create a TLS/SSL context -- a framework enabling TLS/SSL connections. */
  ctx = SSL_CTX_new(TLS_client_method());
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: SSL_CTX_new() failed\n");
    close(sfd);
    return(-3);
  }

  /* Load the client's own certificate in case client authentication needed.
   * Note that this loading client certificate step MUST be done BEFORE the
   * SSL object is created. Or the client certificate won't be sent! */
  ret = load_certificate(ctx, CLNT2_CERT_FILE, CLNT2_KEY_FILE);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "Error: load_certificate() failed, ret=%d\n", ret);
    SSL_CTX_free(ctx);
    close(sfd);
    return(-4);
  }

  /* Allocate a new SSL structure to hold SSL connection data. 
   * Note: If you do this step before load_certificate(), client certificate
   * won't be sent even if the server requires it. */
  ssl = SSL_new(ctx);
  if (ssl == NULL)
  {
    fprintf(stderr, "Error: SSL_new() failed\n");
    SSL_CTX_free(ctx);
    close(sfd);
    return(-5);
  }

  /* Set default locations for trusted CA certificates for verification */
  if(SSL_CTX_load_verify_locations(ctx, CA_FILE, CA_DIR) < 1)
  {
    fprintf(stderr, "Error: SSL_CTX_load_verify_locations() failed to set "
      "verify location\n");
    return(-6);
  }

  /* Set to do server certificate verification */
  SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);

  /* Associate the SSL object with the socket file descriptor */
  ret = SSL_set_fd(ssl, sfd);
  if (ret != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: SSL_set_fd() failed, ret=%d\n", ret);
    FREEALL
    return(-7);
  }

  /* Initiate the TLS/SSL handshake with the TLS/SSL server */
  ERR_clear_error();
  ret = SSL_connect(ssl);
  if (ret != OPENSSL_SUCCESS)
  {
    error = SSL_get_error(ssl, ret);
    fprintf(stderr, "Error: SSL_connect() failed, error=%d\n", error);
    print_ssl_io_error(error);
    fprintf(stderr, "%s\n", ERR_error_string((unsigned long)error, (char *)NULL));
    FREEALL
    return(-8);
  }

  /* Connected with TLS/SSL server. Display server certificate info. */
  fprintf(stdout, "Connected with TLS/SSL server, cipher algorithm is %s\n",
    SSL_get_cipher(ssl));
  fprintf(stdout, "Information in the server certificate:\n");
  display_ssl_certificate_info(ssl);

  /* Verify the peer's certificate and get the result */
  ERR_clear_error();
  if ((sslret = SSL_get_verify_result(ssl)) == X509_V_OK)
  {
    /* The server sent a certificate which verified OK. */
    fprintf(stdout, "Verifying server's certificate succeeded.\n");
  }
  else
  {
    fprintf(stderr, "SSL_get_verify_result() failed, ret=%d\n", sslret);
    fprintf(stderr, "%s\n", ERR_error_string((unsigned long)sslret, (char *)NULL));
    FREEALL
    return(-9);
  }

  /* Allocate input buffer */
  reqmsg = malloc(MAXREQSZ);
  if (reqmsg == NULL)
  {
    fprintf(stderr, "Error: malloc() failed\n");
    FREEALL
    return(-10);
  }

  /* Send a message and get a response until done */
  do
  {
    /* Get next message the user wants to send */
    fprintf(stdout, "Enter a message to send ('bye' to end): ");
    reqmsgsz = getline(&reqmsg, &reqbufsz, stdin);
    if (reqmsgsz == -1)
    {
      fprintf(stderr, "Error: getline() failed, ret=%d\n", reqmsgsz);
      break;
    }

    /* Remove the newline character at end of input */
    reqmsg[--reqmsgsz] = '\0';

    /* Send a message using SSL -- message automatically encrypted */
    bytes = SSL_write(ssl, reqmsg, reqmsgsz);
    if (bytes != reqmsgsz)
    {
      error = SSL_get_error(ssl, bytes);
      fprintf(stderr, "Error: SSL_write() failed, error=%d\n", error);
      free(reqmsg);
      FREEALL
      return(-11);
    }

    /* Receive a reply using SSL -- reply automatically decrypted */
    bytes = SSL_read(ssl, replymsg, sizeof(replymsg));
    if (bytes <= 0)
    {
      error = SSL_get_error(ssl, bytes);
      fprintf(stderr, "Error: SSL_read() failed, error=%d\n", error);
      free(reqmsg);
      FREEALL
      return(-12);
    }
    else
    {
      replymsg[bytes] = 0;
      fprintf(stdout, "Received: %s\n", replymsg);
    }

    if (!strcmp(replymsg, reqmsg))
      done = 1;

  } while (!done);

  /* release all resources */
  free(reqmsg);
  SSL_free(ssl);      /* release the SSL structure/connection */
  SSL_CTX_free(ctx);  /* release the SSL context */
  close(sfd);         /* close socket */
  return (0);
}
