/*
 * Cryptographic utility functions.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2020-2021 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>     /* open() */
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>        /* read(), write() */
#include <string.h>        /* memset(), strlen() */
#include <strings.h>       /* bzero() */
#include <stdlib.h>
#include <limits.h>        /* LONG_MIN, LONG_MAX */

#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/blowfish.h>
#include <openssl/rsa.h>
#include <openssl/dsa.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/rand.h>
#include "myopenssl.h"

/* ================ encryption/decryption utility functions =============== */
/* Print the encrypted message -- the cipher text */
void print_cipher_text(unsigned char *buf, unsigned int buflen)
{
  int   i;

  if (buf == NULL) return;
  printf("Cipher text=0x");
  for (i = 0; i < buflen; i++)
    printf("%02x", buf[i]);
  printf("\n");
}

/*
 * Encryption and decryption using EVP_EncryptXXX() and EVP_DecryptXXX() APIs.
 * Encrypt the contents of the input buffer specified by 'inbuf' and
 * write the encrypted output (i.e. the cipher text) to the output buffer
 * specified by the 'outbuf' parameter using the cipher algorithm
 * specified by the 'cipher' parameter.
 */
int myencrypt1(char *inbuf, size_t inlen, unsigned char *outbuf, size_t *outlen, cipher *cipher)
{
  const EVP_CIPHER *algrm = NULL;    /* cipher algorithm */
  EVP_CIPHER_CTX   *ctx = NULL;      /* cipher context */
  int      outlen2;                  /* length of last part of cipher text */
  int      ret;

  if (inbuf == NULL || outbuf == NULL || outlen == NULL || cipher == NULL)
    return(EINVAL);

  /* Get the EVP_CIPHER using the string name of the cipher algorithm */
  algrm = EVP_get_cipherbyname(cipher->name);
  if (algrm == NULL)
  {
    fprintf(stderr, "Error: myencrypt1(), failed to look up cipher algorithm %s\n"
      , cipher->name);
    return(-1);
  }

  /* Creates a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: myencrypt1(), EVP_CIPHER_CTX_new() failed\n");
    return(-2);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_EncryptInit_ex(ctx, algrm, NULL, cipher->key, cipher->iv);
  if (!ret)
  {
    fprintf(stderr, "Error: myencrypt1(), EVP_EncryptInit_ex() failed, "
      "ret=%d\n", ret);
    return(-3);
  }

  /* Encrypt the message in the input buffer */
  *outlen = 0;
  if ((ret = EVP_EncryptUpdate(ctx, outbuf, (int *)outlen,
      (unsigned char *)inbuf, (int)inlen) != OPENSSL_SUCCESS))
  {
    fprintf(stderr, "Error: myencrypt1(), EVP_EncryptUpdate() failed, "
      "ret=%d\n", ret);
    return(-4);
  }

  /* Wrap up the encryption by handling the last remaining part */
  outlen2 = 0;
  if ((ret = EVP_EncryptFinal_ex(ctx, outbuf+(*outlen), &outlen2) !=
       OPENSSL_SUCCESS))
  {
    fprintf(stderr, "Error: myencrypt1(), EVP_EncryptFinal_ex() failed, "
      "ret=%d\n", ret);
    return(-5);
  }
  *outlen = *outlen + outlen2;

  EVP_CIPHER_CTX_free(ctx);

  return(0);
}

/*
 * Encryption and decryption using EVP_EncryptXXX() and EVP_DecryptXXX() APIs.
 * Decrypt the contents of the input buffer specified by 'infbuf' and
 * write the decrypted output (i.e. the plain text) to the output buffer
 * specified by 'outbuf' parameter using the cipher algorithm
 * specified by the 'algrm' parameter.
 */
int mydecrypt1(unsigned char *inbuf, size_t inlen, char *outbuf, size_t *outlen, struct cipher *cipher)
{
  const EVP_CIPHER *algrm = NULL;    /* cipher algorithm */
  EVP_CIPHER_CTX   *ctx = NULL;      /* cipher context */
  int      outlen2;                  /* length of last decrypted part */
  int      ret;

  if (inbuf == NULL || outbuf == NULL || outlen == NULL || cipher == NULL)
    return(EINVAL);

  /* Get the EVP_CIPHER using the string name of the cipher algorithm */
  algrm = EVP_get_cipherbyname(cipher->name);
  if (algrm == NULL)
  {
    fprintf(stderr, "Error: mydecrypt1(), failed to look up cipher algorithm %s\n"
      , cipher->name);
    return(-1);
  }

  /* Creates a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: mydecrypt1(), EVP_CIPHER_CTX_new() failed\n");
    return(-2);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_DecryptInit_ex(ctx, algrm, NULL, cipher->key, cipher->iv);
  if (!ret)
  {
    fprintf(stderr, "Error: mydecrypt1(), EVP_DecryptInit_ex() failed, "
      "ret=%d\n", ret);
    return(-3);
  }

  /* Decrypt the contents in the input buffer */
  *outlen = 0;
  if ((ret = EVP_DecryptUpdate(ctx, (unsigned char *)outbuf, (int *)outlen,
       inbuf, (int)inlen) != OPENSSL_SUCCESS))
  {
    fprintf(stderr, "Error: mydecrypt1(), EVP_DecryptUpdate() failed, "
      "ret=%d\n", ret);
    return(-4);
  }

  /* Wrap up the decryption by handling the last remaining part */
  /* Note that EVP_DecryptFinal_ex() returns 1 on success for all algorithms
     except aes-nnn-gcm where it returns 0 on success in OpenSSL 1.1.1.
     This seems to be a bug. Hope OpenSSL will fix this someday.
  */
  outlen2 = 0;
  if ((ret = EVP_DecryptFinal_ex(ctx, (unsigned char *)outbuf+(*outlen),
       &outlen2)) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: mydecrypt1(), EVP_DecryptFinal_ex() failed, "
      "ret=%d\n", ret);
    return(-5);
  }
  *outlen = *outlen + outlen2;

  EVP_CIPHER_CTX_free(ctx);

  return(0);
}

/*
 * Encryption and decryption using EVP_CipherXXX() APIs.
 * Encrypt the contents of the input buffer specified by 'inbuf' and
 * write the encrypted output (i.e. the cipher text) to the output buffer
 * specified by the 'outbuf' parameter using the cipher algorithm
 * specified by the 'cipherin' parameter.
 */
int myencrypt2(char *inbuf, size_t inlen, unsigned char *outbuf, size_t *outlen, struct cipher *cipherin)
{
  EVP_CIPHER_CTX    *ctx = NULL;    /* cipher context */
  int               outlen2;        /* length of last part of cipher text */
  int               ret;            /* return code */
  struct cipher     dfcipher;       /* default cipher */
  struct cipher     *cipher;        /* the cipher used */
  const EVP_CIPHER  *algrm = NULL;  /* cipher algorithm */

  if (inbuf == NULL || outbuf == NULL || outlen == NULL)
    return(EINVAL);

  /* Use the default cipher algorithm if none is specified */
  if (cipherin != NULL)
    cipher = cipherin;
  else
  {
    strcpy(dfcipher.name, DEFAULT_CIPHER);
    strcpy((char *)dfcipher.key, DEFAULT_KEY2);
    strcpy((char *)dfcipher.iv, DEFAULT_IV2);
    cipher = &dfcipher;
  }

  /* Get the EVP_CIPHER using the string name of the cipher algorithm */
  algrm = EVP_get_cipherbyname(cipher->name);
  if (algrm == NULL)
  {
    fprintf(stderr, "Error: myencrypt2(), failed to look up cipher algorithm"
      " %s\n", cipher->name);
    return(-1);
  }

  /* Creates a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: myencrypt2(), EVP_CIPHER_CTX_new() failed\n");
    return(-2);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_CipherInit_ex(ctx, algrm, NULL, cipher->key, cipher->iv, 1);
  if (!ret)
  {
    fprintf(stderr, "Error: myencrypt2(), EVP_CipherInit_ex() failed, "
      "ret=%d\n", ret);
    return(-3);
  }

  /* Encrypt the message in the input buffer */
  *outlen = 0;
  if ((ret=EVP_CipherUpdate(ctx, outbuf, (int *)outlen, (unsigned char *)inbuf,
     (int)inlen)) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: myencrypt2(), EVP_CipherUpdate() failed, "
      "ret=%d\n", ret);
    return(-4);
  }

  /* Wrap up the encryption by handling the last remaining part */
  outlen2 = 0;
  if ((ret = EVP_CipherFinal_ex(ctx, outbuf+(*outlen), &outlen2) !=
       OPENSSL_SUCCESS))
  {
    fprintf(stderr, "Error: myencrypt2(), EVP_CipherFinal_ex() failed, "
      "ret=%d\n", ret);
    return(-5);
  }
  *outlen = *outlen + outlen2;

  EVP_CIPHER_CTX_free(ctx);
  return(0);
}

/*
 * Encryption and decryption using EVP_CipherXXX() APIs.
 * Decrypt the contents of the input buffer specified by 'infbuf' and
 * write the decrypted output (i.e. the plain text) to the output buffer
 * specified by 'outbuf' parameter using the cipher algorithm
 * specified by the 'cipherin' parameter.
 */
int mydecrypt2(unsigned char *inbuf, size_t inlen, char *outbuf,
    size_t *outlen, struct cipher *cipherin)
{
  EVP_CIPHER_CTX    *ctx = NULL;    /* cipher context */
  int               outlen2;        /* length of last part of cipher text */
  int               ret;            /* retrun code */
  struct cipher     dfcipher;       /* default cipher */
  struct cipher     *cipher;        /* the cipher used */
  const EVP_CIPHER  *algrm = NULL;  /* cipher algorithm */

  if (inbuf == NULL || outbuf == NULL || outlen == NULL)
    return(EINVAL);

  /* Use the default cipher algorithm if none is specified */
  if (cipherin != NULL)
    cipher = cipherin;
  else
  {
    strcpy(dfcipher.name, DEFAULT_CIPHER);
    strcpy((char *)dfcipher.key, DEFAULT_KEY2);
    strcpy((char *)dfcipher.iv, DEFAULT_IV2);
    cipher = &dfcipher;
  }

  /* Get the EVP_CIPHER using the string name of the cipher algorithm */
  algrm = EVP_get_cipherbyname(cipher->name);
  if (algrm == NULL)
  {
    fprintf(stderr, "Error: mydecrypt2(), failed to look up cipher algorithm"
      " %s\n", cipher->name);
    return(-1);
  }

  /* Creates a cipher context */
  ctx = EVP_CIPHER_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: mydecrypt2(), EVP_CIPHER_CTX_new() failed\n");
    return(-2);
  }

  /* Set up the cipher context with a specific cipher algorithm */
  ret = EVP_CipherInit_ex(ctx, algrm, NULL, cipher->key, cipher->iv, 0);
  if (!ret)
  {
    fprintf(stderr, "Error: mydecrypt2(), EVP_CipherInit_ex() failed, "
      "ret=%d\n", ret);
    return(-3);
  }

  /* Decrypt the contents in the input buffer */
  *outlen = 0;
  if ((ret = EVP_CipherUpdate(ctx, (unsigned char *)outbuf, (int *)outlen,
       inbuf, (int)inlen)) != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: mydecrypt2(), EVP_CipherUpdate() failed, "
      "ret=%d\n", ret);
    return(-4);
  }

  /* Wrap up the decryption by handling the last remaining part */
  /* Note that EVP_CipherFinal_ex() returns 1 on success for all algorithms
     except aes-nnn-gcm where it returns 0 on success in OpenSSL 1.1.1.
     This seems to be a bug. Hope OpenSSL will fix this someday.
  */
  outlen2 = 0;
  outlen2 = 0;
  ret = EVP_CipherFinal_ex(ctx, (unsigned char *)outbuf+(*outlen), &outlen2);
  if (ret != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: mydecrypt2(), EVP_CipherFinal_ex() failed, "
      "ret=%d\n", ret);
    return(-5);
  }
  *outlen = *outlen + outlen2;

  EVP_CIPHER_CTX_free(ctx);
  return(0);
}

/*
 * This function takes a decimal numeric string and increment its value by one.
 * The parameter inbuf holds the input string and outbuf holds the output.
 * Make sure the outbuf has enough space to hold the output value.
 */
int increment_iv(unsigned char *inbuf, unsigned char *outbuf)
{
  long int  val;             /* numeric value */
  char      *endptr = NULL;  /* end pointer */
  int       ret;

  if (inbuf == NULL || outbuf == NULL)
    return(EINVAL);

  /* Convert the value from string to integer */
  val = strtol((char *)inbuf, (char **)&endptr, 10);
  if (val == LONG_MIN)
  {
    fprintf(stderr, "increment_iv(): error, strtoll() underflow\n");
    return(ERANGE);
  }
  else if (val == LONG_MAX)
  {
    fprintf(stderr, "increment_iv(): error, strtoll() overflow\n");
    return(ERANGE);
  }

  /* We limit the length of an IV to 8 characters here. */
  if (val  >= 99999999)
    val = 0;

  val = val + 1;
  ret = sprintf((char *)outbuf, "%ld", val);

  return(0);
}

/* =================== message digest utility functions =================== */
/*
 * A generic message digest function -- with hashname.
 * This function computes the digest (i.e. hash) of a message using the hash
 * function provided.
 * Input parameters:
 *   hashname - name of a hash function to be used
 *   message - the message whose digest is to be computed
 *   msglen - length of the message in bytes
 * Output parameters
 *   digest - digest of the message
 *   dgstlen - length of the digest in bytes
 */
int message_digest(char *hashname, char *message, unsigned int msglen,
    unsigned char *digest, unsigned int *dgstlen)
{
  const EVP_MD   *hashfunc=NULL;  /* descriptor of message digest algorithm */
  EVP_MD_CTX     *ctx = NULL;     /* digest context */
  int            ret;

  if (hashname == NULL || message == NULL || digest == NULL || dgstlen == NULL)
    return(EINVAL);

  /* Get the structure describing the message digest algorithm by name */
  hashfunc = EVP_get_digestbyname(hashname);
  if(hashfunc == NULL)
  {
    fprintf(stderr, "Error, message_digest(): unknown message digest algorithm"
      " %s\n", hashname);
    return(-1);
  }

  /* Allocate and initialize a digest context */
  ctx = EVP_MD_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error, message_digest(): EVP_MD_CTX_new() failed\n");
    return(-2);
  }

  /* Set up digest context ctx to use the digest type specified by hashfunc */
  ret = EVP_DigestInit_ex(ctx, hashfunc, NULL);
  if (ret == OPENSSL_FAILURE)
  {
    fprintf(stderr, "Error, message_digest(): EVP_DigestInit_ex() failed\n");
    EVP_MD_CTX_free(ctx);
    return(-3);
  }

  /* Hash the current message segment into the digest context ctx. This
     can be called several times on the same ctx to hash additional data. */
  ret = EVP_DigestUpdate(ctx, message, msglen);
  if (ret == OPENSSL_FAILURE)
  {
    fprintf(stderr, "Error, message_digest(): EVP_DigestUpdate() failed\n");
    EVP_MD_CTX_free(ctx);
    return(-4);
  }

  /* Retrieves the digest value from ctx and places it in digest argument */
  ret = EVP_DigestFinal_ex(ctx, digest, dgstlen);
  if (ret == OPENSSL_FAILURE)
  {
    fprintf(stderr, "Error, message_digest(): EVP_DigestFinal_ex() failed\n");
    EVP_MD_CTX_free(ctx);
    return(-5);
  }

  /* Free the digest context allocated */
  EVP_MD_CTX_free(ctx);

  return(0);
}

/*
 * A generic message digest function -- with hashfunc.
 * This function computes the digest (i.e. hash) of a message using the hash
 * function provided.
 * Input parameters:
 *   hashfunc - pointer to a hash function to be used
 *   message - the message whose digest is to be computed
 *   msglen - length of the message in bytes
 * Output parameters
 *   digest - digest of the message
 *   dgstlen - length of the digest in bytes
 */
int message_digest2(const EVP_MD *hashfunc, char *message,
    unsigned int msglen, unsigned char *digest, unsigned int *dgstlen)
{
  EVP_MD_CTX     *ctx = NULL;     /* digest context */
  int            ret;

  if (hashfunc == NULL || message == NULL || digest == NULL || dgstlen == NULL)
    return(EINVAL);

  /* Allocate and initialize a digest context */
  ctx = EVP_MD_CTX_new();
  if (ctx == NULL)
  {
    fprintf(stderr, "Error, message_digest(): EVP_MD_CTX_new() failed\n");
    return(-2);
  }

  /* Set up digest context ctx to use the digest type specified by hashfunc */
  ret = EVP_DigestInit_ex(ctx, hashfunc, NULL);
  if (ret == OPENSSL_FAILURE)
  {
    fprintf(stderr, "Error, message_digest(): EVP_DigestInit_ex() failed\n");
    EVP_MD_CTX_free(ctx);
    return(-3);
  }

  /* Hash the current message segment into the digest context ctx. This
     can be called several times on the same ctx to hash additional data. */
  ret = EVP_DigestUpdate(ctx, message, msglen);
  if (ret == OPENSSL_FAILURE)
  {
    fprintf(stderr, "Error, message_digest(): EVP_DigestUpdate() failed\n");
    EVP_MD_CTX_free(ctx);
    return(-4);
  }

  /* Retrieves the digest value from ctx and places it in digest argument */
  ret = EVP_DigestFinal_ex(ctx, digest, dgstlen);
  if (ret == OPENSSL_FAILURE)
  {
    fprintf(stderr, "Error, message_digest(): EVP_DigestFinal_ex() failed\n");
    EVP_MD_CTX_free(ctx);
    return(-5);
  }

  /* Free the digest context allocated */
  EVP_MD_CTX_free(ctx);

  return(0);
}

/* =================== DSA signature utility functions ==================== */
/*
 * Initialize DSA structure.
 * Input parameters:
 *   bits - the length of the prime number p to be generated.
 *     For lengths under 2048 bits, the length of q is 160 bits; for lengths
 *     greater than or equal to 2048 bits, the length of q is set to 256 bits.
 *   seed - seed 
 *     'seed' being NULL is supported by DSA_generate_parameters_ex().
 *   seedlen - length of the seed in bytes
 * Output parameter:
 *   dsa - pointer to the DSA structure allocated and initialized.
 *         This memory must be freed by the caller after use.
 */
int init_DSA(int bits, unsigned char *seed, unsigned int seedlen, DSA **dsa)
{
  DSA    *dsa1 = NULL;       /* opaque DSA structure */
  int    iter = 0;           /* iteration count used in finding a generator */
  unsigned long  cntr = 0;   /* counter used in finding a generator */
  unsigned long  error = 0L;            /* error code */
  char           errstr[ERRBUFLEN];     /* error string */
  int     ret;

  if (dsa == NULL)
    return(EINVAL);

  /* Create a new DSA structure */
  errstr[0] = '\0';
  dsa1 = DSA_new();
  if (dsa1 == NULL)
  {
    error = ERR_get_error();
    fprintf(stderr, "init_DSA(): DSA_new() failed, error=%lu\n", error);
    return(-1);
  }
 
  /*
   * Generate DSA parameters.
   * Never try to clear the memory of a DSA. It will get Segmentation Fault.
   */
  ret = DSA_generate_parameters_ex(dsa1, bits, seed, seedlen, &iter, 
        &cntr, (void *)NULL);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "init_DSA(): DSA_generate_parameters_ex() failed,"
      " error=%lu\n", error);
    ERR_error_string_n(error, errstr, ERRBUFLEN);
    fprintf(stderr, "%s\n", errstr);
    DSA_free(dsa1);
    return(-2);
  }

  /* Generate DSA public and private keys */
  ret = DSA_generate_key(dsa1);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "init_DSA(): DSA_generate_key() failed, "
      "error=%lu\n", error);
    DSA_free(dsa1);
    return(-3);
  }

  *dsa = dsa1;
  return(0);
}

/*
 * This function computes the digital signature of a message digest
 * using the DSA (Digital Signature Algorithm) algorithm.
 * INPUT parameters:
 *   digest - message digest to be signed
 *   dgstlen - length of the message digest
 *   dsa - allocated and initialized DSA structure
 * OUTPUT parameters:
 *   signature - DSA digital signature
 *   siglen - length of the digital signature
 * This function returns 0 for success.
 */
int get_DSA_signature(unsigned char *digest, unsigned int dgstlen,
   unsigned char *signature, unsigned int *siglen, DSA *dsa)
{
  int    iter = 0;    /* iteration count used in finding a generator */
  unsigned long    cntr = 0;    /* counter used in finding a generator */
  unsigned long  error = 0L;            /* error code */
  char           errstr[ERRBUFLEN];     /* error string */
  int    ret;

  if (digest == NULL || dgstlen == 0 || signature == NULL || siglen == NULL
      || dsa == NULL)
    return(EINVAL);

  /* Sign the message */
  ret = DSA_sign(0, digest, dgstlen, signature, siglen, dsa);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "get_DSA_signature(): DSA_sign() failed, error=%lu\n",
      error);
    return(-1);
  }

  return(0);
}

/*
 * Verify a DSA signature.
 * Input parameters:
 *   dsa - allocated and initialized DSA structure
 *   digest - message digest to be verified
 *   dgstlen - length of the message digest
 *   dsa - allocated and initialized DSA structure
 *   signature - DSA digital signature
 *   siglen - length of the digital signature
 * This function returns 0 for success.
 */
int verify_DSA_signature(unsigned char *digest, unsigned int dgstlen,
    unsigned char *signature, unsigned int siglen, DSA *dsa)
{
  int  ret;
  unsigned long  error = 0L;            /* error code */
  char           errstr[ERRBUFLEN];     /* error string */

  if (digest == NULL || signature == NULL || dsa == NULL)
    return(EINVAL);

  /* Verify the signature */
  ret = DSA_verify(0, digest, dgstlen, signature, siglen, dsa);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "verify_DSA_signature(): DSA_verify() failed, "
      "error=%lu\n", error);
    ERR_error_string_n(error, errstr, ERRBUFLEN);
    fprintf(stderr, "  %s\n", errstr);
    return(-1);
  }

  return(0);
}

/* =================== RSA signature utility functions ==================== */

/*
 * Initialize RSA structure.
 * Input parameters:
 *   bits - the length of modulus
 *   seed - seed to the pseudo-random number generator
 *   seedlen - length of the seed in bytes
 * Output parameter:
 *   rsa - pointer to the RSA structure allocated and initialized.
 *         This memory must be freed by the caller using RSA_free().
 */
int init_RSA(int bits, unsigned char *seed, unsigned int seedlen, RSA **rsa)
{
  RSA    *rsa1 = NULL;       /* opaque RSA structure */
  BIGNUM *bignum = NULL;     /* the exponent e */
  unsigned long  error = 0L;            /* error code */
  char           errstr[ERRBUFLEN];     /* error string */
  int     ret;

  if (seed == NULL || rsa == NULL)
    return(EINVAL);

  /* Create a new RSA structure */
  errstr[0] = '\0';
  rsa1 = RSA_new();
  if (rsa1 == NULL)
  {
    error = ERR_get_error();
    fprintf(stderr, "init_RSA(): RSA_new() failed, error=%lu\n", error);
    return(-1);
  }
 
  /* Seed the random number generator */
  RAND_seed(seed, (int)seedlen);

  /* Generate RSA public and private keys */
  bignum = BN_new();
  if (bignum == NULL)
  {
    error = ERR_get_error();
    fprintf(stderr, "init_RSA(): BN_new() failed, " "error=%lu\n", error);
    RSA_free(rsa1);
    return(-2);
  }
  BN_set_word(bignum, 4271395487);

  ret = RSA_generate_key_ex(rsa1, bits, bignum, (BN_GENCB *)NULL);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "init_RSA(): RSA_generate_key() failed, "
      "error=%lu\n", error);
    RSA_free(rsa1);
    return(-3);
  }

  *rsa = rsa1;
  return(0);
}

/*
 * This function computes the digital signature of a message digest
 * using the RSA algorithm.
 * INPUT parameters:
 *   dgsttype - type of digest (NID_sha1, NID_md5, NID_ripemd160 ...)
 *   digest - message digest to be signed
 *   dgstlen - length of the message digest
 *   rsa - allocated and initialized RSA structure (RSA private key)
 * OUTPUT parameters:
 *   signature - RSA digital signature
 *       This buffer must be at least RSA_size(rsa) bytes.
 *   siglen - length of the digital signature
 * This function returns 0 for success.
 */
int get_RSA_signature(int dgsttype, unsigned char *digest, unsigned int dgstlen,
   unsigned char *signature, unsigned int *siglen, RSA *rsa)
{
  unsigned long  error = 0L;            /* error code */
  char           errstr[ERRBUFLEN];     /* error string */
  int            ret;

  if (digest == NULL || dgstlen == 0 || signature == NULL || siglen == NULL
      || rsa == NULL)
    return(EINVAL);

  /* Sign the message */
  ret = RSA_sign(dgsttype, digest, dgstlen, signature, siglen, rsa);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "get_RSA_signature(): RSA_sign() failed, error=%lu\n",
      error);
    ERR_error_string_n(error, errstr, ERRBUFLEN);
    fprintf(stderr, "  %s\n", errstr);
    return(-1);
  }

  return(0);
}

/*
 * Verify a RSA signature.
 * Input parameters:
 *   dgsttype - type of digest (NID_sha1, NID_md5, NID_ripemd160 ...)
 *     This is the message digest algorithm used to generate the signature.
 *   digest - message digest to be verified against the signature
 *   dgstlen - length of the message digest
 *   signature - RSA digital signature to be verified
 *   siglen - length of the digital signature
 *   rsa - allocated and initialized RSA structure (RSA public key)
 * This function returns 0 for success.
 */
int verify_RSA_signature(int dgsttype, unsigned char *digest, unsigned int dgstlen,
    unsigned char *signature, unsigned int siglen, RSA *rsa)
{
  unsigned long  error = 0L;            /* error code */
  char           errstr[ERRBUFLEN];     /* error string */
  int            ret;

  if (digest == NULL || signature == NULL || rsa == NULL)
    return(EINVAL);

  /* Verify the RSA signature */
  ret = RSA_verify(dgsttype, digest, dgstlen, signature, siglen, rsa);
  if (ret != OPENSSL_SUCCESS)
  {
    error = ERR_get_error();
    fprintf(stderr, "verify_RSA_signature(): RSA_verify() failed, "
      "error=%lu\n", error);
    ERR_error_string_n(error, errstr, ERRBUFLEN);
    fprintf(stderr, "  %s\n", errstr);
    return(-1);
  }

  return(0);
}

/* =================== TLS/SSL utility functions ==================== */

/*
 * This function loads certificate and private key from files.
 * Parameters:
 *   ctx (input) - SSL context
 *   certfile (input) - name of certificate file
 *   keyfile (input) - name of file containing the private key
 */
int load_certificate(SSL_CTX *ctx, char *certfile, char *keyfile)
{
  int    ret;

  /* Clear the error queue */
  ERR_clear_error();

  /* Load certificate from a file into the SSL context */
  ret = SSL_CTX_use_certificate_file(ctx, certfile, SSL_FILETYPE_PEM);
  if (ret != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: SSL_CTX_use_certificate_file() failed\n");
    ERR_print_errors_fp(stderr);
    return(OPENSSL_ERR_BAD_CERTFILE);
  }

  /* Load the private key into SSL context */
  ret = SSL_CTX_use_PrivateKey_file(ctx, keyfile, SSL_FILETYPE_PEM);
  if (ret != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: SSL_CTX_use_PrivateKey_file() failed\n");
    ERR_print_errors_fp(stderr);
    return(OPENSSL_ERR_BAD_KEYFILE);
  }

  /* Verify the private key just loaded into the SSL context */
  ret = SSL_CTX_check_private_key(ctx);
  if (ret != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: SSL_CTX_check_private_key() failed\n");
    ERR_print_errors_fp(stderr);
    return(OPENSSL_ERR_KEY_MISMATCH);
  }

  return(0);
}
 
/*
 * Display information in an X509 certificate.
 * Input argument: cert -- pointer to an X.509 certificate.
 */
int display_certificate_info(X509 *cert)
{
  X509_NAME *nm = NULL;       /* X509 name */
  int  version;
  ASN1_INTEGER  *serial_num;  /* serial number of the certificate */
  BIGNUM        *bignum;
  char          *serialptr;   /* pointer to a serial number */

  const ASN1_TIME *time1;     /* start time of cert valid time period */
  const ASN1_TIME *time2;     /* end time of cert valid time period */
  BIO   *outbio = NULL;       /* BIO output stream */

  int sig_algrtm_nid;         /* nid of signature algorithm */
  const char* namebuf;        /* buffer for signature algorithm's name */

  int      isca;              /* is a valid CA certificate */
  EVP_PKEY *pubkey = NULL;    /* public key of the certificate */
  int      ret;

  if (cert == NULL)
    return(EINVAL);

  /* Is this a self-signed certificate? */
  if (X509_check_issued(cert, cert) == X509_V_OK)
    fprintf(stdout, "This is a self-signed certificate.\n");
  else
    fprintf(stdout, "This is not a self-signed certificate.\n");

  /* Extract and print the subject name from the X.509 certificate */
  nm = X509_get_subject_name(cert);
  if (nm != NULL)
  {
    fprintf(stdout, "  Subject of the X509 certificate:\n    ");
    X509_NAME_print_ex_fp(stdout, nm, 0, 0);
  }
  else
    fprintf(stderr, "Error, X509_get_subject_name() failed\n");

  /* Extract and print the issuer name from the X.509 certificate */
  nm = X509_get_issuer_name(cert);
  if (nm != NULL)
  {
    fprintf(stdout, "\n  Issuer of the X509 certificate:\n    ");
    X509_NAME_print_ex_fp(stdout, nm, 0, 0);
    fprintf(stdout, "\n");
  }
  else
    fprintf(stderr, "Error, X509_get_issuer_name() failed\n");

  /* Extract and print the certificate's serial number */
  serial_num = X509_get_serialNumber(cert);
  if (serial_num != NULL)
  {
    bignum = ASN1_INTEGER_to_BN(serial_num, NULL);
    if (!bignum)
      fprintf(stderr, "Error, ASN1_INTEGER_to_BN() failed to convert "
        "ASN1INTEGER to BN\n");
    else
    {
      serialptr = BN_bn2dec(bignum);
      fprintf(stdout, "  Serial number of the X509 certificate: %s\n", serialptr);
      BN_free(bignum);
    }
  }
  else
    fprintf(stderr, "Error, X509_get_serialNumber() failed\n");

  /* Extract and print the certificate's valid time period */
  time1 = X509_getm_notBefore(cert);
  time2 = X509_getm_notAfter(cert);
  outbio  = BIO_new_fp(stdout, BIO_NOCLOSE);
  if (time1 != NULL && time2 != NULL)
  {
    if (outbio != NULL)
    {
      BIO_printf(outbio, "  Validity period: from ");
      ASN1_TIME_print(outbio, time1);
      BIO_printf(outbio, " to ");
      ASN1_TIME_print(outbio, time2);
      BIO_printf(outbio, "\n");
    }
    else
      fprintf(stderr, "Cannot print validity period because outbio is NULL.\n");
  }
  else
    fprintf(stderr, "Error, failed to get start or end valid time\n");

  /* Extract and print the certificate's X509 version - zero-based */
  version = ((int) X509_get_version(cert)) + 1;
    fprintf(stdout, "  Version of the X509 certificate: %u\n", version);

  /* Extract and print the certificate's signature algorithm */
  sig_algrtm_nid = X509_get_signature_nid(cert);
  if (sig_algrtm_nid != NID_undef)
  {
    namebuf = OBJ_nid2ln(sig_algrtm_nid);
    if (namebuf != NULL)
      fprintf(stdout, "  Certificate's signature algorithm: %s\n", namebuf);
    else
      fprintf(stderr, "Error, OBJ_nid2ln() failed to convert nid to name\n");
  }
  else
    fprintf(stderr, "Error, X509_get_signature_nid() failed to get signature"
      " algorithm's nid\n");

  /* See if this is a CA certificate */
  isca = X509_check_ca(cert);
  if (isca >= 1)
    fprintf(stdout, "  This is a valid CA certificate (ret=%d).\n", isca);
  else
    fprintf(stdout, "  This is not a valid CA certificate.\n");

  /* Extract and print the public key of the certificate */
  pubkey = X509_get_pubkey(cert);
  if (pubkey != NULL)
  {
    if (outbio != NULL)
    {
      ret = EVP_PKEY_print_public(outbio, pubkey, 0, NULL);
      if (!ret)
        fprintf(stderr, "Error, EVP_PKEY_print_public() failed to print"
          " certificate's public key\n");
      /* must free the pubkey */
      EVP_PKEY_free(pubkey);
    }
    else
      fprintf(stderr, "Cannot print public key because outbio is NULL.\n");
  }
  else
    fprintf(stderr, "Error, X509_get_pubkey() failed to extract public key\n");

  if (outbio) BIO_free(outbio);
  return(0);
}

/*
 * Display information about the subject and issuer of a X509 certificate
 * used in an SSL/TLS handshaking.
 * If you like to see more details of the certificate, change this
 * function to call display_certificate_info(X509 *cert) instead.
 * Input argument: ssl -- a SSL structure representing a SSL connection
 */
void display_ssl_certificate_info(SSL* ssl)
{
  X509      *cert = NULL;    /* X509 certificate */
  X509_NAME *nm = NULL;      /* X509 name */

  /* Get the X509 certificate of the peer */
  cert = SSL_get_peer_certificate(ssl); /* get the server's certificate */

  /* Here we're simply interested in subject and issuer's names.
   * For full details of a certificate, call 
   * display_certificate_info(X509 *cert) instead.
   */
  if ( cert != NULL )
  {
    /* Extract and print the subject name from the X.509 certificate */
    nm = X509_get_subject_name(cert);
    if (nm != NULL)
    {
      fprintf(stdout, "  Subject of the X509 certificate:\n    ");
      X509_NAME_print_ex_fp(stdout, nm, 0, 0);
    }
    /* Extract and print the issuer name from the X.509 certificate */
    nm = X509_get_issuer_name(cert);
    if (nm != NULL)
    {
      fprintf(stdout, "\n  Issuer of the X509 certificate:\n    ");
      X509_NAME_print_ex_fp(stdout, nm, 0, 0);
      fprintf(stdout, "\n\n");
    }
  }
  else
    fprintf(stdout, "No peer certificates received.\n");
}

/*
 * Print error returned from TLS/SSL I/O functions.
 */
void print_ssl_io_error(int error)
{
  switch (error)
  {
    case SSL_ERROR_NONE:
      fprintf(stderr, "SSL_ERROR_NONE\n");
    break;
    case SSL_ERROR_ZERO_RETURN:
      fprintf(stderr, "SSL_ERROR_ZERO_RETURN\n");
    break;
    case SSL_ERROR_WANT_READ:
      fprintf(stderr, "SSL_ERROR_WANT_READ\n");
    break;
/*
    case ERROR_WANT_WRITE:
      fprintf(stderr, "ERROR_WANT_WRITE\n");
    break;
*/
    case SSL_ERROR_WANT_CONNECT:
      fprintf(stderr, "SSL_ERROR_WANT_CONNECT\n");
    break;
    case SSL_ERROR_WANT_ACCEPT:
      fprintf(stderr, "SSL_ERROR_WANT_ACCEPT\n");
    break;
    case SSL_ERROR_WANT_X509_LOOKUP:
      fprintf(stderr, "SSL_ERROR_WANT_X509_LOOKUP\n");
    break;
    case SSL_ERROR_WANT_ASYNC:
      fprintf(stderr, "SSL_ERROR_WANT_ASYNC\n");
    break;
/*
    case SSL_ERROR_WANT_ASYNC_JOB:
      fprintf(stderr, "SSL_ERROR_WANT_ASYNC_JOB\n");
    break;
*/
    case SSL_ERROR_SYSCALL:
      fprintf(stderr, "SSL_ERROR_SYSCALL\n");
    break;
    case SSL_ERROR_SSL:
      fprintf(stderr, "SSL_ERROR_SSL\n");
    break;
    other:
      fprintf(stderr, "Unknown error\n");
  }
}

/*
 * Display the cipher suites used in the SSL/TLS connection.
 */
void display_cipher_suites(SSL *ssl)
{
  const char *cipher;
  int        i;

  fprintf(stdout, "Cipher suite(s) used:");
  for( i = 0; (cipher = SSL_get_cipher_list( ssl, i )); i++ )
    fprintf(stdout, "  %s", cipher );
  fprintf(stdout, "\n");
}

