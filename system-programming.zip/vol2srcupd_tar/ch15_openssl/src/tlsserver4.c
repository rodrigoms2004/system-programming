/*
 * A TLS/SSL server.
 * This server program communicates with clients using TLS/SSL protocol.
 * The server verifies a client certificate signed by a chain of CAs.
 * Requiring client authentication using the SSL_VERIFY_FAIL_IF_NO_PEER_CERT
 * flag.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2021 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>    /* protocols such as IPPROTO_TCP, ... */
#include <string.h>        /* memset(), strlen(), memcmp() */
#include <stdlib.h>        /* atoi() */
#include <unistd.h>
#include <resolv.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <resolv.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509.h>
#include "myopenssl.h"

/*
 * This function serves a newly connected SSL client.
 * Parameters:
 *   ctx (input) - SSL context.
 *   clntsock (input) - the child socket to communicate with the client.
 * Function output: return 0 on success, non-zero on failure.
 * Note that Openssl provides different functions to retrieve the actual
 * error. Unfortunately, they return different data types, some 'int'
 * (SSL_get_error()) and some 'unsigned long' (ERR_get_error()).
 * It makes it hard to return both types of errors from a function.
 * Note: If SSL_CTX_set_verify() is called in this function, it must be
 * placed before SSL_new().
 */
int serve_ssl_client(SSL_CTX *ctx, int clntsock)
{
  SSL            *ssl = NULL;        /* SSL structure/connection */
  unsigned char  reqmsg[MAXREQSZ];   /* buffer for incoming request message */
  unsigned char  reply[MAXRPLYSZ];   /* buffer for outgoing server reply */
  unsigned char  replysz;            /* length in bytes of reply message */
  int            insize;             /* actual number of bytes read */
  int            outsz;              /* actual number of bytes written */
  int            error = 0;          /* error from certain SSL_xxx calls */
  unsigned char  msgcnt;             /* count of reply messages to client */
  int            done = 0;           /* done with current client */
  int            ret;
  X509           *clnt_cert = NULL;  /* pointer to peer's certificate */

  if (ctx == NULL)
    return(EINVAL);
  ERR_clear_error();

  /* Create a new SSL structure to hold the connection data.
   * Note that to require client authentication, the call to
   * SSL_CTX_set_verify() must be done BEFORE SSL_new(). Or it has no effect.
   */
  ssl = SSL_new(ctx);
  if (ssl == NULL)
  {
    fprintf(stderr, "Error: SSL_new() failed:\n");
    ERR_print_errors_fp(stderr);
    return(OPENSSL_ERR_SSLNEW_FAIL);
  }

  /* Associate the SSL structure with the socket */
  ret = SSL_set_fd(ssl, clntsock);
  if (ret != OPENSSL_SUCCESS)
  {
    fprintf(stderr, "Error: SSL_set_fd() failed:\n");
    ERR_print_errors_fp(stderr);
    SSL_free(ssl);
    return(OPENSSL_ERR_SSLSETFD_FAIL);
  }

  /* Wait for the TLS/SSL client to initiate the TLS/SSL handshake */
  ret = SSL_accept(ssl);
  if (ret != OPENSSL_SUCCESS)
  {
    error = SSL_get_error(ssl, ret);
    fprintf(stderr, "Error: SSL_accept() failed, error=%d\n", error);
    ERR_print_errors_fp(stderr);
    SSL_free(ssl);
    return(error);
  }

  /* Display information about the peer/client certificate */
  display_ssl_certificate_info(ssl);

  /* The service loop */
  done = 0;
  msgcnt = 1;
  do
  {
    /* Read the next request message from the TLS/SSL client */
    insize = SSL_read(ssl, reqmsg, MAXREQSZ);
    if (insize <= 0)
    {
      error = SSL_get_error(ssl, insize);
      fprintf(stderr, "Error: SSL_read() failed, error=%d\n", error);
      break;
    }

    reqmsg[insize] = '\0';
    fprintf(stdout, "Server received: %s\n", reqmsg);

    /* Process the request here ... */

    /* Construct a reply message */
    if ( !strcmp(reqmsg, BYE_MSG) )
    {
      done = 1;
      strcpy(reply, reqmsg);
    }
    else
      sprintf(reply, SRVREPLY2, msgcnt++);

    replysz = strlen(reply);

    /* Send back a reply */
    outsz = SSL_write(ssl, reply, replysz);
    if (outsz != replysz)
    {
      error = SSL_get_error(ssl, outsz);
      fprintf(stderr, "Error: SSL_write() failed, error=%d\n", error);
      break;
    }
  } while (!done);

  /* Free up resources and return */
  SSL_free(ssl);
  return(error);
}
 
/* TLS/SSL server program */
int main(int argc, char *argv[])
{
  int    sfd;                       /* file descriptor of the listener socket */
  struct sockaddr_in    srvaddr;    /* IPv4 socket address structure */
  struct sockaddr_in6   srvaddr6;   /* IPv6 socket address structure */
  in_port_t  portnum = SRVPORT;     /* port number this server listens on */
  int        portnum_in = 0;        /* port number specified by user */
  struct sockaddr_in6   clntaddr6;  /* client socket address */
  socklen_t             clntaddr6sz = sizeof(clntaddr6);
  int    newsock = 0;               /* file descriptor of client data socket */
  int    ipv6 = 0;                  /* IPv6 mode or not */
  int    ret;                       /* return value */
  SSL_CTX    *ctx;                  /* SSL context */
 
  /* Print Usage if requested by user */
  if (argc > 1 && argv[1][0] == '?' )
  {
    fprintf(stderr, "Usage: %s [server_port] [1 (use IPv6)]\n", argv[0]);
    return(0);
  }

  /* Get the server port number from user, if any */
  if (argc > 1)
  {
    portnum_in = atoi(argv[1]);
    if (portnum_in <= 0)
    {
      fprintf(stderr, "Error: port number %s invalid\n", argv[1]);
      fprintf(stderr, "Usage: %s [server_port] [1 (use IPv6)]\n", argv[0]);
      return(-1);
    }
    else
      portnum = portnum_in;
  }

  /* Get the IPv6 switch from user, if any */
  if (argc > 2)
  {
    if (argv[2][0] == '1')
      ipv6 = 1;
    else if (argv[2][0] != '0')
    {
      fprintf(stderr, "Usage: %s [server_port] [1 (use IPv6)]\n", argv[0]);
      return(-2);
    }
  }

  fprintf(stdout, "TLS/SSL server listening at portnum=%u ipv6=%u\n",
    portnum, ipv6);

  /* Create the server listener socket */
  if (ipv6)
    ret = new_bound_srv_endpt(&sfd, (struct sockaddr *)&srvaddr6, AF_INET6,
      portnum);
  else
    ret = new_bound_srv_endpt(&sfd, (struct sockaddr *)&srvaddr, AF_INET,
      portnum);

  if (ret != 0)
  {
    fprintf(stderr, "Error: new_bound_srv_endpt() failed, ret=%d\n", ret);
    return(-3);
  }

  /* Create a TLS/SSL context -- a framework enabling TLS/SSL connections. */
  ctx = SSL_CTX_new(TLS_server_method());
  if (ctx == NULL)
  {
    fprintf(stderr, "Error: SSL_CTX_new() failed\n");
    close(sfd);
    return(-4);
  }

  /* Set default locations for trusted CA certificates for verification */
  /* I found whether doing this first or last does not make a difference */
  if(SSL_CTX_load_verify_locations(ctx, CA_FILE, CA_DIR) < 1)
  {
    fprintf(stderr, "Error: SSL_CTX_load_verify_locations() failed to set "
      "verify location\n");
    SSL_CTX_free(ctx);
    close(sfd);
    return(-5);
  }

  /* Load the server's certificate and private key */
  ret = load_certificate(ctx, SRV_CERT_FILE, SRV_KEY_FILE);
  if (ret != SUCCESS)
  {
    fprintf(stderr, "Error: load_certificate() failed, ret=%d\n", ret);
    SSL_CTX_free(ctx);
    close(sfd);
    return(-6);
  }

  /* Require client authentication -- this function returns void.
   * Fail the client connection request if client does not send its certificate
   * or the sent client certificate fails in verification.
   */
  SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT, NULL);

  /* Server's service loop. Wait for next client and service it. */
  while (1)
  {
    /* Accept the next client's connection request */
    newsock = accept(sfd, (struct sockaddr *)&clntaddr6, &clntaddr6sz);
    if (newsock < 0)
    {
      fprintf(stderr, "Error: accept() failed, errno=%d\n", errno);
      continue;
    }

    fprintf(stdout, "\nServer got a client connection\n");

    /* Service the current SSL client */
    ret = serve_ssl_client(ctx, newsock);
    if (ret != 0)
      fprintf(stderr, "Error: serve_ssl_client() failed, ret=%d\n", ret);

    close(newsock);
  }  /* while */

  SSL_CTX_free(ctx);   /* release SSL context */
  close(sfd);          /* close server socket */
  return(0);
}
