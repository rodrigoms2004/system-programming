/*
 * Print information in an X.509 certificate.
 * Authored by Mr. Jin-Jwei Chen.
 * Copyright (c) 2014-2016, 2020 Mr. Jin-Jwei Chen. All rights reserved.
 */

#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <string.h>        /* memset(), strlen(), memcmp() */
#include <stdlib.h>        /* atoi() */
#include <unistd.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/pem.h>
#include <openssl/bn.h>
#include <openssl/asn1.h>
#include <openssl/x509_vfy.h>
#include <openssl/bio.h>
#include "myopenssl.h"
 
/* Peek into a X.509 certificate */
int main(int argc, char *argv[])
{
  char  *certfname;   /* file name of an X.509 certificate */
  FILE  *fp;
  int   ret;
  X509  *cert;        /* pointer to an X.509 object */

  /* Get the name of the file containing the certificate in PEM format */
  if (argc < 2)
  {
    fprintf(stderr, "Usage: %s certificate_file_name (PEM format)\n", argv[0]);
    return(-1);
  }
  certfname = argv[1];

  /* Try to open the certificate file */
  fp = fopen(certfname, "r");
  if (fp == NULL)
  {
    fprintf(stderr, "Error, failed to open certificate file %s, error=%d\n",
      certfname, errno);
    return(-2);
  }

  /* Read the PEM-format certificate into an X.509 object */
  cert = PEM_read_X509(fp, NULL, NULL, NULL);
  if (cert == NULL)
  {
    fprintf(stderr, "Error, PEM_read_X509() failed to read certificate from"
      " file %s\n", certfname);
    fclose(fp);
    return(-3);
  }

  /* Display information contained in the X.509 certificate */
  ret = display_certificate_info(cert);

  X509_free(cert);
  fclose(fp);
  return(0);
}
